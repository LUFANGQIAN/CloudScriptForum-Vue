const _0x4f7d0f = (function () {
        let _0x3679e0 = !![];
        return function (_0x48391c, _0x417cab) {
            const _0x23e943 = _0x3679e0 ? function () {
                if (_0x417cab) {
                    const _0x2098f4 = _0x417cab['apply'](_0x48391c, arguments);
                    return _0x417cab = null, _0x2098f4;
                }
            } : function () {
            };
            return _0x3679e0 = ![], _0x23e943;
        };
    }()), _0x8e7172 = _0x4f7d0f(this, function () {
        const _0x2d06ce = function () {
                let _0x37a0b9;
                try {
                    _0x37a0b9 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x4caf4b) {
                    _0x37a0b9 = window;
                }
                return _0x37a0b9;
            }, _0x5e3897 = _0x2d06ce(), _0x3f3db8 = _0x5e3897['console'] = _0x5e3897['console'] || {}, _0x21e37f = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x3068a9 = 0x0; _0x3068a9 < _0x21e37f['length']; _0x3068a9++) {
            const _0x25292c = _0x4f7d0f['constructor']['prototype']['bind'](_0x4f7d0f), _0x115546 = _0x21e37f[_0x3068a9], _0x3bb19c = _0x3f3db8[_0x115546] || _0x25292c;
            _0x25292c['__proto__'] = _0x4f7d0f['bind'](_0x4f7d0f), _0x25292c['toString'] = _0x3bb19c['toString']['bind'](_0x3bb19c), _0x3f3db8[_0x115546] = _0x25292c;
        }
    });
_0x8e7172();
import { r } from './Request-CHKnUlo5.js';
const s = _0x3a67a9 => r({
        'url': '/comment/add',
        'method': 'post',
        'data': _0x3a67a9
    }), a = _0x2919cc => r({
        'url': '/comment/' + _0x2919cc,
        'method': 'delete'
    }), n = (_0x5abe3e, _0x1816e9, _0x2fb149) => r({
        'url': '/comment/list',
        'method': 'get',
        'params': {
            'articleId': _0x5abe3e,
            'pageNum': _0x1816e9,
            'pageSize': _0x2fb149
        }
    }), d = (_0x191d24, _0x2c07af, _0x1b8ab2) => r({
        'url': '/comment/reply/list',
        'method': 'get',
        'params': {
            'commentId': _0x191d24,
            'pageNum': _0x2c07af,
            'pageSize': _0x1b8ab2
        }
    }), l = (_0x4c7ee3, _0x5c721b, _0x3408bd) => r({
        'url': '/comment/manage/list',
        'method': 'post',
        'params': {
            'pageNum': _0x4c7ee3,
            'pageSize': _0x5c721b
        },
        'data': _0x3408bd
    });
export {
    s as a,
    n as b,
    l as c,
    a as d,
    d as g
};