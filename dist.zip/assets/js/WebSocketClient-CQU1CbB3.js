const _0x32402b = (function () {
        let _0x1c53fe = !![];
        return function (_0x3a19e1, _0x43ee40) {
            const _0xaf44c5 = _0x1c53fe ? function () {
                if (_0x43ee40) {
                    const _0x39fb20 = _0x43ee40['apply'](_0x3a19e1, arguments);
                    return _0x43ee40 = null, _0x39fb20;
                }
            } : function () {
            };
            return _0x1c53fe = ![], _0xaf44c5;
        };
    }()), _0x30d605 = _0x32402b(this, function () {
        const _0x3ac5a3 = function () {
                let _0x24e16d;
                try {
                    _0x24e16d = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x32afee) {
                    _0x24e16d = window;
                }
                return _0x24e16d;
            }, _0xec8df5 = _0x3ac5a3(), _0x5677a7 = _0xec8df5['console'] = _0xec8df5['console'] || {}, _0x5c02dd = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x32cbe5 = 0x0; _0x32cbe5 < _0x5c02dd['length']; _0x32cbe5++) {
            const _0x32f0f6 = _0x32402b['constructor']['prototype']['bind'](_0x32402b), _0x42213e = _0x5c02dd[_0x32cbe5], _0x34e2ab = _0x5677a7[_0x42213e] || _0x32f0f6;
            _0x32f0f6['__proto__'] = _0x32402b['bind'](_0x32402b), _0x32f0f6['toString'] = _0x34e2ab['toString']['bind'](_0x34e2ab), _0x5677a7[_0x42213e] = _0x32f0f6;
        }
    });
_0x30d605();
import {
    aA as _0x14e6ed,
    r as _0x21d900
} from './index-54DmW9hq.js';
import {
    G as _0x11171b,
    b as _0x380128
} from './Request-CHKnUlo5.js';
const W = _0x14e6ed('message', () => {
    const _0x1b93f8 = _0x21d900([]), _0x408ef1 = _0x21d900(0x0), _0x6fe398 = _0x21d900(null), _0x2d1d56 = _0x21d900([]), _0x37217d = _0x51c7fd => {
            _0x1b93f8['value'] = _0x51c7fd, _0x408ef1['value'] = _0x51c7fd['reduce']((_0x445401, _0x3fa827) => _0x445401 + _0x3fa827['unreadCount'], 0x0);
        }, _0x543adf = (_0x28dd4c, _0xc9a9c6, _0x23576c, _0x5861b8) => {
            const _0x3c2ae8 = _0x1b93f8['value']['findIndex'](_0x4a0d7 => _0x4a0d7['targetUserId'] === _0x28dd4c);
            if (_0x3c2ae8 !== -0x1) {
                const _0x209bb5 = _0x1b93f8['value'][_0x3c2ae8], _0x272bc6 = _0x209bb5['unreadCount'] || 0x0, _0x30b10f = {
                        ..._0x209bb5,
                        'lastMessageContent': _0xc9a9c6['content'],
                        'lastMessageTime': _0xc9a9c6['createTime']
                    };
                _0x5861b8 && (_0x5861b8['nickname'] && (_0x30b10f['targetUserNickname'] = _0x5861b8['nickname']), _0x5861b8['avatar'] && (_0x30b10f['targetUserAvatar'] = _0x5861b8['avatar'])), typeof _0x23576c == 'number' ? (_0x30b10f['unreadCount'] = _0x23576c, _0x408ef1['value'] = _0x408ef1['value'] - _0x272bc6 + _0x23576c) : _0x6fe398['value'] !== _0x28dd4c ? (_0x30b10f['unreadCount'] = _0x272bc6 + 0x1, _0x408ef1['value']++) : _0x30b10f['unreadCount'] = _0x272bc6, _0x1b93f8['value']['splice'](_0x3c2ae8, 0x1), _0x1b93f8['value']['unshift'](_0x30b10f);
            } else {
                const _0x557509 = typeof _0x23576c == 'number' ? _0x23576c : _0x6fe398['value'] === _0x28dd4c ? 0x0 : 0x1, _0xb7ca78 = {
                        'id': _0x28dd4c,
                        'targetUserId': _0x28dd4c,
                        'targetUserNickname': (_0x5861b8 == null ? void 0x0 : _0x5861b8['nickname']) || '新用户',
                        'targetUserAvatar': (_0x5861b8 == null ? void 0x0 : _0x5861b8['avatar']) || '',
                        'lastMessageContent': _0xc9a9c6['content'],
                        'lastMessageTime': _0xc9a9c6['createTime'],
                        'unreadCount': _0x557509,
                        'isOnline': !0x1
                    };
                _0x1b93f8['value']['unshift'](_0xb7ca78), _0x408ef1['value'] += _0x557509;
            }
        }, _0x4f5a04 = _0x10afbb => {
            const _0x49ec7c = _0x1b93f8['value']['find'](_0x277f58 => _0x277f58['targetUserId'] === _0x10afbb);
            _0x49ec7c && _0x49ec7c['unreadCount'] > 0x0 && (_0x408ef1['value'] -= _0x49ec7c['unreadCount'], _0x49ec7c['unreadCount'] = 0x0);
        };
    return {
        'conversationList': _0x1b93f8,
        'totalUnreadCount': _0x408ef1,
        'currentChatUserId': _0x6fe398,
        'currentChatMessages': _0x2d1d56,
        'setConversationList': _0x37217d,
        'updateConversation': _0x543adf,
        'clearConversationUnread': _0x4f5a04,
        'setCurrentChatUser': _0x463c95 => {
            _0x6fe398['value'] = _0x463c95, _0x4f5a04(_0x463c95);
        },
        'addMessageToCurrentChat': _0x4aefd6 => {
            _0x2d1d56['value']['push'](_0x4aefd6);
        },
        'setCurrentChatMessages': _0x20f218 => {
            _0x2d1d56['value'] = _0x20f218;
        },
        'revokeMessageInCurrentChat': _0x30bcee => {
            const _0x37c728 = _0x2d1d56['value']['find'](_0x1e292e => _0x1e292e['id'] === _0x30bcee);
            _0x37c728 && (_0x37c728['isRevoked'] = 0x1);
        },
        'removeConversation': _0x5d3e49 => {
            const _0x1f680f = _0x1b93f8['value']['findIndex'](_0x28c175 => _0x28c175['targetUserId'] === _0x5d3e49);
            if (_0x1f680f !== -0x1) {
                const _0x1a05ba = _0x1b93f8['value'][_0x1f680f];
                _0x408ef1['value'] -= _0x1a05ba['unreadCount'], _0x1b93f8['value']['splice'](_0x1f680f, 0x1);
            }
        },
        'updateUserOnlineStatus': (_0x4d53a1, _0x52f1c6) => {
            const _0x2c2a27 = _0x1b93f8['value']['find'](_0x2ddf50 => _0x2ddf50['targetUserId'] === _0x4d53a1);
            _0x2c2a27 && (_0x2c2a27['isOnline'] = _0x52f1c6);
        },
        'updateConversationLastMessage': (_0x7d96f2, _0x4bcee4) => {
            const _0x342e48 = _0x1b93f8['value']['find'](_0x26b060 => _0x26b060['targetUserId'] === _0x7d96f2);
            _0x342e48 && (_0x342e48['lastMessageContent'] = _0x4bcee4);
        },
        'clearAll': () => {
            _0x1b93f8['value'] = [], _0x408ef1['value'] = 0x0, _0x6fe398['value'] = null, _0x2d1d56['value'] = [];
        }
    };
}, { 'persist': !0x1 });
class S {
    constructor() {
        this['ws'] = null, this['url'] = '', this['reconnectTimer'] = null, this['heartbeatTimer'] = null, this['isManualClose'] = !0x1, this['messageHandlers'] = new Map();
    }
    ['connect']() {
        const _0x132f64 = _0x11171b();
        if (!_0x132f64) {
            console['error']('WebSocket\x20连接失败：token\x20为空');
            return;
        }
        this['ws'] && (console['log']('WebSocket\x20已存在，先关闭旧连接'), this['close']());
        const _0x1206ff = 'http://172.17.0.5:5000'['replace'](/^http/, 'ws') + '/ws/message?token=' + _0x132f64;
        this['url'] = _0x1206ff, this['isManualClose'] = !0x1;
        try {
            this['ws'] = new WebSocket(_0x1206ff), this['ws']['onopen'] = () => {
                this['startHeartbeat'](), this['triggerHandler']('open');
            }, this['ws']['onmessage'] = _0x24eede => {
                try {
                    const _0x4ab2f2 = JSON['parse'](_0x24eede['data']);
                    this['handleMessage'](_0x4ab2f2);
                } catch (_0x32e021) {
                    console['error']('解析\x20WebSocket\x20消息失败:', _0x32e021);
                }
            }, this['ws']['onerror'] = _0x402531 => {
                console['error']('WebSocket\x20错误:', _0x402531), this['triggerHandler']('error', _0x402531);
            }, this['ws']['onclose'] = () => {
                this['stopHeartbeat'](), this['triggerHandler']('close'), this['isManualClose'] || this['reconnect']();
            };
        } catch (_0x386a9c) {
            console['error']('创建\x20WebSocket\x20连接失败:', _0x386a9c);
        }
    }
    ['send'](_0x2786c7) {
        if (this['ws'] && this['ws']['readyState'] === WebSocket['OPEN']) {
            const _0x22f9c1 = JSON['stringify'](_0x2786c7);
            this['ws']['send'](_0x22f9c1), _0x2786c7['type'] !== 'HEARTBEAT' && console['log']('发送\x20WebSocket\x20消息:', _0x2786c7);
        } else
            console['error']('WebSocket\x20未连接'), _0x380128['error']('网络连接异常，请稍后重试');
    }
    ['sendTextMessage'](_0x1f6296, _0x46d5c4) {
        this['send']({
            'type': 'SEND_MESSAGE',
            'toUserId': _0x1f6296,
            'content': _0x46d5c4,
            'messageType': 0x1
        });
    }
    ['sendImageMessage'](_0x1c7dea, _0x4d8494) {
        this['send']({
            'type': 'SEND_MESSAGE',
            'toUserId': _0x1c7dea,
            'content': '[图片]',
            'messageType': 0x2,
            'imageUrl': _0x4d8494
        });
    }
    ['markAsRead'](_0x1eb24f) {
        this['send']({
            'type': 'READ_MESSAGE',
            'targetUserId': _0x1eb24f
        });
    }
    ['revokeMessage'](_0x4a5685) {
        this['send']({
            'type': 'REVOKE_MESSAGE',
            'messageId': _0x4a5685
        });
    }
    ['handleMessage'](_0x3d7ec5) {
        const {type: _0x2545e8} = _0x3d7ec5;
        _0x2545e8 === 'SYSTEM' && this['handleSystemNotification'](_0x3d7ec5), this['triggerHandler'](_0x2545e8, _0x3d7ec5);
    }
    ['handleSystemNotification'](_0x53e7ef) {
        const {
                content: _0x311d69,
                messageType: _0x47b938
            } = _0x53e7ef, _0x3985b3 = {
                0x1: '评论',
                0x2: '点赞',
                0x3: '收藏',
                0x4: '关注'
            }[_0x47b938] || '系统';
        window['ElNotification'] ? window['ElNotification']({
            'title': _0x3985b3 + '通知',
            'message': _0x311d69,
            'type': 'info',
            'duration': 0x1194,
            'position': 'top-right'
        }) : console['log']('[系统通知]\x20' + _0x311d69);
    }
    ['on'](_0x3b5306, _0x21a5f2) {
        this['messageHandlers']['has'](_0x3b5306) || this['messageHandlers']['set'](_0x3b5306, []), this['messageHandlers']['get'](_0x3b5306)['push'](_0x21a5f2);
    }
    ['off'](_0x64febe, _0x34d57e) {
        if (this['messageHandlers']['has'](_0x64febe)) {
            const _0x338720 = this['messageHandlers']['get'](_0x64febe), _0x3f2653 = _0x338720['indexOf'](_0x34d57e);
            _0x3f2653 > -0x1 && _0x338720['splice'](_0x3f2653, 0x1);
        }
    }
    ['triggerHandler'](_0x15d2df, _0x22b2de) {
        this['messageHandlers']['has'](_0x15d2df) && this['messageHandlers']['get'](_0x15d2df)['forEach'](_0x592cbe => {
            _0x592cbe(_0x22b2de);
        });
    }
    ['startHeartbeat']() {
        this['stopHeartbeat'](), this['heartbeatTimer'] = setInterval(() => {
            this['send']({ 'type': 'HEARTBEAT' });
        }, 0x7530);
    }
    ['stopHeartbeat']() {
        this['heartbeatTimer'] && (clearInterval(this['heartbeatTimer']), this['heartbeatTimer'] = null);
    }
    ['reconnect']() {
        this['reconnectTimer'] || (console['log']('5秒后尝试重连...'), this['reconnectTimer'] = setTimeout(() => {
            this['reconnectTimer'] = null, this['connect']();
        }, 0x1388));
    }
    ['close']() {
        this['isManualClose'] = !0x0, this['stopHeartbeat'](), this['reconnectTimer'] && (clearTimeout(this['reconnectTimer']), this['reconnectTimer'] = null), this['ws'] && (this['ws']['onclose'] = null, this['ws']['close'](), this['ws'] = null);
    }
    ['isConnected']() {
        return this['ws'] && this['ws']['readyState'] === WebSocket['OPEN'];
    }
}
const O = new S();
export {
    O as W,
    W as u
};