const _0x468a2a = (function () {
        let _0x38d3d9 = !![];
        return function (_0xdffb17, _0x4ab8ad) {
            const _0x26c5a5 = _0x38d3d9 ? function () {
                if (_0x4ab8ad) {
                    const _0x6b1c04 = _0x4ab8ad['apply'](_0xdffb17, arguments);
                    return _0x4ab8ad = null, _0x6b1c04;
                }
            } : function () {
            };
            return _0x38d3d9 = ![], _0x26c5a5;
        };
    }()), _0x29d170 = _0x468a2a(this, function () {
        const _0x9e2286 = function () {
                let _0x8cb145;
                try {
                    _0x8cb145 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x34ba01) {
                    _0x8cb145 = window;
                }
                return _0x8cb145;
            }, _0x486db4 = _0x9e2286(), _0x3adfd7 = _0x486db4['console'] = _0x486db4['console'] || {}, _0x186a6f = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x2eeb39 = 0x0; _0x2eeb39 < _0x186a6f['length']; _0x2eeb39++) {
            const _0x1ccef4 = _0x468a2a['constructor']['prototype']['bind'](_0x468a2a), _0xd5fe69 = _0x186a6f[_0x2eeb39], _0x10e0b6 = _0x3adfd7[_0xd5fe69] || _0x1ccef4;
            _0x1ccef4['__proto__'] = _0x468a2a['bind'](_0x468a2a), _0x1ccef4['toString'] = _0x10e0b6['toString']['bind'](_0x10e0b6), _0x3adfd7[_0xd5fe69] = _0x1ccef4;
        }
    });
_0x29d170();
import {
    r as _0xa7068f,
    a as _0x499884
} from './Request-CHKnUlo5.js';
import { E as _0x40cde3 } from './el-empty-o9RgIX3C.js';
import { E as _0x5d490c } from './el-skeleton-item-BG_lS1DD.js';
import {
    _ as _0xf3e2d6,
    r as _0x62fe78,
    o as _0xf75347,
    c,
    g as _0x41d5ea,
    d as _0x1e82b4,
    f as _0x1e8ab3,
    i as _0x18a5d1,
    F as _0x2910cd,
    G as _0x59bc0d,
    k as _0x32fc86,
    t as _0x3e83ae,
    u as _0x7323b4,
    b as _0x3f8452,
    m as _0x3d8097,
    H as _0x53328f,
    I as _0x3b4ca9,
    J as _0x2c38d1,
    K as _0x2abae5,
    L as _0x2ff003,
    z as _0x5bac49,
    e as _0x435e73,
    M as _0x12b04c,
    v as _0x25e9e0,
    N as _0x38b992,
    j as _0x3ae8d7,
    O as _0x2a994d,
    P as _0x1f7f53,
    h as _0x23b9d
} from './index-54DmW9hq.js';
import { E as _0x2749a0 } from './el-image-viewer-DAjDHmiI.js';
import {
    g as _0x2d96e5,
    a as _0xe584cd
} from './article-IrYQ22on.js';
import './aria-DyaK1nXM.js';
import './focus-trap-Cbj9GFlW.js';
import './index-BLYrTdqd.js';
import './toNumber-DGNxa_rg.js';
import './index-ijNW1fhk.js';
import './scroll-DDB7nuLj.js';
function ct() {
    return _0xa7068f({
        'url': '/visitorLog/today/count',
        'method': 'get'
    });
}
const _t = { 'class': 'home' }, vt = { 'class': 'page-container' }, pt = { 'class': 'left-nav' }, ft = { 'class': 'main' }, mt = { 'class': 'stats' }, ht = { 'class': 'card-top' }, gt = { 'class': 'label' }, yt = { 'class': 'value' }, kt = { 'class': 'hot-topics' }, bt = { 'class': 'section-header' }, Ct = { 'class': 'hot-grid' }, xt = ['onClick'], wt = { 'class': 'image-placeholder' }, Lt = { 'class': 'image-error' }, Et = { 'class': 'hot-info' }, Nt = { 'class': 'hot-title' }, Vt = { 'class': 'hot-meta' }, Dt = { 'class': 'latest' }, It = { 'key': 0x0 }, St = { 'key': 0x1 }, Ut = { 'class': 'post-main' }, At = { 'class': 'post-title' }, zt = { 'class': 'post-desc' }, Tt = { 'class': 'post-meta' }, $t = ['onClick'], Bt = { 'class': 'thumb-error' }, Ft = {
        'key': 0x0,
        'class': 'empty'
    }, Ht = { 'class': 'site-footer' }, Rt = { 'class': 'footer-inner' }, Mt = { 'class': 'links' }, Ot = { 'class': 'copyright' }, Pt = {
        '__name': 'index',
        'setup'(_0x1e5bf7) {
            const _0x3e330b = _0x7323b4(), _0x40dfa4 = _0x62fe78([]), _0x5788c5 = _0x62fe78([]), _0x5498fb = _0x62fe78(!0x1), _0x4cc6b4 = _0x62fe78(new Date()['getFullYear']()), _0x5dd382 = _0x62fe78([
                    {
                        'key': 'posts',
                        'label': '总帖子数',
                        'value': 0x0,
                        'icon': 'Document',
                        'color': 'c1',
                        'trend': {
                            'value': 0x0,
                            'up': !0x0,
                            'label': '较上周'
                        }
                    },
                    {
                        'key': 'registered',
                        'label': '注册用户',
                        'value': 0x0,
                        'icon': 'User',
                        'color': 'c2',
                        'trend': {
                            'value': 0x0,
                            'up': !0x0,
                            'label': '较上周'
                        }
                    },
                    {
                        'key': 'online',
                        'label': '在线用户',
                        'value': 0x0,
                        'icon': 'User',
                        'color': 'c3',
                        'trend': {
                            'value': 0x0,
                            'up': !0x0,
                            'label': '较昨日'
                        }
                    },
                    {
                        'key': 'visits',
                        'label': '今日访问',
                        'value': 0x0,
                        'icon': 'View',
                        'color': 'c4',
                        'trend': {
                            'value': 0x0,
                            'up': !0x1,
                            'label': '较昨日'
                        }
                    }
                ]), _0x3fc198 = async () => {
                    var _0x369869, _0x2697f8, _0x5c294d, _0x356002;
                    try {
                        _0x5498fb['value'] = !0x0;
                        const _0x2e5436 = await _0x2d96e5(0x1, 0xa), _0x27cb32 = ((_0x2697f8 = (_0x369869 = _0x2e5436 == null ? void 0x0 : _0x2e5436['data']) == null ? void 0x0 : _0x369869['data']) == null ? void 0x0 : _0x2697f8['data']) || [];
                        _0x40dfa4['value'] = _0x27cb32;
                        const _0x94b980 = ((_0x356002 = (_0x5c294d = _0x2e5436 == null ? void 0x0 : _0x2e5436['data']) == null ? void 0x0 : _0x5c294d['data']) == null ? void 0x0 : _0x356002['total']) || _0x27cb32['length'];
                        _0x379324('posts', _0x94b980), _0x339123('posts', {
                            'value': 0xc,
                            'up': !0x0,
                            'label': '较上周'
                        });
                    } finally {
                        _0x5498fb['value'] = !0x1;
                    }
                }, _0x4929b3 = async () => {
                    var _0x228d42, _0x56819f;
                    const _0x663c95 = await _0xe584cd(0x1, 0x4);
                    _0x5788c5['value'] = ((_0x56819f = (_0x228d42 = _0x663c95 == null ? void 0x0 : _0x663c95['data']) == null ? void 0x0 : _0x228d42['data']) == null ? void 0x0 : _0x56819f['data']) || [];
                }, _0x270ec6 = async () => {
                    var _0x4188d1;
                    try {
                        const _0x3666ec = await ct();
                        _0x379324('visits', ((_0x4188d1 = _0x3666ec == null ? void 0x0 : _0x3666ec['data']) == null ? void 0x0 : _0x4188d1['data']) || 0x0), _0x339123('visits', {
                            'value': -0x3,
                            'up': !0x1,
                            'label': '较昨日'
                        });
                    } catch {
                    }
                }, _0x379324 = (_0x2e41a0, _0x2a46c7) => {
                    const _0x2309e5 = _0x5dd382['value']['findIndex'](_0x4f5d07 => _0x4f5d07['key'] === _0x2e41a0);
                    _0x2309e5 !== -0x1 && (_0x5dd382['value'][_0x2309e5]['value'] = _0x2a46c7);
                }, _0x339123 = (_0x36a186, _0x32f0ee) => {
                    const _0x247096 = _0x5dd382['value']['findIndex'](_0x3186a9 => _0x3186a9['key'] === _0x36a186);
                    _0x247096 !== -0x1 && (_0x5dd382['value'][_0x247096]['trend'] = _0x32f0ee);
                }, _0x4bbea6 = async () => {
                    _0x379324('registered', 0x162e), _0x339123('registered', {
                        'value': 0x8,
                        'up': !0x0,
                        'label': '较上周'
                    });
                }, _0x5146dd = async () => {
                    _0x379324('online', 0x156), _0x339123('online', {
                        'value': 0x5,
                        'up': !0x0,
                        'label': '较昨日'
                    });
                }, _0x1cd7d9 = _0x3d7fac => _0x3d7fac ? new Date(_0x3d7fac)['toLocaleDateString']('zh-CN', {
                    'year': 'numeric',
                    'month': '2-digit',
                    'day': '2-digit'
                }) : '', _0x2973cd = _0xeaf1f6 => '/user/' + _0xeaf1f6['userId'] + '/article/' + _0xeaf1f6['id'], _0x2e01c4 = _0x5b2113 => _0x3e330b['push'](_0x2973cd(_0x5b2113));
            _0xf75347(async () => {
                await Promise['all']([
                    _0x3fc198(),
                    _0x4929b3(),
                    _0x270ec6(),
                    _0x4bbea6(),
                    _0x5146dd()
                ]);
            });
            const _0x5badcf = _0x418931 => Number(_0x418931 || 0x0)['toLocaleString']('zh-CN'), _0x6f9747 = _0x3f6109 => {
                    const _0x32b7fc = (_0x3f6109 == null ? void 0x0 : _0x3f6109['coverUrl']) || '';
                    if (_0x32b7fc)
                        return _0x32b7fc;
                    const _0x505da8 = ((_0x3f6109 == null ? void 0x0 : _0x3f6109['content']) || '')['match'](/<img[^>]+src=["']([^"']+)["']/i);
                    return (_0x505da8 == null ? void 0x0 : _0x505da8[0x1]) || '';
                };
            return (_0x3b6c7e, _0x3c63ea) => {
                const _0x15767d = _0x499884, _0x5d83f0 = _0x18a5d1('router-link'), _0x27463e = _0x2749a0, _0x36c245 = _0x23b9d, _0x476dff = _0x5d490c, _0x452436 = _0x18a5d1('Star'), _0xdf741a = _0x40cde3;
                return _0x3f8452(), c('div', _t, [
                    _0x41d5ea('div', vt, [
                        _0x41d5ea('aside', pt, [_0x41d5ea('nav', null, [
                                _0x1e82b4(_0x5d83f0, {
                                    'to': '/',
                                    'class': 'nav-item',
                                    'exact-active-class': 'active'
                                }, {
                                    'default': _0x1e8ab3(() => [
                                        _0x3c63ea[0x0] || (_0x3c63ea[0x0] = _0x41d5ea('div', { 'class': 'item-decorate' }, null, -0x1)),
                                        _0x1e82b4(_0x15767d, null, {
                                            'default': _0x1e8ab3(() => [_0x1e82b4(_0x3d8097(_0x53328f))]),
                                            '_': 0x1
                                        }),
                                        _0x3c63ea[0x1] || (_0x3c63ea[0x1] = _0x41d5ea('span', null, '主页', -0x1))
                                    ]),
                                    '_': 0x1,
                                    '__': [
                                        0x0,
                                        0x1
                                    ]
                                }),
                                _0x1e82b4(_0x5d83f0, {
                                    'to': '/article',
                                    'class': 'nav-item'
                                }, {
                                    'default': _0x1e8ab3(() => [
                                        _0x3c63ea[0x2] || (_0x3c63ea[0x2] = _0x41d5ea('div', { 'class': 'item-decorate' }, null, -0x1)),
                                        _0x1e82b4(_0x15767d, null, {
                                            'default': _0x1e8ab3(() => [_0x1e82b4(_0x3d8097(_0x3b4ca9))]),
                                            '_': 0x1
                                        }),
                                        _0x3c63ea[0x3] || (_0x3c63ea[0x3] = _0x41d5ea('span', null, '热门话题', -0x1))
                                    ]),
                                    '_': 0x1,
                                    '__': [
                                        0x2,
                                        0x3
                                    ]
                                }),
                                _0x1e82b4(_0x5d83f0, {
                                    'to': '/creation',
                                    'class': 'nav-item'
                                }, {
                                    'default': _0x1e8ab3(() => [
                                        _0x3c63ea[0x4] || (_0x3c63ea[0x4] = _0x41d5ea('div', { 'class': 'item-decorate' }, null, -0x1)),
                                        _0x1e82b4(_0x15767d, null, {
                                            'default': _0x1e8ab3(() => [_0x1e82b4(_0x3d8097(_0x2c38d1))]),
                                            '_': 0x1
                                        }),
                                        _0x3c63ea[0x5] || (_0x3c63ea[0x5] = _0x41d5ea('span', null, '创作中心', -0x1))
                                    ]),
                                    '_': 0x1,
                                    '__': [
                                        0x4,
                                        0x5
                                    ]
                                }),
                                _0x1e82b4(_0x5d83f0, {
                                    'to': '/editor',
                                    'class': 'nav-item'
                                }, {
                                    'default': _0x1e8ab3(() => [
                                        _0x3c63ea[0x6] || (_0x3c63ea[0x6] = _0x41d5ea('div', { 'class': 'item-decorate' }, null, -0x1)),
                                        _0x1e82b4(_0x15767d, null, {
                                            'default': _0x1e8ab3(() => [_0x1e82b4(_0x3d8097(_0x2abae5))]),
                                            '_': 0x1
                                        }),
                                        _0x3c63ea[0x7] || (_0x3c63ea[0x7] = _0x41d5ea('span', null, '发布文章', -0x1))
                                    ]),
                                    '_': 0x1,
                                    '__': [
                                        0x6,
                                        0x7
                                    ]
                                }),
                                _0x1e82b4(_0x5d83f0, {
                                    'to': '/about',
                                    'class': 'nav-item'
                                }, {
                                    'default': _0x1e8ab3(() => [
                                        _0x3c63ea[0x8] || (_0x3c63ea[0x8] = _0x41d5ea('div', { 'class': 'item-decorate' }, null, -0x1)),
                                        _0x1e82b4(_0x15767d, null, {
                                            'default': _0x1e8ab3(() => [_0x1e82b4(_0x3d8097(_0x2ff003))]),
                                            '_': 0x1
                                        }),
                                        _0x3c63ea[0x9] || (_0x3c63ea[0x9] = _0x41d5ea('span', null, '关于论坛', -0x1))
                                    ]),
                                    '_': 0x1,
                                    '__': [
                                        0x8,
                                        0x9
                                    ]
                                })
                            ])]),
                        _0x41d5ea('main', ft, [
                            _0x3c63ea[0xd] || (_0x3c63ea[0xd] = _0x41d5ea('section', { 'class': 'welcome-banner' }, [
                                _0x41d5ea('div', { 'class': 'title' }, '欢迎来到云论坛'),
                                _0x41d5ea('div', { 'class': 'desc' }, '这里是技术交流与分享的社区，点击右上角的铃铛查看更多消息。')
                            ], -0x1)),
                            _0x41d5ea('section', mt, [(_0x3f8452(!0x0), c(_0x2910cd, null, _0x59bc0d(_0x5dd382['value'], _0x3e75f3 => (_0x3f8452(), c('div', {
                                    'class': 'stat-card',
                                    'key': _0x3e75f3['key']
                                }, [
                                    _0x41d5ea('div', ht, [
                                        _0x41d5ea('div', gt, _0x3e83ae(_0x3e75f3['label']), 0x1),
                                        _0x41d5ea('div', {
                                            'class': _0x5bac49([
                                                'icon',
                                                _0x3e75f3['color']
                                            ])
                                        }, [_0x3e75f3['icon'] === 'View' ? (_0x3f8452(), _0x435e73(_0x15767d, { 'key': 0x0 }, {
                                                'default': _0x1e8ab3(() => [_0x1e82b4(_0x3d8097(_0x12b04c))]),
                                                '_': 0x1
                                            })) : _0x3e75f3['icon'] === 'User' ? (_0x3f8452(), _0x435e73(_0x15767d, { 'key': 0x1 }, {
                                                'default': _0x1e8ab3(() => [_0x1e82b4(_0x3d8097(_0x25e9e0))]),
                                                '_': 0x1
                                            })) : (_0x3f8452(), _0x435e73(_0x15767d, { 'key': 0x2 }, {
                                                'default': _0x1e8ab3(() => [_0x1e82b4(_0x3d8097(_0x38b992))]),
                                                '_': 0x1
                                            }))], 0x2)
                                    ]),
                                    _0x41d5ea('div', yt, _0x3e83ae(_0x5badcf(_0x3e75f3['value'])), 0x1)
                                ]))), 0x80))]),
                            _0x41d5ea('section', kt, [
                                _0x41d5ea('div', bt, [
                                    _0x3c63ea[0xb] || (_0x3c63ea[0xb] = _0x41d5ea('h3', null, '热门话题', -0x1)),
                                    _0x1e82b4(_0x5d83f0, {
                                        'to': '/article',
                                        'class': 'more'
                                    }, {
                                        'default': _0x1e8ab3(() => _0x3c63ea[0xa] || (_0x3c63ea[0xa] = [_0x3ae8d7('全部')])),
                                        '_': 0x1,
                                        '__': [0xa]
                                    })
                                ]),
                                _0x41d5ea('div', Ct, [(_0x3f8452(!0x0), c(_0x2910cd, null, _0x59bc0d(_0x5788c5['value'], _0x518009 => (_0x3f8452(), c('div', {
                                        'class': 'hot-card',
                                        'key': _0x518009['id'],
                                        'onClick': _0x3afd83 => _0x2e01c4(_0x518009)
                                    }, [
                                        _0x1e82b4(_0x27463e, {
                                            'src': _0x6f9747(_0x518009),
                                            'fit': 'cover',
                                            'lazy': ''
                                        }, {
                                            'placeholder': _0x1e8ab3(() => [_0x41d5ea('div', wt, [_0x1e82b4(_0x15767d, { 'class': 'is-loading' }, {
                                                        'default': _0x1e8ab3(() => [_0x1e82b4(_0x3d8097(_0x1f7f53))]),
                                                        '_': 0x1
                                                    })])]),
                                            'error': _0x1e8ab3(() => [_0x41d5ea('div', Lt, [_0x1e82b4(_0x15767d, null, {
                                                        'default': _0x1e8ab3(() => [_0x1e82b4(_0x3d8097(_0x2a994d))]),
                                                        '_': 0x1
                                                    })])]),
                                            '_': 0x2
                                        }, 0x408, ['src']),
                                        _0x41d5ea('div', Et, [
                                            _0x41d5ea('div', Nt, _0x3e83ae(_0x518009['title']), 0x1),
                                            _0x41d5ea('div', Vt, [
                                                _0x41d5ea('span', null, [
                                                    _0x1e82b4(_0x15767d, null, {
                                                        'default': _0x1e8ab3(() => [_0x1e82b4(_0x3d8097(_0x12b04c))]),
                                                        '_': 0x1
                                                    }),
                                                    _0x3ae8d7(_0x3e83ae(_0x518009['readCount'] || 0x0), 0x1)
                                                ]),
                                                _0x41d5ea('span', null, [
                                                    _0x1e82b4(_0x36c245, {
                                                        'name': 'like',
                                                        'width': '13px',
                                                        'height': '13px'
                                                    }),
                                                    _0x3ae8d7(_0x3e83ae(_0x518009['likeCount'] || 0x0), 0x1)
                                                ])
                                            ])
                                        ])
                                    ], 0x8, xt))), 0x80))])
                            ]),
                            _0x41d5ea('section', Dt, [
                                _0x3c63ea[0xc] || (_0x3c63ea[0xc] = _0x41d5ea('div', { 'class': 'section-header' }, [_0x41d5ea('h3', null, '最新动态')], -0x1)),
                                _0x5498fb['value'] ? (_0x3f8452(), c('div', It, [_0x1e82b4(_0x476dff, {
                                        'animated': '',
                                        'count': 0x4
                                    })])) : (_0x3f8452(), c('div', St, [
                                    (_0x3f8452(!0x0), c(_0x2910cd, null, _0x59bc0d(_0x40dfa4['value'], _0x1ca1b9 => (_0x3f8452(), c('div', {
                                        'class': 'post-item',
                                        'key': _0x1ca1b9['id']
                                    }, [
                                        _0x41d5ea('div', Ut, [
                                            _0x41d5ea('div', At, [_0x1e82b4(_0x5d83f0, { 'to': _0x2973cd(_0x1ca1b9) }, {
                                                    'default': _0x1e8ab3(() => [_0x3ae8d7(_0x3e83ae(_0x1ca1b9['title']), 0x1)]),
                                                    '_': 0x2
                                                }, 0x408, ['to'])]),
                                            _0x41d5ea('div', zt, _0x3e83ae(_0x1ca1b9['description'] || '这是一篇没有描述的文章'), 0x1),
                                            _0x41d5ea('div', Tt, [
                                                _0x41d5ea('span', null, _0x3e83ae(_0x1cd7d9(_0x1ca1b9['createTime'])), 0x1),
                                                _0x41d5ea('span', null, [
                                                    _0x1e82b4(_0x15767d, null, {
                                                        'default': _0x1e8ab3(() => [_0x1e82b4(_0x3d8097(_0x12b04c))]),
                                                        '_': 0x1
                                                    }),
                                                    _0x3ae8d7(_0x3e83ae(_0x1ca1b9['readCount'] || 0x0), 0x1)
                                                ]),
                                                _0x41d5ea('span', null, [
                                                    _0x1e82b4(_0x36c245, {
                                                        'name': 'like',
                                                        'width': '13px',
                                                        'height': '13px'
                                                    }),
                                                    _0x3ae8d7(_0x3e83ae(_0x1ca1b9['likeCount'] || 0x0), 0x1)
                                                ]),
                                                _0x41d5ea('span', null, [
                                                    _0x1e82b4(_0x15767d, null, {
                                                        'default': _0x1e8ab3(() => [_0x1e82b4(_0x452436)]),
                                                        '_': 0x1
                                                    }),
                                                    _0x3ae8d7(_0x3e83ae(_0x1ca1b9['collectCount'] || 0x0), 0x1)
                                                ])
                                            ])
                                        ]),
                                        _0x41d5ea('div', {
                                            'class': 'post-thumb',
                                            'onClick': _0x2c2bec => _0x2e01c4(_0x1ca1b9)
                                        }, [_0x1e82b4(_0x27463e, {
                                                'src': _0x1ca1b9['coverUrl'],
                                                'fit': 'cover'
                                            }, {
                                                'error': _0x1e8ab3(() => [_0x41d5ea('div', Bt, [_0x1e82b4(_0x15767d, null, {
                                                            'default': _0x1e8ab3(() => [_0x1e82b4(_0x3d8097(_0x2a994d))]),
                                                            '_': 0x1
                                                        })])]),
                                                '_': 0x2
                                            }, 0x408, ['src'])], 0x8, $t)
                                    ]))), 0x80)),
                                    _0x40dfa4['value']['length'] === 0x0 ? (_0x3f8452(), c('div', Ft, [_0x1e82b4(_0xdf741a, { 'description': '暂无内容' })])) : _0x32fc86('', !0x0)
                                ]))
                            ])
                        ])
                    ]),
                    _0x41d5ea('footer', Ht, [_0x41d5ea('div', Rt, [
                            _0x41d5ea('div', Mt, [
                                _0x1e82b4(_0x5d83f0, { 'to': '/about' }, {
                                    'default': _0x1e8ab3(() => _0x3c63ea[0xe] || (_0x3c63ea[0xe] = [_0x3ae8d7('关于我们')])),
                                    '_': 0x1,
                                    '__': [0xe]
                                }),
                                _0x3c63ea[0x11] || (_0x3c63ea[0x11] = _0x41d5ea('span', null, '·', -0x1)),
                                _0x1e82b4(_0x5d83f0, { 'to': '/link' }, {
                                    'default': _0x1e8ab3(() => _0x3c63ea[0xf] || (_0x3c63ea[0xf] = [_0x3ae8d7('友情链接')])),
                                    '_': 0x1,
                                    '__': [0xf]
                                }),
                                _0x3c63ea[0x12] || (_0x3c63ea[0x12] = _0x41d5ea('span', null, '·', -0x1)),
                                _0x1e82b4(_0x5d83f0, { 'to': '/creation' }, {
                                    'default': _0x1e8ab3(() => _0x3c63ea[0x10] || (_0x3c63ea[0x10] = [_0x3ae8d7('服务条款')])),
                                    '_': 0x1,
                                    '__': [0x10]
                                })
                            ]),
                            _0x41d5ea('div', Ot, '©\x20' + _0x3e83ae(_0x4cc6b4['value']) + '\x20云论坛\x20CloudScript', 0x1)
                        ])])
                ]);
            };
        }
    }, oe = _0xf3e2d6(Pt, [[
            '__scopeId',
            'data-v-9c4f5aa3'
        ]]);
export {
    oe as default
};