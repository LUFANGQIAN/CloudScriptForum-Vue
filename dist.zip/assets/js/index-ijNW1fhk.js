const _0x47a8f0 = (function () {
        let _0xb4ddfc = !![];
        return function (_0x3fee20, _0x2ece9b) {
            const _0x525fa8 = _0xb4ddfc ? function () {
                if (_0x2ece9b) {
                    const _0xddb8ad = _0x2ece9b['apply'](_0x3fee20, arguments);
                    return _0x2ece9b = null, _0xddb8ad;
                }
            } : function () {
            };
            return _0xb4ddfc = ![], _0x525fa8;
        };
    }()), _0x38b77d = _0x47a8f0(this, function () {
        let _0x12b199;
        try {
            const _0x333d64 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x12b199 = _0x333d64();
        } catch (_0x51c158) {
            _0x12b199 = window;
        }
        const _0x9e6438 = _0x12b199['console'] = _0x12b199['console'] || {}, _0x220ab0 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x55f636 = 0x0; _0x55f636 < _0x220ab0['length']; _0x55f636++) {
            const _0x186ab9 = _0x47a8f0['constructor']['prototype']['bind'](_0x47a8f0), _0x5738b6 = _0x220ab0[_0x55f636], _0x4c4ff2 = _0x9e6438[_0x5738b6] || _0x186ab9;
            _0x186ab9['__proto__'] = _0x47a8f0['bind'](_0x47a8f0), _0x186ab9['toString'] = _0x4c4ff2['toString']['bind'](_0x4c4ff2), _0x9e6438[_0x5738b6] = _0x186ab9;
        }
    });
_0x38b77d();
import { ai as _0x16eb68 } from './Request-CHKnUlo5.js';
import {
    Y as _0x44f03f,
    aF as _0x19ed07
} from './index-54DmW9hq.js';
const i = [
        'class',
        'style'
    ], E = /^on[A-Z]/, m = (_0x41b960 = {}) => {
        const {
                excludeListeners: _0x34bb52 = !0x1,
                excludeKeys: _0x176101
            } = _0x41b960, _0x24b560 = _0x44f03f(() => ((_0x176101 == null ? void 0x0 : _0x176101['value']) || [])['concat'](i)), _0x3b2ee8 = _0x19ed07();
        return _0x3b2ee8 ? _0x44f03f(() => {
            var _0x44c8f1;
            return _0x16eb68(Object['entries']((_0x44c8f1 = _0x3b2ee8['proxy']) == null ? void 0x0 : _0x44c8f1['$attrs'])['filter'](([_0x1ca655]) => !_0x24b560['value']['includes'](_0x1ca655) && !(_0x34bb52 && E['test'](_0x1ca655))));
        }) : _0x44f03f(() => ({}));
    };
export {
    m as u
};