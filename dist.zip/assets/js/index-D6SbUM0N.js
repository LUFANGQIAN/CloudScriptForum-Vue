const _0x1a195e = (function () {
        let _0x1e44df = !![];
        return function (_0x214548, _0x2c055b) {
            const _0x34bc50 = _0x1e44df ? function () {
                if (_0x2c055b) {
                    const _0x20fc58 = _0x2c055b['apply'](_0x214548, arguments);
                    return _0x2c055b = null, _0x20fc58;
                }
            } : function () {
            };
            return _0x1e44df = ![], _0x34bc50;
        };
    }()), _0x1cc4e9 = _0x1a195e(this, function () {
        let _0x28d37e;
        try {
            const _0x121780 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x28d37e = _0x121780();
        } catch (_0x5deccd) {
            _0x28d37e = window;
        }
        const _0x3469c3 = _0x28d37e['console'] = _0x28d37e['console'] || {}, _0x226e47 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x3eb992 = 0x0; _0x3eb992 < _0x226e47['length']; _0x3eb992++) {
            const _0x4fcf2b = _0x1a195e['constructor']['prototype']['bind'](_0x1a195e), _0x3bb659 = _0x226e47[_0x3eb992], _0x34eb22 = _0x3469c3[_0x3bb659] || _0x4fcf2b;
            _0x4fcf2b['__proto__'] = _0x1a195e['bind'](_0x1a195e), _0x4fcf2b['toString'] = _0x34eb22['toString']['bind'](_0x34eb22), _0x3469c3[_0x3bb659] = _0x4fcf2b;
        }
    });
_0x1cc4e9();
import {
    _ as _0x1ee70f,
    c as _0x1f4770,
    e as _0x51d994,
    w as _0x57e0c9,
    L as _0x401f90,
    u as _0x3f75cb,
    a as _0x154563
} from './Request-CHKnUlo5.js';
import {
    a as _0x28d9bd,
    E as _0x275f59,
    b as _0x2b6350
} from './el-menu-item-KBCZyWt_.js';
import './el-tooltip-l0sNRNKZ.js';
import './el-scrollbar-BcrgDlEt.js';
import './el-button-D6wSrR74.js';
import {
    E as _0x4bd770,
    a as _0x24ac22,
    b as _0x5eed2d
} from './el-dropdown-item-CXWV75Wk.js';
import { E as _0x231839 } from './el-avatar-D7H8d9zq.js';
import { E as _0x104edd } from './el-text-CbMl16cr.js';
import {
    X as _0x5bb634,
    ap as _0x1d4c56,
    Y as _0x33a765,
    c as _0x23720a,
    b as _0x576e7f,
    a2 as _0x3d76b2,
    z as _0xfd2561,
    m as _0x1a2887,
    $ as _0x2d4cb6,
    _ as _0x35ad54,
    s as _0xc71105,
    u as _0x5a4b1c,
    r as _0x6d0f31,
    o as _0x5263ba,
    d as _0x594501,
    e as _0x59b2fc,
    f as _0x47c9f0,
    g as _0x14d71c,
    h as _0x591a60,
    j as _0x3a32b3,
    t as _0x3ee6e0,
    q as _0x452338,
    A as _0x2c72c5,
    C as _0x1999ce,
    ae as _0x19f60d,
    H as _0x1f6a06,
    aO as _0x1ccdd3,
    aP as _0x51e988,
    B as _0x2c44b1,
    T as _0x3c8493,
    D as _0x3021f4,
    F as _0x4e9da8,
    E as _0x5e7cc3,
    w as _0x26ae10,
    i as _0x5e01d2,
    aQ as _0x2cf171
} from './index-54DmW9hq.js';
import { D as _0x106373 } from './Dark-8xrz-9yO.js';
import { i as _0x4e5215 } from './user-BDWxAMXB.js';
import './aria-DyaK1nXM.js';
import './index-DMxv2JmO.js';
import './index-CuE0nMtH.js';
import './vnode-C3QoD07S.js';
import './index-BLYrTdqd.js';
import './index-BOok6G7G.js';
import './focus-trap-Cbj9GFlW.js';
import './castArray-BGw1D6E-.js';
import './refs-mENLc3Ek.js';
const ze = _0x5bb634({ 'name': 'ElContainer' }), Ve = _0x5bb634({
        ...ze,
        'props': _0x1f4770({
            'direction': {
                'type': String,
                'values': [
                    'horizontal',
                    'vertical'
                ]
            }
        }),
        'setup'(_0x3f76f0) {
            const _0x2a93f5 = _0x3f76f0, _0x740e0f = _0x1d4c56(), _0xe4ada3 = _0x51d994('container'), _0x35cd06 = _0x33a765(() => _0x2a93f5['direction'] === 'vertical' ? !0x0 : _0x2a93f5['direction'] === 'horizontal' ? !0x1 : _0x740e0f && _0x740e0f['default'] ? _0x740e0f['default']()['some'](_0x44b57f => {
                    const _0x1ccedd = _0x44b57f['type']['name'];
                    return _0x1ccedd === 'ElHeader' || _0x1ccedd === 'ElFooter';
                }) : !0x1);
            return (_0x1f9b08, _0x563edf) => (_0x576e7f(), _0x23720a('section', {
                'class': _0xfd2561([
                    _0x1a2887(_0xe4ada3)['b'](),
                    _0x1a2887(_0xe4ada3)['is']('vertical', _0x1a2887(_0x35cd06))
                ])
            }, [_0x3d76b2(_0x1f9b08['$slots'], 'default')], 0x2));
        }
    });
var Be = _0x1ee70f(Ve, [[
        '__file',
        'container.vue'
    ]]);
const De = _0x5bb634({ 'name': 'ElAside' }), Te = _0x5bb634({
        ...De,
        'props': {
            'width': {
                'type': String,
                'default': null
            }
        },
        'setup'(_0x2ceafb) {
            const _0x40b796 = _0x2ceafb, _0x5ef571 = _0x51d994('aside'), _0x320497 = _0x33a765(() => _0x40b796['width'] ? _0x5ef571['cssVarBlock']({ 'width': _0x40b796['width'] }) : {});
            return (_0x12c917, _0x4d6aa4) => (_0x576e7f(), _0x23720a('aside', {
                'class': _0xfd2561(_0x1a2887(_0x5ef571)['b']()),
                'style': _0x2d4cb6(_0x1a2887(_0x320497))
            }, [_0x3d76b2(_0x12c917['$slots'], 'default')], 0x6));
        }
    });
var G = _0x1ee70f(Te, [[
        '__file',
        'aside.vue'
    ]]);
const Ae = _0x5bb634({ 'name': 'ElFooter' }), He = _0x5bb634({
        ...Ae,
        'props': {
            'height': {
                'type': String,
                'default': null
            }
        },
        'setup'(_0x2fb88c) {
            const _0xa13bc1 = _0x2fb88c, _0x43066e = _0x51d994('footer'), _0x4596be = _0x33a765(() => _0xa13bc1['height'] ? _0x43066e['cssVarBlock']({ 'height': _0xa13bc1['height'] }) : {});
            return (_0x5dd936, _0x62d9a) => (_0x576e7f(), _0x23720a('footer', {
                'class': _0xfd2561(_0x1a2887(_0x43066e)['b']()),
                'style': _0x2d4cb6(_0x1a2887(_0x4596be))
            }, [_0x3d76b2(_0x5dd936['$slots'], 'default')], 0x6));
        }
    });
var J = _0x1ee70f(He, [[
        '__file',
        'footer.vue'
    ]]);
const Ne = _0x5bb634({ 'name': 'ElHeader' }), Fe = _0x5bb634({
        ...Ne,
        'props': {
            'height': {
                'type': String,
                'default': null
            }
        },
        'setup'(_0x165e7a) {
            const _0x2be5cf = _0x165e7a, _0x43ce48 = _0x51d994('header'), _0x4cb70f = _0x33a765(() => _0x2be5cf['height'] ? _0x43ce48['cssVarBlock']({ 'height': _0x2be5cf['height'] }) : {});
            return (_0x1286f7, _0x9d0b4c) => (_0x576e7f(), _0x23720a('header', {
                'class': _0xfd2561(_0x1a2887(_0x43ce48)['b']()),
                'style': _0x2d4cb6(_0x1a2887(_0x4cb70f))
            }, [_0x3d76b2(_0x1286f7['$slots'], 'default')], 0x6));
        }
    });
var K = _0x1ee70f(Fe, [[
        '__file',
        'header.vue'
    ]]);
const Ue = _0x5bb634({ 'name': 'ElMain' }), Pe = _0x5bb634({
        ...Ue,
        'setup'(_0x39864e) {
            const _0x1fc2a7 = _0x51d994('main');
            return (_0x1b1976, _0x3fbf84) => (_0x576e7f(), _0x23720a('main', { 'class': _0xfd2561(_0x1a2887(_0x1fc2a7)['b']()) }, [_0x3d76b2(_0x1b1976['$slots'], 'default')], 0x2));
        }
    });
var W = _0x1ee70f(Pe, [[
        '__file',
        'main.vue'
    ]]);
const Re = _0x57e0c9(Be, {
        'Aside': G,
        'Footer': J,
        'Header': K,
        'Main': W
    }), Le = _0x401f90(G);
_0x401f90(J);
const je = _0x401f90(K), qe = _0x401f90(W), Oe = {
        'class': 'logo',
        'href': '/'
    }, Qe = { 'href': '/creation' }, Xe = { 'class': 'right' }, Ye = {
        'key': 0x0,
        'class': 'user-info'
    }, Ge = {
        '__name': 'CreationHeader',
        'setup'(_0x308884) {
            const _0x3b9fb7 = _0x3f75cb(), {user: _0x2d7cf4} = _0xc71105(_0x3b9fb7), _0x21c651 = _0x5a4b1c(), _0x47179f = _0x6d0f31(!0x0), _0x4c8245 = _0x6d0f31('/creation');
            _0x21c651['afterEach'](_0x31f18a => {
                _0x4c8245['value'] = _0x31f18a['path'];
            });
            const _0x17a683 = _0xa807b6 => {
                    _0x21c651['push'](_0xa807b6);
                }, _0x3ccabe = () => {
                    _0x21c651['push']({ 'name': 'Account' });
                }, _0x210f85 = async () => {
                    const _0x171d4f = await _0x4e5215();
                    _0x2d7cf4['value'] = _0x171d4f['data']['data'];
                }, _0x22af8c = () => {
                    _0x3b9fb7['clearUser']();
                }, _0x423481 = () => {
                    location['href'] = '/user/' + _0x2d7cf4['value']['id'];
                }, _0x38d869 = () => {
                    window['location']['href'] = '/setting';
                }, _0x4c37f8 = _0x6d0f31(!0x1), _0x45d0ea = () => {
                    _0x4c37f8['value'] = !_0x4c37f8['value'];
                }, _0x5adde0 = () => {
                    _0x4c37f8['value'] = !0x1;
                };
            return _0x5263ba(() => {
                _0x2d7cf4['value'] && _0x210f85();
            }), (_0x6bc6fd, _0x442c33) => {
                const _0x4706fa = _0x591a60, _0x38e2eb = _0x104edd, _0x3e2d37 = _0x231839, _0x2a52c6 = _0x5eed2d, _0x5dda93 = _0x24ac22, _0x19381c = _0x4bd770, _0x4301e3 = _0x28d9bd, _0x139e49 = _0x154563, _0xe1fd0e = _0x275f59, _0x274f1f = _0x2b6350;
                return _0x576e7f(), _0x23720a(_0x4e9da8, null, [
                    _0x594501(_0x4301e3, {
                        'default-active': _0x4c8245['value'],
                        'router': '',
                        'class': _0xfd2561([
                            'pc-menu',
                            { 'hidden': !_0x47179f['value'] }
                        ]),
                        'mode': 'horizontal',
                        'onSelect': _0x17a683,
                        'ellipsis': !0x1
                    }, {
                        'default': _0x47c9f0(() => [
                            _0x14d71c('div', {
                                'class': 'mobile-menu-button',
                                'onClick': _0x45d0ea
                            }, [_0x594501(_0x4706fa, {
                                    'name': 'menu',
                                    'width': '50px',
                                    'height': '50px',
                                    'cursor': 'pointer'
                                })]),
                            _0x14d71c('a', Oe, [_0x594501(_0x38e2eb, {
                                    'size': 'large',
                                    'class': 'logo-text'
                                }, {
                                    'default': _0x47c9f0(() => _0x442c33[0x1] || (_0x442c33[0x1] = [_0x3a32b3('CloudScript')])),
                                    '_': 0x1,
                                    '__': [0x1]
                                })]),
                            _0x14d71c('a', Qe, [_0x594501(_0x38e2eb, { 'class': 'creation-center' }, {
                                    'default': _0x47c9f0(() => _0x442c33[0x2] || (_0x442c33[0x2] = [_0x3a32b3('创作中心')])),
                                    '_': 0x1,
                                    '__': [0x2]
                                })]),
                            _0x14d71c('div', Xe, [
                                _0x594501(_0x106373),
                                _0x1a2887(_0x2d7cf4) ? (_0x576e7f(), _0x23720a('div', Ye, [
                                    _0x594501(_0x38e2eb, {
                                        'size': 'large',
                                        'class': 'nickname'
                                    }, {
                                        'default': _0x47c9f0(() => [_0x3a32b3(_0x3ee6e0(_0x1a2887(_0x2d7cf4)['nickname']), 0x1)]),
                                        '_': 0x1
                                    }),
                                    _0x594501(_0x19381c, {
                                        'popper-options': {
                                            'modifiers': [{
                                                    'name': 'offset',
                                                    'options': {
                                                        'offset': [
                                                            -0x14,
                                                            0x8
                                                        ]
                                                    }
                                                }]
                                        }
                                    }, {
                                        'dropdown': _0x47c9f0(() => [_0x594501(_0x5dda93, null, {
                                                'default': _0x47c9f0(() => [
                                                    _0x594501(_0x2a52c6, { 'onClick': _0x423481 }, {
                                                        'default': _0x47c9f0(() => _0x442c33[0x3] || (_0x442c33[0x3] = [_0x3a32b3('个人主页')])),
                                                        '_': 0x1,
                                                        '__': [0x3]
                                                    }),
                                                    _0x594501(_0x2a52c6, { 'onClick': _0x38d869 }, {
                                                        'default': _0x47c9f0(() => _0x442c33[0x4] || (_0x442c33[0x4] = [_0x3a32b3('个人设置')])),
                                                        '_': 0x1,
                                                        '__': [0x4]
                                                    }),
                                                    _0x594501(_0x2a52c6, { 'onClick': _0x22af8c }, {
                                                        'default': _0x47c9f0(() => _0x442c33[0x5] || (_0x442c33[0x5] = [_0x3a32b3('退出登录')])),
                                                        '_': 0x1,
                                                        '__': [0x5]
                                                    })
                                                ]),
                                                '_': 0x1
                                            })]),
                                        'default': _0x47c9f0(() => [_0x1a2887(_0x2d7cf4)['avatar'] ? (_0x576e7f(), _0x59b2fc(_0x3e2d37, {
                                                'key': 0x0,
                                                'style': { 'cursor': 'pointer' },
                                                'size': 0x28,
                                                'src': _0x1a2887(_0x2d7cf4)['avatar']
                                            }, null, 0x8, ['src'])) : (_0x576e7f(), _0x59b2fc(_0x3e2d37, {
                                                'key': 0x1,
                                                'style': { 'cursor': 'pointer' },
                                                'size': 0x28,
                                                'icon': _0x1a2887(_0x452338)
                                            }, null, 0x8, ['icon']))]),
                                        '_': 0x1
                                    })
                                ])) : (_0x576e7f(), _0x23720a('div', {
                                    'key': 0x1,
                                    'class': 'login',
                                    'onClick': _0x3ccabe
                                }, '登录'))
                            ])
                        ]),
                        '_': 0x1
                    }, 0x8, [
                        'default-active',
                        'class'
                    ]),
                    (_0x576e7f(), _0x59b2fc(_0x3021f4, { 'to': 'body' }, [_0x594501(_0x3c8493, { 'name': 'slide-fade' }, {
                            'default': _0x47c9f0(() => [_0x2c72c5(_0x14d71c('div', {
                                    'class': 'mobile-menu-overlay',
                                    'onClick': _0x5adde0
                                }, [_0x594501(_0x4301e3, {
                                        'class': 'mobile-menu',
                                        'router': '',
                                        'onClick': _0x442c33[0x0] || (_0x442c33[0x0] = _0x1999ce(() => {
                                        }, ['stop'])),
                                        'onSelect': _0x5adde0,
                                        'default-openeds': ['/creation/manage']
                                    }, {
                                        'default': _0x47c9f0(() => [
                                            _0x594501(_0xe1fd0e, {
                                                'index': '/editor',
                                                'class': 'menu-item'
                                            }, {
                                                'default': _0x47c9f0(() => [
                                                    _0x594501(_0x139e49, null, {
                                                        'default': _0x47c9f0(() => [_0x594501(_0x1a2887(_0x19f60d))]),
                                                        '_': 0x1
                                                    }),
                                                    _0x442c33[0x6] || (_0x442c33[0x6] = _0x14d71c('span', { 'class': 'menu-text' }, '创作', -0x1))
                                                ]),
                                                '_': 0x1,
                                                '__': [0x6]
                                            }),
                                            _0x594501(_0xe1fd0e, {
                                                'index': '/',
                                                'class': 'menu-item'
                                            }, {
                                                'default': _0x47c9f0(() => [
                                                    _0x594501(_0x139e49, null, {
                                                        'default': _0x47c9f0(() => [_0x594501(_0x1a2887(_0x1f6a06))]),
                                                        '_': 0x1
                                                    }),
                                                    _0x442c33[0x7] || (_0x442c33[0x7] = _0x14d71c('span', { 'class': 'menu-text' }, '网站首页', -0x1))
                                                ]),
                                                '_': 0x1,
                                                '__': [0x7]
                                            }),
                                            _0x594501(_0xe1fd0e, {
                                                'index': '/creation',
                                                'class': 'menu-item'
                                            }, {
                                                'default': _0x47c9f0(() => [
                                                    _0x594501(_0x139e49, null, {
                                                        'default': _0x47c9f0(() => [_0x594501(_0x1a2887(_0x1ccdd3))]),
                                                        '_': 0x1
                                                    }),
                                                    _0x442c33[0x8] || (_0x442c33[0x8] = _0x14d71c('span', { 'class': 'menu-text' }, '创作首页', -0x1))
                                                ]),
                                                '_': 0x1,
                                                '__': [0x8]
                                            }),
                                            _0x594501(_0x274f1f, {
                                                'index': '/creation/manage',
                                                'class': 'menu-item'
                                            }, {
                                                'title': _0x47c9f0(() => [
                                                    _0x594501(_0x139e49, null, {
                                                        'default': _0x47c9f0(() => [_0x594501(_0x1a2887(_0x51e988))]),
                                                        '_': 0x1
                                                    }),
                                                    _0x442c33[0x9] || (_0x442c33[0x9] = _0x14d71c('span', { 'class': 'menu-text' }, '管理', -0x1))
                                                ]),
                                                'default': _0x47c9f0(() => [
                                                    _0x594501(_0xe1fd0e, { 'index': '/creation/articlemanage' }, {
                                                        'default': _0x47c9f0(() => _0x442c33[0xa] || (_0x442c33[0xa] = [_0x3a32b3('\x20内容管理\x20')])),
                                                        '_': 0x1,
                                                        '__': [0xa]
                                                    }),
                                                    _0x594501(_0xe1fd0e, { 'index': '/creation/columnmanage' }, {
                                                        'default': _0x47c9f0(() => _0x442c33[0xb] || (_0x442c33[0xb] = [_0x3a32b3('\x20专栏管理\x20')])),
                                                        '_': 0x1,
                                                        '__': [0xb]
                                                    }),
                                                    _0x594501(_0xe1fd0e, { 'index': '/creation/commentmanage' }, {
                                                        'default': _0x47c9f0(() => _0x442c33[0xc] || (_0x442c33[0xc] = [_0x3a32b3('\x20评论管理\x20')])),
                                                        '_': 0x1,
                                                        '__': [0xc]
                                                    })
                                                ]),
                                                '_': 0x1
                                            })
                                        ]),
                                        '_': 0x1
                                    })], 0x200), [[
                                        _0x2c44b1,
                                        _0x4c37f8['value']
                                    ]])]),
                            '_': 0x1
                        })]))
                ], 0x40);
            };
        }
    }, Je = _0x35ad54(Ge, [[
            '__scopeId',
            'data-v-cfdf1583'
        ]]), Ke = { 'class': 'create' }, We = {
        'href': '/editor',
        'target': '_blank'
    }, Ze = { 'class': 'create-button' }, et = {
        '__name': 'index',
        'setup'(_0x53aa18) {
            _0x5a4b1c();
            const _0x1c291e = _0x5e7cc3(), _0x38b401 = _0x6d0f31('/creation'), _0x235a23 = _0x33a765(() => _0x1c291e['path']);
            return _0x26ae10(_0x235a23, _0x1b8dbe => {
                _0x38b401['value'] = _0x1b8dbe;
            }, { 'immediate': !0x0 }), (_0x191716, _0x282666) => {
                const _0xc59bdd = je, _0x1313c7 = _0x154563, _0xa7e9ee = _0x275f59, _0x5f343b = _0x2b6350, _0x15a496 = _0x28d9bd, _0x42efa7 = Le, _0x2f414f = _0x5e01d2('router-view'), _0x243d4d = qe, _0x120203 = Re;
                return _0x576e7f(), _0x59b2fc(_0x120203, { 'class': 'layout-container' }, {
                    'default': _0x47c9f0(() => [
                        _0x594501(_0xc59bdd, { 'class': 'header' }, {
                            'default': _0x47c9f0(() => [_0x594501(Je)]),
                            '_': 0x1
                        }),
                        _0x594501(_0x120203, { 'class': 'menu' }, {
                            'default': _0x47c9f0(() => [
                                _0x594501(_0x42efa7, { 'class': 'sidebar' }, {
                                    'default': _0x47c9f0(() => [_0x594501(_0x15a496, {
                                            'class': 'pc-menu',
                                            'default-active': _0x38b401['value'],
                                            'router': '',
                                            'onSelect': _0x191716['handleSelect'],
                                            'default-openeds': ['/creation/manage']
                                        }, {
                                            'default': _0x47c9f0(() => [
                                                _0x14d71c('div', Ke, [_0x14d71c('a', We, [_0x14d71c('div', Ze, [
                                                            _0x594501(_0x1313c7, { 'class': 'create-icon' }, {
                                                                'default': _0x47c9f0(() => [_0x594501(_0x1a2887(_0x19f60d))]),
                                                                '_': 0x1
                                                            }),
                                                            _0x282666[0x0] || (_0x282666[0x0] = _0x3a32b3('创作\x20'))
                                                        ])])]),
                                                _0x594501(_0xa7e9ee, {
                                                    'index': '/',
                                                    'class': 'menu-item'
                                                }, {
                                                    'default': _0x47c9f0(() => [
                                                        _0x594501(_0x1313c7, null, {
                                                            'default': _0x47c9f0(() => [_0x594501(_0x1a2887(_0x1f6a06))]),
                                                            '_': 0x1
                                                        }),
                                                        _0x282666[0x1] || (_0x282666[0x1] = _0x14d71c('span', { 'class': 'menu-text' }, '网站首页', -0x1))
                                                    ]),
                                                    '_': 0x1,
                                                    '__': [0x1]
                                                }),
                                                _0x594501(_0xa7e9ee, {
                                                    'index': '/creation',
                                                    'class': 'menu-item'
                                                }, {
                                                    'default': _0x47c9f0(() => [
                                                        _0x594501(_0x1313c7, null, {
                                                            'default': _0x47c9f0(() => [_0x594501(_0x1a2887(_0x1ccdd3))]),
                                                            '_': 0x1
                                                        }),
                                                        _0x282666[0x2] || (_0x282666[0x2] = _0x14d71c('span', { 'class': 'menu-text' }, '首页', -0x1))
                                                    ]),
                                                    '_': 0x1,
                                                    '__': [0x2]
                                                }),
                                                _0x594501(_0x5f343b, {
                                                    'index': '/creation/manage',
                                                    'class': 'menu-item'
                                                }, {
                                                    'title': _0x47c9f0(() => [
                                                        _0x594501(_0x1313c7, null, {
                                                            'default': _0x47c9f0(() => [_0x594501(_0x1a2887(_0x2cf171))]),
                                                            '_': 0x1
                                                        }),
                                                        _0x282666[0x3] || (_0x282666[0x3] = _0x14d71c('span', { 'class': 'menu-text' }, '管理', -0x1))
                                                    ]),
                                                    'default': _0x47c9f0(() => [
                                                        _0x594501(_0xa7e9ee, { 'index': '/creation/articlemanage' }, {
                                                            'default': _0x47c9f0(() => _0x282666[0x4] || (_0x282666[0x4] = [_0x3a32b3('\x20文章管理\x20')])),
                                                            '_': 0x1,
                                                            '__': [0x4]
                                                        }),
                                                        _0x594501(_0xa7e9ee, { 'index': '/creation/columnmanage' }, {
                                                            'default': _0x47c9f0(() => _0x282666[0x5] || (_0x282666[0x5] = [_0x3a32b3('\x20专栏管理\x20')])),
                                                            '_': 0x1,
                                                            '__': [0x5]
                                                        }),
                                                        _0x594501(_0xa7e9ee, { 'index': '/creation/commentmanage' }, {
                                                            'default': _0x47c9f0(() => _0x282666[0x6] || (_0x282666[0x6] = [_0x3a32b3('\x20评论管理\x20')])),
                                                            '_': 0x1,
                                                            '__': [0x6]
                                                        })
                                                    ]),
                                                    '_': 0x1
                                                })
                                            ]),
                                            '_': 0x1
                                        }, 0x8, [
                                            'default-active',
                                            'onSelect'
                                        ])]),
                                    '_': 0x1
                                }),
                                _0x594501(_0x243d4d, { 'class': 'main' }, {
                                    'default': _0x47c9f0(() => [_0x594501(_0x2f414f, { 'class': 'router-view' })]),
                                    '_': 0x1
                                })
                            ]),
                            '_': 0x1
                        })
                    ]),
                    '_': 0x1
                });
            };
        }
    }, bt = _0x35ad54(et, [[
            '__scopeId',
            'data-v-287ae086'
        ]]);
export {
    bt as default
};