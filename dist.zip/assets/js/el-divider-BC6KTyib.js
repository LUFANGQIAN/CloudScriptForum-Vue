const _0x3cef6b = (function () {
        let _0x30b030 = !![];
        return function (_0x45a7fd, _0x196c5f) {
            const _0x2c2d8c = _0x30b030 ? function () {
                if (_0x196c5f) {
                    const _0x4b1cd3 = _0x196c5f['apply'](_0x45a7fd, arguments);
                    return _0x196c5f = null, _0x4b1cd3;
                }
            } : function () {
            };
            return _0x30b030 = ![], _0x2c2d8c;
        };
    }()), _0x45d979 = _0x3cef6b(this, function () {
        let _0xaf630f;
        try {
            const _0x37ca9a = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0xaf630f = _0x37ca9a();
        } catch (_0x44dad4) {
            _0xaf630f = window;
        }
        const _0x44e107 = _0xaf630f['console'] = _0xaf630f['console'] || {}, _0x1c4dbb = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x1f62c8 = 0x0; _0x1f62c8 < _0x1c4dbb['length']; _0x1f62c8++) {
            const _0xb60968 = _0x3cef6b['constructor']['prototype']['bind'](_0x3cef6b), _0x4803c2 = _0x1c4dbb[_0x1f62c8], _0x502a2b = _0x44e107[_0x4803c2] || _0xb60968;
            _0xb60968['__proto__'] = _0x3cef6b['bind'](_0x3cef6b), _0xb60968['toString'] = _0x502a2b['toString']['bind'](_0x502a2b), _0x44e107[_0x4803c2] = _0xb60968;
        }
    });
_0x45d979();
import {
    c,
    d as _0x52b96d,
    _ as _0x38e174,
    e as _0x95178e,
    w as _0x19ac05
} from './Request-CHKnUlo5.js';
import {
    X as _0x3f48ea,
    Y as _0x1b0ca6,
    c as _0x1f3bfc,
    b as _0x312aaf,
    k as _0x15f477,
    z as _0x2f5945,
    m as _0x137f52,
    a2 as _0x52f0a2,
    $ as _0x4ba359
} from './index-54DmW9hq.js';
const b = c({
        'direction': {
            'type': String,
            'values': [
                'horizontal',
                'vertical'
            ],
            'default': 'horizontal'
        },
        'contentPosition': {
            'type': String,
            'values': [
                'left',
                'center',
                'right'
            ],
            'default': 'center'
        },
        'borderStyle': {
            'type': _0x52b96d(String),
            'default': 'solid'
        }
    }), h = _0x3f48ea({ 'name': 'ElDivider' }), z = _0x3f48ea({
        ...h,
        'props': b,
        'setup'(_0x6fd4f8) {
            const _0x17d26b = _0x6fd4f8, _0x5a1873 = _0x95178e('divider'), _0x84d445 = _0x1b0ca6(() => _0x5a1873['cssVar']({ 'border-style': _0x17d26b['borderStyle'] }));
            return (_0x18008b, _0x5d3ac7) => (_0x312aaf(), _0x1f3bfc('div', {
                'class': _0x2f5945([
                    _0x137f52(_0x5a1873)['b'](),
                    _0x137f52(_0x5a1873)['m'](_0x18008b['direction'])
                ]),
                'style': _0x4ba359(_0x137f52(_0x84d445)),
                'role': 'separator'
            }, [_0x18008b['$slots']['default'] && _0x18008b['direction'] !== 'vertical' ? (_0x312aaf(), _0x1f3bfc('div', {
                    'key': 0x0,
                    'class': _0x2f5945([
                        _0x137f52(_0x5a1873)['e']('text'),
                        _0x137f52(_0x5a1873)['is'](_0x18008b['contentPosition'])
                    ])
                }, [_0x52f0a2(_0x18008b['$slots'], 'default')], 0x2)) : _0x15f477('v-if', !0x0)], 0x6));
        }
    });
var P = _0x38e174(z, [[
        '__file',
        'divider.vue'
    ]]);
const C = _0x19ac05(P);
export {
    C as E
};