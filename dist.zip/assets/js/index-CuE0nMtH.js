const _0x5e4ce0 = (function () {
        let _0x4f2369 = !![];
        return function (_0x2b1881, _0x337440) {
            const _0x51896c = _0x4f2369 ? function () {
                if (_0x337440) {
                    const _0x241f95 = _0x337440['apply'](_0x2b1881, arguments);
                    return _0x337440 = null, _0x241f95;
                }
            } : function () {
            };
            return _0x4f2369 = ![], _0x51896c;
        };
    }()), _0x17615e = _0x5e4ce0(this, function () {
        let _0x339f4c;
        try {
            const _0x528632 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x339f4c = _0x528632();
        } catch (_0x334751) {
            _0x339f4c = window;
        }
        const _0x1b5cc6 = _0x339f4c['console'] = _0x339f4c['console'] || {}, _0x2b76ec = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x6f3760 = 0x0; _0x6f3760 < _0x2b76ec['length']; _0x6f3760++) {
            const _0x4dede2 = _0x5e4ce0['constructor']['prototype']['bind'](_0x5e4ce0), _0x3ddd1d = _0x2b76ec[_0x6f3760], _0x46081d = _0x1b5cc6[_0x3ddd1d] || _0x4dede2;
            _0x4dede2['__proto__'] = _0x5e4ce0['bind'](_0x5e4ce0), _0x4dede2['toString'] = _0x46081d['toString']['bind'](_0x46081d), _0x1b5cc6[_0x3ddd1d] = _0x4dede2;
        }
    });
_0x17615e();
import {
    aj as _0x29d3c7,
    n as _0x28ba77
} from './Request-CHKnUlo5.js';
import { a3 as _0x29b404 } from './index-54DmW9hq.js';
const s = new Map();
if (_0x28ba77) {
    let e;
    document['addEventListener']('mousedown', _0xab93fc => e = _0xab93fc), document['addEventListener']('mouseup', _0x150a35 => {
        if (e) {
            for (const _0x47a64b of s['values']())
                for (const {documentHandler: _0x62e902} of _0x47a64b)
                    _0x62e902(_0x150a35, e);
            e = void 0x0;
        }
    });
}
function i(_0x4ecfe8, _0x51e9e9) {
    let _0x17ace8 = [];
    return _0x29b404(_0x51e9e9['arg']) ? _0x17ace8 = _0x51e9e9['arg'] : _0x29d3c7(_0x51e9e9['arg']) && _0x17ace8['push'](_0x51e9e9['arg']), function (_0x1c3913, _0x37c164) {
        const _0x2515aa = _0x51e9e9['instance']['popperRef'], _0x313e6d = _0x1c3913['target'], _0x4abe74 = _0x37c164 == null ? void 0x0 : _0x37c164['target'], _0x45decd = !_0x51e9e9 || !_0x51e9e9['instance'], _0x470680 = !_0x313e6d || !_0x4abe74, _0x188a6a = _0x4ecfe8['contains'](_0x313e6d) || _0x4ecfe8['contains'](_0x4abe74), _0x16d4d4 = _0x4ecfe8 === _0x313e6d, _0x3c7d3b = _0x17ace8['length'] && _0x17ace8['some'](_0x439809 => _0x439809 == null ? void 0x0 : _0x439809['contains'](_0x313e6d)) || _0x17ace8['length'] && _0x17ace8['includes'](_0x4abe74), _0x8a4e8e = _0x2515aa && (_0x2515aa['contains'](_0x313e6d) || _0x2515aa['contains'](_0x4abe74));
        _0x45decd || _0x470680 || _0x188a6a || _0x16d4d4 || _0x3c7d3b || _0x8a4e8e || _0x51e9e9['value'](_0x1c3913, _0x37c164);
    };
}
const T = {
    'beforeMount'(_0x24149c, _0x598a9e) {
        s['has'](_0x24149c) || s['set'](_0x24149c, []), s['get'](_0x24149c)['push']({
            'documentHandler': i(_0x24149c, _0x598a9e),
            'bindingFn': _0x598a9e['value']
        });
    },
    'updated'(_0x80c7a4, _0x2ce7b5) {
        s['has'](_0x80c7a4) || s['set'](_0x80c7a4, []);
        const _0x5c9db5 = s['get'](_0x80c7a4), _0x27a404 = _0x5c9db5['findIndex'](_0x3c1e2b => _0x3c1e2b['bindingFn'] === _0x2ce7b5['oldValue']), _0x4f2657 = {
                'documentHandler': i(_0x80c7a4, _0x2ce7b5),
                'bindingFn': _0x2ce7b5['value']
            };
        _0x27a404 >= 0x0 ? _0x5c9db5['splice'](_0x27a404, 0x1, _0x4f2657) : _0x5c9db5['push'](_0x4f2657);
    },
    'unmounted'(_0x277a9f) {
        s['delete'](_0x277a9f);
    }
};
export {
    T as C
};