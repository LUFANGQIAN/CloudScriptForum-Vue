const _0x4ac7a2 = (function () {
        let _0x4dc923 = !![];
        return function (_0x350f7b, _0x9ec517) {
            const _0x1f43dd = _0x4dc923 ? function () {
                if (_0x9ec517) {
                    const _0x113ae6 = _0x9ec517['apply'](_0x350f7b, arguments);
                    return _0x9ec517 = null, _0x113ae6;
                }
            } : function () {
            };
            return _0x4dc923 = ![], _0x1f43dd;
        };
    }()), _0x297ec0 = _0x4ac7a2(this, function () {
        let _0x36314e;
        try {
            const _0x4c7716 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x36314e = _0x4c7716();
        } catch (_0x5bcaff) {
            _0x36314e = window;
        }
        const _0x2e127a = _0x36314e['console'] = _0x36314e['console'] || {}, _0x18e809 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x193213 = 0x0; _0x193213 < _0x18e809['length']; _0x193213++) {
            const _0x2c6130 = _0x4ac7a2['constructor']['prototype']['bind'](_0x4ac7a2), _0x19280f = _0x18e809[_0x193213], _0x2e1714 = _0x2e127a[_0x19280f] || _0x2c6130;
            _0x2c6130['__proto__'] = _0x4ac7a2['bind'](_0x4ac7a2), _0x2c6130['toString'] = _0x2e1714['toString']['bind'](_0x2e1714), _0x2e127a[_0x19280f] = _0x2c6130;
        }
    });
_0x297ec0();
import {
    c as _0x1f5d60,
    d as _0x470161,
    _ as _0x3af2d0,
    w as _0x4630e2
} from './Request-CHKnUlo5.js';
import {
    X as _0x665c87,
    a2 as _0x4c7ec3,
    e as _0x42555a,
    b as _0x4f803d,
    D as _0x529783
} from './index-54DmW9hq.js';
const i = _0x1f5d60({
        'to': {
            'type': _0x470161([
                String,
                Object
            ]),
            'required': !0x0
        },
        'disabled': Boolean
    }), c = _0x665c87({
        '__name': 'teleport',
        'props': i,
        'setup'(_0x3b8a2e) {
            return (_0x12b4a4, _0x3bb46f) => _0x12b4a4['disabled'] ? _0x4c7ec3(_0x12b4a4['$slots'], 'default', { 'key': 0x0 }) : (_0x4f803d(), _0x42555a(_0x529783, {
                'key': 0x1,
                'to': _0x12b4a4['to']
            }, [_0x4c7ec3(_0x12b4a4['$slots'], 'default')], 0x8, ['to']));
        }
    });
var f = _0x3af2d0(c, [[
        '__file',
        'teleport.vue'
    ]]);
const k = _0x4630e2(f);
export {
    k as E,
    i as t
};