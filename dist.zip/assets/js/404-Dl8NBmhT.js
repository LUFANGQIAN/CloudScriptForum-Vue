const _0x548348 = (function () {
        let _0x4569d4 = !![];
        return function (_0x12f44f, _0x2045ec) {
            const _0x59233e = _0x4569d4 ? function () {
                if (_0x2045ec) {
                    const _0x2cb4eb = _0x2045ec['apply'](_0x12f44f, arguments);
                    return _0x2045ec = null, _0x2cb4eb;
                }
            } : function () {
            };
            return _0x4569d4 = ![], _0x59233e;
        };
    }()), _0x327849 = _0x548348(this, function () {
        const _0x34794f = function () {
                let _0x28adbf;
                try {
                    _0x28adbf = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x14884f) {
                    _0x28adbf = window;
                }
                return _0x28adbf;
            }, _0x43297a = _0x34794f(), _0x5e1e18 = _0x43297a['console'] = _0x43297a['console'] || {}, _0x4a523c = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x2c94bd = 0x0; _0x2c94bd < _0x4a523c['length']; _0x2c94bd++) {
            const _0x55a1c3 = _0x548348['constructor']['prototype']['bind'](_0x548348), _0x385bbb = _0x4a523c[_0x2c94bd], _0x46e43e = _0x5e1e18[_0x385bbb] || _0x55a1c3;
            _0x55a1c3['__proto__'] = _0x548348['bind'](_0x548348), _0x55a1c3['toString'] = _0x46e43e['toString']['bind'](_0x46e43e), _0x5e1e18[_0x385bbb] = _0x55a1c3;
        }
    });
_0x327849();
import {
    _ as _0x5fa8a7,
    c as _0x110110,
    g as _0x44a646,
    u as _0x52abe6,
    b as _0x2eac49
} from './index-54DmW9hq.js';
const u = { 'class': 'not-found-container' }, d = {
        '__name': '404',
        'setup'(_0x215b7c) {
            const _0x3d9165 = _0x52abe6(), _0x57df4f = () => {
                    _0x3d9165['push']('/');
                };
            return (_0xe4cc36, _0x34b1e9) => (_0x2eac49(), _0x110110('div', u, [_0x44a646('div', { 'class': 'not-found-content' }, [
                    _0x34b1e9[0x0] || (_0x34b1e9[0x0] = _0x44a646('h1', { 'class': 'error-code' }, '404', -0x1)),
                    _0x34b1e9[0x1] || (_0x34b1e9[0x1] = _0x44a646('p', { 'class': 'error-message' }, '页面不存在', -0x1)),
                    _0x34b1e9[0x2] || (_0x34b1e9[0x2] = _0x44a646('p', { 'class': 'suggestion' }, '抱歉，您访问的页面不存在或已被删除', -0x1)),
                    _0x44a646('button', {
                        'class': 'back-home',
                        'onClick': _0x57df4f
                    }, '返回首页')
                ])]));
        }
    }, i = _0x5fa8a7(d, [[
            '__scopeId',
            'data-v-a4761b8d'
        ]]);
export {
    i as default
};