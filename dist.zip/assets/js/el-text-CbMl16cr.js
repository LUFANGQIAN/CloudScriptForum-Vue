const _0x323db1 = (function () {
        let _0x26e85b = !![];
        return function (_0x2168b9, _0x5236ef) {
            const _0xc2cdd4 = _0x26e85b ? function () {
                if (_0x5236ef) {
                    const _0x5114b3 = _0x5236ef['apply'](_0x2168b9, arguments);
                    return _0x5236ef = null, _0x5114b3;
                }
            } : function () {
            };
            return _0x26e85b = ![], _0xc2cdd4;
        };
    }()), _0x181812 = _0x323db1(this, function () {
        let _0x828f8b;
        try {
            const _0x3c62ac = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x828f8b = _0x3c62ac();
        } catch (_0x445fce) {
            _0x828f8b = window;
        }
        const _0x24e038 = _0x828f8b['console'] = _0x828f8b['console'] || {}, _0x11986e = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x2d6446 = 0x0; _0x2d6446 < _0x11986e['length']; _0x2d6446++) {
            const _0x26049b = _0x323db1['constructor']['prototype']['bind'](_0x323db1), _0x2dafe7 = _0x11986e[_0x2d6446], _0x3e0df8 = _0x24e038[_0x2dafe7] || _0x26049b;
            _0x26049b['__proto__'] = _0x323db1['bind'](_0x323db1), _0x26049b['toString'] = _0x3e0df8['toString']['bind'](_0x3e0df8), _0x24e038[_0x2dafe7] = _0x26049b;
        }
    });
_0x181812();
import {
    c as _0x38cc79,
    a1 as _0x422220,
    _ as _0xef53c0,
    e as _0x5872fd,
    l as _0x545a56,
    w as _0x3abdf4
} from './Request-CHKnUlo5.js';
import { b as _0x2a79ce } from './el-button-D6wSrR74.js';
import {
    X as _0x525de0,
    r as _0x28ff31,
    Y as _0x2bc18d,
    o as _0x14caeb,
    aC as _0x40cddc,
    e as _0x2876ea,
    b as _0x9b02fd,
    f as _0x298cc6,
    a2 as _0xa27145,
    $ as _0x39d3f7,
    z as _0x3da41,
    m as _0x25c540,
    ak as _0x3ba1f0,
    Z as _0x1f18d5
} from './index-54DmW9hq.js';
const F = _0x38cc79({
        'type': {
            'type': String,
            'values': [
                'primary',
                'success',
                'info',
                'warning',
                'danger',
                ''
            ],
            'default': ''
        },
        'size': {
            'type': String,
            'values': _0x422220,
            'default': ''
        },
        'truncated': Boolean,
        'lineClamp': {
            'type': [
                String,
                Number
            ]
        },
        'tag': {
            'type': String,
            'default': 'span'
        }
    }), I = _0x525de0({ 'name': 'ElText' }), K = _0x525de0({
        ...I,
        'props': F,
        'setup'(_0x56d39d) {
            const _0x135a1e = _0x56d39d, _0x3d5436 = _0x28ff31(), _0x18eadb = _0x2a79ce(), _0x1d130f = _0x5872fd('text'), _0x848cb3 = _0x2bc18d(() => [
                    _0x1d130f['b'](),
                    _0x1d130f['m'](_0x135a1e['type']),
                    _0x1d130f['m'](_0x18eadb['value']),
                    _0x1d130f['is']('truncated', _0x135a1e['truncated']),
                    _0x1d130f['is']('line-clamp', !_0x545a56(_0x135a1e['lineClamp']))
                ]), _0x293a7f = () => {
                    var _0x153c02, _0x21714a, _0x53aca7, _0x5dbb34, _0x2505a4, _0x1746dd, _0x3496cd;
                    if (_0x1f18d5()['title'])
                        return;
                    let _0x12fcb5 = !0x1;
                    const _0x21b03d = ((_0x153c02 = _0x3d5436['value']) == null ? void 0x0 : _0x153c02['textContent']) || '';
                    if (_0x135a1e['truncated']) {
                        const _0x3c14fa = (_0x21714a = _0x3d5436['value']) == null ? void 0x0 : _0x21714a['offsetWidth'], _0x53062c = (_0x53aca7 = _0x3d5436['value']) == null ? void 0x0 : _0x53aca7['scrollWidth'];
                        _0x3c14fa && _0x53062c && _0x53062c > _0x3c14fa && (_0x12fcb5 = !0x0);
                    } else {
                        if (!_0x545a56(_0x135a1e['lineClamp'])) {
                            const _0x27aafc = (_0x5dbb34 = _0x3d5436['value']) == null ? void 0x0 : _0x5dbb34['offsetHeight'], _0x581e65 = (_0x2505a4 = _0x3d5436['value']) == null ? void 0x0 : _0x2505a4['scrollHeight'];
                            _0x27aafc && _0x581e65 && _0x581e65 > _0x27aafc && (_0x12fcb5 = !0x0);
                        }
                    }
                    _0x12fcb5 ? (_0x1746dd = _0x3d5436['value']) == null || _0x1746dd['setAttribute']('title', _0x21b03d) : (_0x3496cd = _0x3d5436['value']) == null || _0x3496cd['removeAttribute']('title');
                };
            return _0x14caeb(_0x293a7f), _0x40cddc(_0x293a7f), (_0x36bb96, _0x55e74d) => (_0x9b02fd(), _0x2876ea(_0x3ba1f0(_0x36bb96['tag']), {
                'ref_key': 'textRef',
                'ref': _0x3d5436,
                'class': _0x3da41(_0x25c540(_0x848cb3)),
                'style': _0x39d3f7({ '-webkit-line-clamp': _0x36bb96['lineClamp'] })
            }, {
                'default': _0x298cc6(() => [_0xa27145(_0x36bb96['$slots'], 'default')]),
                '_': 0x3
            }, 0x8, [
                'class',
                'style'
            ]));
        }
    });
var M = _0xef53c0(K, [[
        '__file',
        'text.vue'
    ]]);
const q = _0x3abdf4(M);
export {
    q as E
};