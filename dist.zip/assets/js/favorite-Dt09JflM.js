const _0x5853f4 = (function () {
        let _0x38ce57 = !![];
        return function (_0xac015f, _0x531aa9) {
            const _0x285c5e = _0x38ce57 ? function () {
                if (_0x531aa9) {
                    const _0x2294f7 = _0x531aa9['apply'](_0xac015f, arguments);
                    return _0x531aa9 = null, _0x2294f7;
                }
            } : function () {
            };
            return _0x38ce57 = ![], _0x285c5e;
        };
    }()), _0x506bba = _0x5853f4(this, function () {
        let _0x35c877;
        try {
            const _0x3deb67 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x35c877 = _0x3deb67();
        } catch (_0x55354e) {
            _0x35c877 = window;
        }
        const _0x4981d0 = _0x35c877['console'] = _0x35c877['console'] || {}, _0x1f61ea = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x135519 = 0x0; _0x135519 < _0x1f61ea['length']; _0x135519++) {
            const _0x88be2c = _0x5853f4['constructor']['prototype']['bind'](_0x5853f4), _0x45b6aa = _0x1f61ea[_0x135519], _0x49db58 = _0x4981d0[_0x45b6aa] || _0x88be2c;
            _0x88be2c['__proto__'] = _0x5853f4['bind'](_0x5853f4), _0x88be2c['toString'] = _0x49db58['toString']['bind'](_0x49db58), _0x4981d0[_0x45b6aa] = _0x88be2c;
        }
    });
_0x506bba();
import { r } from './Request-CHKnUlo5.js';
const o = _0x5b2f18 => r({
        'url': '/favorite/listByArticle',
        'method': 'get',
        'params': { 'articleId': _0x5b2f18 }
    }), s = _0x5582e2 => r({
        'url': '/favorite/add',
        'method': 'post',
        'data': _0x5582e2
    }), i = _0x549f86 => r({
        'url': '/favorite/update',
        'method': 'put',
        'data': _0x549f86
    }), d = (_0x5b932c, _0x5a080b) => r({
        'url': '/favorite/addArticle',
        'method': 'post',
        'params': {
            'articleId': _0x5b932c,
            'favoriteId': _0x5a080b
        }
    }), u = (_0x19e04a, _0x56b2c8) => r({
        'url': '/favorite/removeArticle',
        'method': 'delete',
        'params': {
            'articleId': _0x19e04a,
            'favoriteId': _0x56b2c8
        }
    }), l = _0x4bf17b => r({
        'url': '/favorite/listByUser',
        'method': 'get',
        'params': { 'userId': _0x4bf17b }
    }), m = _0x13739d => r({
        'url': '/favorite/articles',
        'method': 'get',
        'params': { 'favoriteId': _0x13739d }
    });
export {
    l as a,
    s as b,
    o as c,
    d,
    m as g,
    u as r,
    i as u
};