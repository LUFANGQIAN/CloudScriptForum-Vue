const _0x584e3a = (function () {
        let _0x3967fa = !![];
        return function (_0x485837, _0x344658) {
            const _0x7daac5 = _0x3967fa ? function () {
                if (_0x344658) {
                    const _0xae7ed5 = _0x344658['apply'](_0x485837, arguments);
                    return _0x344658 = null, _0xae7ed5;
                }
            } : function () {
            };
            return _0x3967fa = ![], _0x7daac5;
        };
    }()), _0x496062 = _0x584e3a(this, function () {
        const _0x317669 = function () {
                let _0x119ee8;
                try {
                    _0x119ee8 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x439a40) {
                    _0x119ee8 = window;
                }
                return _0x119ee8;
            }, _0x4de279 = _0x317669(), _0x125b5c = _0x4de279['console'] = _0x4de279['console'] || {}, _0x4191ad = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x3774f4 = 0x0; _0x3774f4 < _0x4191ad['length']; _0x3774f4++) {
            const _0x1d2071 = _0x584e3a['constructor']['prototype']['bind'](_0x584e3a), _0x11fd8e = _0x4191ad[_0x3774f4], _0x171ce6 = _0x125b5c[_0x11fd8e] || _0x1d2071;
            _0x1d2071['__proto__'] = _0x584e3a['bind'](_0x584e3a), _0x1d2071['toString'] = _0x171ce6['toString']['bind'](_0x171ce6), _0x125b5c[_0x11fd8e] = _0x1d2071;
        }
    });
_0x496062();
import {
    c as _0x4e6c30,
    d as _0x504b57,
    _ as _0xc0f453,
    e as _0x5d39c0,
    i as _0x9600e4,
    l as _0x395c6d,
    w as _0x4027b0,
    L as _0x3f8b09
} from './Request-CHKnUlo5.js';
import {
    X as _0x4b08be,
    c as _0x410241,
    b as _0x4266e5,
    e as _0x8226bf,
    k as _0x3b4e6d,
    m as _0x11e4e4,
    a_ as _0x418306,
    z as _0x450354,
    U as _0x1d72ad,
    r as _0x1dbf5e,
    o as _0x267992,
    w as _0x4b371a,
    aq as _0x511b1b,
    a2 as _0x168ffd,
    F as _0x22b2e0,
    G as _0x24429a,
    d as _0x15bf5f,
    a0 as _0x48f890,
    a$ as _0x2b89c8
} from './index-54DmW9hq.js';
const O = _0x4e6c30({
        'animated': Boolean,
        'count': {
            'type': Number,
            'default': 0x1
        },
        'rows': {
            'type': Number,
            'default': 0x3
        },
        'loading': {
            'type': Boolean,
            'default': !0x0
        },
        'throttle': {
            'type': _0x504b57([
                Number,
                Object
            ])
        }
    }), R = _0x4e6c30({
        'variant': {
            'type': String,
            'values': [
                'circle',
                'rect',
                'h1',
                'h3',
                'text',
                'caption',
                'p',
                'image',
                'button'
            ],
            'default': 'text'
        }
    }), U = _0x4b08be({ 'name': 'ElSkeletonItem' }), q = _0x4b08be({
        ...U,
        'props': R,
        'setup'(_0x200a8f) {
            const _0x38528d = _0x5d39c0('skeleton');
            return (_0x2f882e, _0x52a5a4) => (_0x4266e5(), _0x410241('div', {
                'class': _0x450354([
                    _0x11e4e4(_0x38528d)['e']('item'),
                    _0x11e4e4(_0x38528d)['e'](_0x2f882e['variant'])
                ])
            }, [_0x2f882e['variant'] === 'image' ? (_0x4266e5(), _0x8226bf(_0x11e4e4(_0x418306), { 'key': 0x0 })) : _0x3b4e6d('v-if', !0x0)], 0x2));
        }
    });
var c = _0xc0f453(q, [[
        '__file',
        'skeleton-item.vue'
    ]]);
const G = (_0xde57ce, _0xc395d6 = 0x0) => {
        if (_0xc395d6 === 0x0)
            return _0xde57ce;
        const _0x157a4f = _0x1d72ad(_0xc395d6) && !!_0xc395d6['initVal'], _0x3414bd = _0x1dbf5e(_0x157a4f);
        let _0x2ce259 = null;
        const _0x98b69f = _0x243aed => {
                if (_0x395c6d(_0x243aed)) {
                    _0x3414bd['value'] = _0xde57ce['value'];
                    return;
                }
                _0x2ce259 && clearTimeout(_0x2ce259), _0x2ce259 = setTimeout(() => {
                    _0x3414bd['value'] = _0xde57ce['value'];
                }, _0x243aed);
            }, _0xf9ef84 = _0xe4eaca => {
                _0xe4eaca === 'leading' ? _0x9600e4(_0xc395d6) ? _0x98b69f(_0xc395d6) : _0x98b69f(_0xc395d6['leading']) : _0x1d72ad(_0xc395d6) ? _0x98b69f(_0xc395d6['trailing']) : _0x3414bd['value'] = !0x1;
            };
        return _0x267992(() => _0xf9ef84('leading')), _0x4b371a(() => _0xde57ce['value'], _0x242379 => {
            _0xf9ef84(_0x242379 ? 'leading' : 'trailing');
        }), _0x3414bd;
    }, H = _0x4b08be({ 'name': 'ElSkeleton' }), M = _0x4b08be({
        ...H,
        'props': O,
        'setup'(_0xa714d2, {expose: _0xf01da2}) {
            const _0x29def0 = _0xa714d2, _0x3eea19 = _0x5d39c0('skeleton'), _0x39b833 = G(_0x511b1b(_0x29def0, 'loading'), _0x29def0['throttle']);
            return _0xf01da2({ 'uiLoading': _0x39b833 }), (_0x1e8a9c, _0x575beb) => _0x11e4e4(_0x39b833) ? (_0x4266e5(), _0x410241('div', _0x48f890({
                'key': 0x0,
                'class': [
                    _0x11e4e4(_0x3eea19)['b'](),
                    _0x11e4e4(_0x3eea19)['is']('animated', _0x1e8a9c['animated'])
                ]
            }, _0x1e8a9c['$attrs']), [(_0x4266e5(!0x0), _0x410241(_0x22b2e0, null, _0x24429a(_0x1e8a9c['count'], _0x233ce1 => (_0x4266e5(), _0x410241(_0x22b2e0, { 'key': _0x233ce1 }, [_0x11e4e4(_0x39b833) ? _0x168ffd(_0x1e8a9c['$slots'], 'template', { 'key': _0x233ce1 }, () => [
                        _0x15bf5f(c, {
                            'class': _0x450354(_0x11e4e4(_0x3eea19)['is']('first')),
                            'variant': 'p'
                        }, null, 0x8, ['class']),
                        (_0x4266e5(!0x0), _0x410241(_0x22b2e0, null, _0x24429a(_0x1e8a9c['rows'], _0xbb2cf4 => (_0x4266e5(), _0x8226bf(c, {
                            'key': _0xbb2cf4,
                            'class': _0x450354([
                                _0x11e4e4(_0x3eea19)['e']('paragraph'),
                                _0x11e4e4(_0x3eea19)['is']('last', _0xbb2cf4 === _0x1e8a9c['rows'] && _0x1e8a9c['rows'] > 0x1)
                            ]),
                            'variant': 'p'
                        }, null, 0x8, ['class']))), 0x80))
                    ]) : _0x3b4e6d('v-if', !0x0)], 0x40))), 0x80))], 0x10)) : _0x168ffd(_0x1e8a9c['$slots'], 'default', _0x2b89c8(_0x48f890({ 'key': 0x1 }, _0x1e8a9c['$attrs'])));
        }
    });
var X = _0xc0f453(M, [[
        '__file',
        'skeleton.vue'
    ]]);
const J = _0x4027b0(X, { 'SkeletonItem': c }), K = _0x3f8b09(c);
export {
    J as E,
    K as a
};