const _0xa58674 = (function () {
        let _0x74a470 = !![];
        return function (_0x5c0897, _0x4ff2d6) {
            const _0x3f0c4d = _0x74a470 ? function () {
                if (_0x4ff2d6) {
                    const _0x163902 = _0x4ff2d6['apply'](_0x5c0897, arguments);
                    return _0x4ff2d6 = null, _0x163902;
                }
            } : function () {
            };
            return _0x74a470 = ![], _0x3f0c4d;
        };
    }()), _0x1228c1 = _0xa58674(this, function () {
        let _0x15fe50;
        try {
            const _0x14867d = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x15fe50 = _0x14867d();
        } catch (_0x2c7ac7) {
            _0x15fe50 = window;
        }
        const _0x22d93b = _0x15fe50['console'] = _0x15fe50['console'] || {}, _0x360143 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x5067f0 = 0x0; _0x5067f0 < _0x360143['length']; _0x5067f0++) {
            const _0x52677e = _0xa58674['constructor']['prototype']['bind'](_0xa58674), _0x3cb023 = _0x360143[_0x5067f0], _0xf82446 = _0x22d93b[_0x3cb023] || _0x52677e;
            _0x52677e['__proto__'] = _0xa58674['bind'](_0xa58674), _0x52677e['toString'] = _0xf82446['toString']['bind'](_0xf82446), _0x22d93b[_0x3cb023] = _0x52677e;
        }
    });
_0x1228c1();
import { bf as _0x5e73b6 } from './index-54DmW9hq.js';
const p = (_0x3a05bf = '') => _0x3a05bf['replace'](/[|\\{}()[\]^$+*?.]/g, '\x5c$&')['replace'](/-/g, '\x5cx2d'), t = _0x37d066 => _0x5e73b6(_0x37d066);
export {
    t as c,
    p as e
};