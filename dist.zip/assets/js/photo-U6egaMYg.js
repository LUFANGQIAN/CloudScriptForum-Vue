const _0x2bbc4f = (function () {
        let _0x5b90ca = !![];
        return function (_0x586775, _0xd1b2be) {
            const _0x5f0e22 = _0x5b90ca ? function () {
                if (_0xd1b2be) {
                    const _0x2858fa = _0xd1b2be['apply'](_0x586775, arguments);
                    return _0xd1b2be = null, _0x2858fa;
                }
            } : function () {
            };
            return _0x5b90ca = ![], _0x5f0e22;
        };
    }()), _0x406b41 = _0x2bbc4f(this, function () {
        const _0x2741fd = function () {
                let _0x5d3bd7;
                try {
                    _0x5d3bd7 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x48977a) {
                    _0x5d3bd7 = window;
                }
                return _0x5d3bd7;
            }, _0x5f33ac = _0x2741fd(), _0x4bc322 = _0x5f33ac['console'] = _0x5f33ac['console'] || {}, _0x48975d = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x16fa80 = 0x0; _0x16fa80 < _0x48975d['length']; _0x16fa80++) {
            const _0x4d051e = _0x2bbc4f['constructor']['prototype']['bind'](_0x2bbc4f), _0x428a8e = _0x48975d[_0x16fa80], _0x2df3ce = _0x4bc322[_0x428a8e] || _0x4d051e;
            _0x4d051e['__proto__'] = _0x2bbc4f['bind'](_0x2bbc4f), _0x4d051e['toString'] = _0x2df3ce['toString']['bind'](_0x2df3ce), _0x4bc322[_0x428a8e] = _0x4d051e;
        }
    });
_0x406b41();
import { r as _0x51dba2 } from './Request-CHKnUlo5.js';
function n(_0x481a5b, _0x5cc5ba) {
    const _0x365114 = new FormData();
    return _0x365114['append']('file', _0x481a5b), _0x365114['append']('albumId', _0x5cc5ba), _0x51dba2({
        'url': '/photo/uploadAlbum',
        'method': 'post',
        'data': _0x365114,
        'headers': { 'Content-Type': 'multipart/form-data' }
    });
}
function p(_0x572eec) {
    const _0x44ccc3 = new FormData();
    return _0x44ccc3['append']('file', _0x572eec), _0x51dba2({
        'url': '/photo/uploadArticle',
        'method': 'post',
        'data': _0x44ccc3,
        'headers': { 'Content-Type': 'multipart/form-data' }
    });
}
function d(_0x50d369) {
    const _0x108b1b = new FormData();
    return _0x108b1b['append']('file', _0x50d369), _0x51dba2({
        'url': '/photo/uploadColumn',
        'method': 'post',
        'data': _0x108b1b,
        'headers': { 'Content-Type': 'multipart/form-data' }
    });
}
function u(_0x5625b5) {
    const _0x409b40 = new FormData();
    return _0x409b40['append']('file', _0x5625b5), _0x51dba2({
        'url': '/photo/uploadAvatar',
        'method': 'post',
        'data': _0x409b40,
        'headers': { 'Content-Type': 'multipart/form-data' }
    });
}
function l(_0x5a36cc) {
    const _0x4a4743 = new FormData();
    return _0x4a4743['append']('file', _0x5a36cc), _0x51dba2({
        'url': '/photo/uploadMessage',
        'method': 'post',
        'data': _0x4a4743,
        'headers': { 'Content-Type': 'multipart/form-data' }
    });
}
function m(_0x170514) {
    return _0x51dba2({
        'url': '/photo/delete/batch',
        'method': 'delete',
        'data': _0x170514
    });
}
export {
    u as a,
    m as b,
    l as c,
    d,
    p as e,
    n as u
};