var _0x50dcc9 = (function () {
        var _0x5c0a39 = !![];
        return function (_0x364827, _0x123eaf) {
            var _0x4d917f = _0x5c0a39 ? function () {
                if (_0x123eaf) {
                    var _0x458ada = _0x123eaf['apply'](_0x364827, arguments);
                    return _0x123eaf = null, _0x458ada;
                }
            } : function () {
            };
            return _0x5c0a39 = ![], _0x4d917f;
        };
    }()), _0x3e2891 = _0x50dcc9(this, function () {
        var _0x507e12;
        try {
            var _0x341d53 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x507e12 = _0x341d53();
        } catch (_0x146bc9) {
            _0x507e12 = window;
        }
        var _0x1ccc4a = _0x507e12['console'] = _0x507e12['console'] || {}, _0x3c89f9 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (var _0x5b0ca2 = 0x0; _0x5b0ca2 < _0x3c89f9['length']; _0x5b0ca2++) {
            var _0xfa30b1 = _0x50dcc9['constructor']['prototype']['bind'](_0x50dcc9), _0x490670 = _0x3c89f9[_0x5b0ca2], _0x2c492d = _0x1ccc4a[_0x490670] || _0xfa30b1;
            _0xfa30b1['__proto__'] = _0x50dcc9['bind'](_0x50dcc9), _0xfa30b1['toString'] = _0x2c492d['toString']['bind'](_0x2c492d), _0x1ccc4a[_0x490670] = _0xfa30b1;
        }
    });
_0x3e2891();
import { r as _0x2764d1 } from './Request-CHKnUlo5.js';
function s(_0x55879b) {
    return _0x2764d1({
        'url': '/user/login',
        'method': 'post',
        'data': _0x55879b
    });
}
function u(_0x282311) {
    return _0x2764d1({
        'url': '/user/oauthLogin',
        'headers': { 'Login-Type': _0x282311['type'] },
        'method': 'post',
        'data': _0x282311
    });
}
function o() {
    return _0x2764d1({
        'url': '/user/checkCode',
        'method': 'get'
    });
}
function n(_0x59efec) {
    return _0x2764d1({
        'url': '/user/register',
        'method': 'post',
        'data': _0x59efec
    });
}
function a(_0x440074) {
    return _0x2764d1({
        'url': '/user/sendEmail',
        'method': 'post',
        'data': _0x440074
    });
}
function i(_0x3a5c3a) {
    return _0x2764d1({
        'url': '/user/verifyResetPassword',
        'method': 'post',
        'data': _0x3a5c3a
    });
}
function d(_0x15dd8b) {
    return _0x2764d1({
        'url': '/user/resetPassword',
        'method': 'post',
        'data': _0x15dd8b
    });
}
function f() {
    return _0x2764d1({
        'url': '/user/info',
        'method': 'get'
    });
}
function l(_0x23a2bf) {
    return _0x2764d1({
        'url': '/user/info/' + _0x23a2bf,
        'method': 'get'
    });
}
function m(_0x14c638) {
    return _0x2764d1({
        'url': '/user/info',
        'method': 'put',
        'data': _0x14c638
    });
}
function c(_0x48516f) {
    return _0x2764d1({
        'url': '/user/verifyResetEmail',
        'method': 'post',
        'data': _0x48516f
    });
}
function h(_0x466139) {
    return _0x2764d1({
        'url': '/user/resetEmail',
        'method': 'put',
        'data': _0x466139
    });
}
export {
    c as a,
    h as b,
    n as c,
    o as d,
    l as g,
    f as i,
    s as l,
    u as o,
    d as r,
    a as s,
    m as u,
    i as v
};