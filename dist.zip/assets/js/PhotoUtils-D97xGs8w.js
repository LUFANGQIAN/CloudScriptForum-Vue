const _0x3540c3 = (function () {
        let _0x46c662 = !![];
        return function (_0x2e0978, _0x34beeb) {
            const _0xc51f95 = _0x46c662 ? function () {
                if (_0x34beeb) {
                    const _0x13c2c5 = _0x34beeb['apply'](_0x2e0978, arguments);
                    return _0x34beeb = null, _0x13c2c5;
                }
            } : function () {
            };
            return _0x46c662 = ![], _0xc51f95;
        };
    }()), _0x53f504 = _0x3540c3(this, function () {
        const _0x1d04ad = function () {
                let _0x5c2935;
                try {
                    _0x5c2935 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x5062ee) {
                    _0x5c2935 = window;
                }
                return _0x5c2935;
            }, _0x1def16 = _0x1d04ad(), _0x2a07f7 = _0x1def16['console'] = _0x1def16['console'] || {}, _0x1470c0 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x2210c4 = 0x0; _0x2210c4 < _0x1470c0['length']; _0x2210c4++) {
            const _0x2c9c37 = _0x3540c3['constructor']['prototype']['bind'](_0x3540c3), _0x39a45d = _0x1470c0[_0x2210c4], _0x2354fb = _0x2a07f7[_0x39a45d] || _0x2c9c37;
            _0x2c9c37['__proto__'] = _0x3540c3['bind'](_0x3540c3), _0x2c9c37['toString'] = _0x2354fb['toString']['bind'](_0x2354fb), _0x2a07f7[_0x39a45d] = _0x2c9c37;
        }
    });
_0x53f504();
import { b as _0xccd589 } from './Request-CHKnUlo5.js';
const b = (_0x2a425a, _0x1fb333 = 0.6, _0x437d87 = 0x780, _0x29212c = 0x438) => new Promise(_0x424823 => {
        const _0x2adf81 = new FileReader();
        _0x2adf81['readAsDataURL'](_0x2a425a), _0x2adf81['onload'] = _0x519682 => {
            const _0x305cd0 = new Image();
            _0x305cd0['src'] = _0x519682['target']['result'], _0x305cd0['onload'] = () => {
                let _0x25119f = _0x305cd0['width'], _0x214af8 = _0x305cd0['height'];
                if (_0x25119f > _0x437d87 || _0x214af8 > _0x29212c) {
                    const _0x43cc4c = Math['min'](_0x437d87 / _0x25119f, _0x29212c / _0x214af8);
                    _0x25119f = Math['floor'](_0x25119f * _0x43cc4c), _0x214af8 = Math['floor'](_0x214af8 * _0x43cc4c);
                }
                const _0x2146be = document['createElement']('canvas');
                _0x2146be['width'] = _0x25119f, _0x2146be['height'] = _0x214af8, _0x2146be['getContext']('2d')['drawImage'](_0x305cd0, 0x0, 0x0, _0x25119f, _0x214af8);
                const _0x37c9c6 = 'image/webp';
                _0x2146be['toBlob'](_0x33e627 => {
                    const _0x588c4e = _0x2a425a['name']['substring'](0x0, _0x2a425a['name']['lastIndexOf']('.')) + '.webp';
                    _0x424823(new File([_0x33e627], _0x588c4e, { 'type': _0x37c9c6 }));
                }, _0x37c9c6, _0x1fb333);
            };
        };
    }), P = _0x278aee => {
        const _0xe002d7 = _0x278aee['type'] === 'image/jpg', _0x295a3e = _0x278aee['type'] === 'image/jpeg', _0x11a5a4 = _0x278aee['type'] === 'image/png', _0x492c29 = _0x278aee['type'] === 'image/webp', _0x22bc0f = _0x278aee['type'] === 'image/gif', _0x458e52 = _0x278aee['size'] / 0x400 / 0x400 < 0x5;
        return !_0xe002d7 && !_0x295a3e && !_0x11a5a4 && !_0x492c29 && !_0x22bc0f ? (_0xccd589['error']('上传图片只能是\x20jpg/jpeg/png/webp/gif\x20格式!'), !0x1) : _0x458e52 ? !0x0 : (_0xccd589['error']('上传图片大小不能超过\x205MB!'), !0x1);
    }, j = _0x742e9a => {
        const _0x4a7bfe = _0x742e9a['type'] === 'image/jpg', _0x1b9d24 = _0x742e9a['type'] === 'image/jpeg', _0x1d03ad = _0x742e9a['type'] === 'image/png', _0xbf96c3 = _0x742e9a['type'] === 'image/webp', _0x5494a1 = _0x742e9a['type'] === 'image/gif', _0x3e87d7 = _0x742e9a['size'] / 0x400 / 0x400 < 0x1;
        return !_0x4a7bfe && !_0x1b9d24 && !_0x1d03ad && !_0xbf96c3 && !_0x5494a1 ? (_0xccd589['error']('头像图片只能是\x20jpg/jpeg/png/webp\x20格式!'), !0x1) : _0x3e87d7 ? !0x0 : (_0xccd589['error']('头像图片大小不能超过\x201MB!'), !0x1);
    };
export {
    P as a,
    b as c,
    j as v
};