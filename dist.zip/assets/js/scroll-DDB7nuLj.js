const _0x3a2901 = (function () {
        let _0x1f27af = !![];
        return function (_0x13af85, _0x3f6985) {
            const _0x6bb99d = _0x1f27af ? function () {
                if (_0x3f6985) {
                    const _0x4facff = _0x3f6985['apply'](_0x13af85, arguments);
                    return _0x3f6985 = null, _0x4facff;
                }
            } : function () {
            };
            return _0x1f27af = ![], _0x6bb99d;
        };
    }()), _0x94e6f0 = _0x3a2901(this, function () {
        const _0x2989ee = function () {
                let _0x5095c1;
                try {
                    _0x5095c1 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x530160) {
                    _0x5095c1 = window;
                }
                return _0x5095c1;
            }, _0x95df94 = _0x2989ee(), _0x522011 = _0x95df94['console'] = _0x95df94['console'] || {}, _0x29ed3f = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0xa83fb3 = 0x0; _0xa83fb3 < _0x29ed3f['length']; _0xa83fb3++) {
            const _0x3f8c6d = _0x3a2901['constructor']['prototype']['bind'](_0x3a2901), _0x3db897 = _0x29ed3f[_0xa83fb3], _0x2886f4 = _0x522011[_0x3db897] || _0x3f8c6d;
            _0x3f8c6d['__proto__'] = _0x3a2901['bind'](_0x3a2901), _0x3f8c6d['toString'] = _0x2886f4['toString']['bind'](_0x2886f4), _0x522011[_0x3db897] = _0x3f8c6d;
        }
    });
_0x94e6f0();
import {
    n as _0x4dd1b7,
    O as _0x35c168
} from './Request-CHKnUlo5.js';
const p = (_0x5d4447, _0x1399bc) => {
        if (!_0x4dd1b7)
            return !0x1;
        const _0x3ecf7a = {
                'undefined': 'overflow',
                'true': 'overflow-y',
                'false': 'overflow-x'
            }[String(_0x1399bc)], _0x1363b2 = _0x35c168(_0x5d4447, _0x3ecf7a);
        return [
            'scroll',
            'auto',
            'overlay'
        ]['some'](_0x45697f => _0x1363b2['includes'](_0x45697f));
    }, w = (_0x10b006, _0x322bad) => {
        if (!_0x4dd1b7)
            return;
        let _0xd070ca = _0x10b006;
        for (; _0xd070ca;) {
            if ([
                    window,
                    document,
                    document['documentElement']
                ]['includes'](_0xd070ca))
                return window;
            if (p(_0xd070ca, _0x322bad))
                return _0xd070ca;
            _0xd070ca = _0xd070ca['parentNode'];
        }
        return _0xd070ca;
    };
let n;
const m = _0x45b808 => {
    var _0x588420;
    if (!_0x4dd1b7)
        return 0x0;
    if (n !== void 0x0)
        return n;
    const _0x2b79b0 = document['createElement']('div');
    _0x2b79b0['className'] = _0x45b808 + '-scrollbar__wrap', _0x2b79b0['style']['visibility'] = 'hidden', _0x2b79b0['style']['width'] = '100px', _0x2b79b0['style']['position'] = 'absolute', _0x2b79b0['style']['top'] = '-9999px', document['body']['appendChild'](_0x2b79b0);
    const _0x27d022 = _0x2b79b0['offsetWidth'];
    _0x2b79b0['style']['overflow'] = 'scroll';
    const _0x39c438 = document['createElement']('div');
    _0x39c438['style']['width'] = '100%', _0x2b79b0['appendChild'](_0x39c438);
    const _0x3a3f5b = _0x39c438['offsetWidth'];
    return (_0x588420 = _0x2b79b0['parentNode']) == null || _0x588420['removeChild'](_0x2b79b0), n = _0x27d022 - _0x3a3f5b, n;
};
function v(_0x4c85dc, _0x174e4e) {
    if (!_0x4dd1b7)
        return;
    if (!_0x174e4e) {
        _0x4c85dc['scrollTop'] = 0x0;
        return;
    }
    const _0x12439b = [];
    let _0x44d76b = _0x174e4e['offsetParent'];
    for (; _0x44d76b !== null && _0x4c85dc !== _0x44d76b && _0x4c85dc['contains'](_0x44d76b);)
        _0x12439b['push'](_0x44d76b), _0x44d76b = _0x44d76b['offsetParent'];
    const _0x2d44b6 = _0x174e4e['offsetTop'] + _0x12439b['reduce']((_0x3e2134, _0x40f88f) => _0x3e2134 + _0x40f88f['offsetTop'], 0x0), _0x2425ca = _0x2d44b6 + _0x174e4e['offsetHeight'], _0x4df287 = _0x4c85dc['scrollTop'], _0x5c5b69 = _0x4df287 + _0x4c85dc['clientHeight'];
    _0x2d44b6 < _0x4df287 ? _0x4c85dc['scrollTop'] = _0x2d44b6 : _0x2425ca > _0x5c5b69 && (_0x4c85dc['scrollTop'] = _0x2425ca - _0x4c85dc['clientHeight']);
}
export {
    m as a,
    w as g,
    v as s
};