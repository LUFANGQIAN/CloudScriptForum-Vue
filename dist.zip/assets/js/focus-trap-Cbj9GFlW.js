const _0x256d41 = (function () {
        let _0x761cb3 = !![];
        return function (_0x4fd434, _0x180eff) {
            const _0xb672d2 = _0x761cb3 ? function () {
                if (_0x180eff) {
                    const _0xcaaf9b = _0x180eff['apply'](_0x4fd434, arguments);
                    return _0x180eff = null, _0xcaaf9b;
                }
            } : function () {
            };
            return _0x761cb3 = ![], _0xb672d2;
        };
    }()), _0x3fbd32 = _0x256d41(this, function () {
        const _0x40b76a = function () {
                let _0x49ea29;
                try {
                    _0x49ea29 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x24b36b) {
                    _0x49ea29 = window;
                }
                return _0x49ea29;
            }, _0xa43339 = _0x40b76a(), _0x141f2e = _0xa43339['console'] = _0xa43339['console'] || {}, _0x1348fe = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x1aee14 = 0x0; _0x1aee14 < _0x1348fe['length']; _0x1aee14++) {
            const _0x548077 = _0x256d41['constructor']['prototype']['bind'](_0x256d41), _0x590cb0 = _0x1348fe[_0x1aee14], _0x5293b9 = _0x141f2e[_0x590cb0] || _0x548077;
            _0x548077['__proto__'] = _0x256d41['bind'](_0x256d41), _0x548077['toString'] = _0x5293b9['toString']['bind'](_0x5293b9), _0x141f2e[_0x590cb0] = _0x548077;
        }
    });
_0x3fbd32();
import { f as _0x4060db } from './aria-DyaK1nXM.js';
import {
    o as _0x2d69c0,
    a as _0x688582,
    r as _0x212610,
    X as _0x604293,
    a2 as _0xfbcdef,
    w as _0x1e3990,
    m as _0xbbaf49,
    a4 as _0x39163b,
    V as _0x4e2d30,
    aG as _0x5044b8
} from './index-54DmW9hq.js';
import {
    n as _0x3ac644,
    J as _0x107166,
    _ as _0x5c12a7,
    U as _0xd8e45f
} from './Request-CHKnUlo5.js';
const g = 'focus-trap.focus-after-trapped', R = 'focus-trap.focus-after-released', ue = 'focus-trap.focusout-prevented', j = {
        'cancelable': !0x0,
        'bubbles': !0x1
    }, ie = {
        'cancelable': !0x0,
        'bubbles': !0x1
    }, q = 'focusAfterTrapped', J = 'focusAfterReleased', de = Symbol('elFocusTrap'), k = _0x212610(), L = _0x212610(0x0), A = _0x212610(0x0);
let F = 0x0;
const Z = _0x2a1950 => {
        const _0x4f7bda = [], _0x546c82 = document['createTreeWalker'](_0x2a1950, NodeFilter['SHOW_ELEMENT'], {
                'acceptNode': _0x16fb93 => {
                    const _0x59135a = _0x16fb93['tagName'] === 'INPUT' && _0x16fb93['type'] === 'hidden';
                    return _0x16fb93['disabled'] || _0x16fb93['hidden'] || _0x59135a ? NodeFilter['FILTER_SKIP'] : _0x16fb93['tabIndex'] >= 0x0 || _0x16fb93 === document['activeElement'] ? NodeFilter['FILTER_ACCEPT'] : NodeFilter['FILTER_SKIP'];
                }
            });
        for (; _0x546c82['nextNode']();)
            _0x4f7bda['push'](_0x546c82['currentNode']);
        return _0x4f7bda;
    }, W = (_0xa170f4, _0x1c974c) => {
        for (const _0x3b976a of _0xa170f4)
            if (!fe(_0x3b976a, _0x1c974c))
                return _0x3b976a;
    }, fe = (_0x105861, _0x4e45c2) => {
        if (getComputedStyle(_0x105861)['visibility'] === 'hidden')
            return !0x0;
        for (; _0x105861;) {
            if (_0x4e45c2 && _0x105861 === _0x4e45c2)
                return !0x1;
            if (getComputedStyle(_0x105861)['display'] === 'none')
                return !0x0;
            _0x105861 = _0x105861['parentElement'];
        }
        return !0x1;
    }, le = _0x26a68f => {
        const _0x32233c = Z(_0x26a68f), _0x279cb4 = W(_0x32233c, _0x26a68f), _0x35ce21 = W(_0x32233c['reverse'](), _0x26a68f);
        return [
            _0x279cb4,
            _0x35ce21
        ];
    }, ve = _0x2cb343 => _0x2cb343 instanceof HTMLInputElement && 'select' in _0x2cb343, l = (_0x19bfe7, _0x4ec8c7) => {
        if (_0x19bfe7) {
            const _0x3639d4 = document['activeElement'];
            _0x4060db(_0x19bfe7, { 'preventScroll': !0x0 }), A['value'] = window['performance']['now'](), _0x19bfe7 !== _0x3639d4 && ve(_0x19bfe7) && _0x4ec8c7 && _0x19bfe7['select']();
        }
    };
function G(_0x1ed6b1, _0x437fbd) {
    const _0x8421cb = [..._0x1ed6b1], _0x3912c6 = _0x1ed6b1['indexOf'](_0x437fbd);
    return _0x3912c6 !== -0x1 && _0x8421cb['splice'](_0x3912c6, 0x1), _0x8421cb;
}
const Ee = () => {
        let _0x571a77 = [];
        return {
            'push': _0x4070e4 => {
                const _0x187aeb = _0x571a77[0x0];
                _0x187aeb && _0x4070e4 !== _0x187aeb && _0x187aeb['pause'](), _0x571a77 = G(_0x571a77, _0x4070e4), _0x571a77['unshift'](_0x4070e4);
            },
            'remove': _0x137423 => {
                var _0x2c2d08, _0x303e2b;
                _0x571a77 = G(_0x571a77, _0x137423), (_0x303e2b = (_0x2c2d08 = _0x571a77[0x0]) == null ? void 0x0 : _0x2c2d08['resume']) == null || _0x303e2b['call'](_0x2c2d08);
            }
        };
    }, pe = (_0x4ce215, _0x103e7b = !0x1) => {
        const _0x3415ef = document['activeElement'];
        for (const _0x1f8e2a of _0x4ce215)
            if (l(_0x1f8e2a, _0x103e7b), document['activeElement'] !== _0x3415ef)
                return;
    }, X = Ee(), me = () => L['value'] > A['value'], _ = () => {
        k['value'] = 'pointer', L['value'] = window['performance']['now']();
    }, Y = () => {
        k['value'] = 'keyboard', L['value'] = window['performance']['now']();
    }, Te = () => (_0x2d69c0(() => {
        F === 0x0 && (document['addEventListener']('mousedown', _), document['addEventListener']('touchstart', _), document['addEventListener']('keydown', Y)), F++;
    }), _0x688582(() => {
        F--, F <= 0x0 && (document['removeEventListener']('mousedown', _), document['removeEventListener']('touchstart', _), document['removeEventListener']('keydown', Y));
    }), {
        'focusReason': k,
        'lastUserFocusTimestamp': L,
        'lastAutomatedFocusTimestamp': A
    }), b = _0x988657 => new CustomEvent(ue, {
        ...ie,
        'detail': _0x988657
    });
let E = [];
const z = _0xa6a35f => {
        _0xa6a35f['code'] === _0x107166['esc'] && E['forEach'](_0x34eaa5 => _0x34eaa5(_0xa6a35f));
    }, Fe = _0x390331 => {
        _0x2d69c0(() => {
            E['length'] === 0x0 && document['addEventListener']('keydown', z), _0x3ac644 && E['push'](_0x390331);
        }), _0x688582(() => {
            E = E['filter'](_0x3abcf7 => _0x3abcf7 !== _0x390331), E['length'] === 0x0 && _0x3ac644 && document['removeEventListener']('keydown', z);
        });
    }, _e = _0x604293({
        'name': 'ElFocusTrap',
        'inheritAttrs': !0x1,
        'props': {
            'loop': Boolean,
            'trapped': Boolean,
            'focusTrapEl': Object,
            'focusStartEl': {
                'type': [
                    Object,
                    String
                ],
                'default': 'first'
            }
        },
        'emits': [
            q,
            J,
            'focusin',
            'focusout',
            'focusout-prevented',
            'release-requested'
        ],
        'setup'(_0x1e0d35, {emit: _0x37ce1f}) {
            const _0x330fe9 = _0x212610();
            let _0x4645f8, _0xe125a4;
            const {focusReason: _0x1fb291} = Te();
            Fe(_0x3b1ac7 => {
                _0x1e0d35['trapped'] && !_0xf58e76['paused'] && _0x37ce1f('release-requested', _0x3b1ac7);
            });
            const _0xf58e76 = {
                    'paused': !0x1,
                    'pause'() {
                        this['paused'] = !0x0;
                    },
                    'resume'() {
                        this['paused'] = !0x1;
                    }
                }, _0x452a47 = _0x3916f4 => {
                    if (!_0x1e0d35['loop'] && !_0x1e0d35['trapped'] || _0xf58e76['paused'])
                        return;
                    const {
                            code: _0x4ac955,
                            altKey: _0x501eec,
                            ctrlKey: _0x519f60,
                            metaKey: _0x3a6b79,
                            currentTarget: _0x48e402,
                            shiftKey: _0x59c7d2
                        } = _0x3916f4, {loop: _0x20d57c} = _0x1e0d35, _0x4ad975 = _0x4ac955 === _0x107166['tab'] && !_0x501eec && !_0x519f60 && !_0x3a6b79, _0x44b252 = document['activeElement'];
                    if (_0x4ad975 && _0x44b252) {
                        const _0x2f2562 = _0x48e402, [_0x567b03, _0x20cdac] = le(_0x2f2562);
                        if (_0x567b03 && _0x20cdac) {
                            if (!_0x59c7d2 && _0x44b252 === _0x20cdac) {
                                const _0x104c98 = b({ 'focusReason': _0x1fb291['value'] });
                                _0x37ce1f('focusout-prevented', _0x104c98), _0x104c98['defaultPrevented'] || (_0x3916f4['preventDefault'](), _0x20d57c && l(_0x567b03, !0x0));
                            } else {
                                if (_0x59c7d2 && [
                                        _0x567b03,
                                        _0x2f2562
                                    ]['includes'](_0x44b252)) {
                                    const _0x4f4c6a = b({ 'focusReason': _0x1fb291['value'] });
                                    _0x37ce1f('focusout-prevented', _0x4f4c6a), _0x4f4c6a['defaultPrevented'] || (_0x3916f4['preventDefault'](), _0x20d57c && l(_0x20cdac, !0x0));
                                }
                            }
                        } else {
                            if (_0x44b252 === _0x2f2562) {
                                const _0x3ec16f = b({ 'focusReason': _0x1fb291['value'] });
                                _0x37ce1f('focusout-prevented', _0x3ec16f), _0x3ec16f['defaultPrevented'] || _0x3916f4['preventDefault']();
                            }
                        }
                    }
                };
            _0x5044b8(de, {
                'focusTrapRef': _0x330fe9,
                'onKeydown': _0x452a47
            }), _0x1e3990(() => _0x1e0d35['focusTrapEl'], _0x474f7d => {
                _0x474f7d && (_0x330fe9['value'] = _0x474f7d);
            }, { 'immediate': !0x0 }), _0x1e3990([_0x330fe9], ([_0x3ef6c7], [_0x1d3402]) => {
                _0x3ef6c7 && (_0x3ef6c7['addEventListener']('keydown', _0x452a47), _0x3ef6c7['addEventListener']('focusin', _0x531fb1), _0x3ef6c7['addEventListener']('focusout', _0x123e8e)), _0x1d3402 && (_0x1d3402['removeEventListener']('keydown', _0x452a47), _0x1d3402['removeEventListener']('focusin', _0x531fb1), _0x1d3402['removeEventListener']('focusout', _0x123e8e));
            });
            const _0x1a265e = _0x4e9e3f => {
                    _0x37ce1f(q, _0x4e9e3f);
                }, _0x1c06a9 = _0x25a0f7 => _0x37ce1f(J, _0x25a0f7), _0x531fb1 = _0x5d642a => {
                    const _0x13b702 = _0xbbaf49(_0x330fe9);
                    if (!_0x13b702)
                        return;
                    const _0x49dc4a = _0x5d642a['target'], _0x1a8844 = _0x5d642a['relatedTarget'], _0x52234c = _0x49dc4a && _0x13b702['contains'](_0x49dc4a);
                    _0x1e0d35['trapped'] || _0x1a8844 && _0x13b702['contains'](_0x1a8844) || (_0x4645f8 = _0x1a8844), _0x52234c && _0x37ce1f('focusin', _0x5d642a), !_0xf58e76['paused'] && _0x1e0d35['trapped'] && (_0x52234c ? _0xe125a4 = _0x49dc4a : l(_0xe125a4, !0x0));
                }, _0x123e8e = _0x3f08a8 => {
                    const _0x55633a = _0xbbaf49(_0x330fe9);
                    if (!(_0xf58e76['paused'] || !_0x55633a)) {
                        if (_0x1e0d35['trapped']) {
                            const _0x37bfc2 = _0x3f08a8['relatedTarget'];
                            !_0xd8e45f(_0x37bfc2) && !_0x55633a['contains'](_0x37bfc2) && setTimeout(() => {
                                if (!_0xf58e76['paused'] && _0x1e0d35['trapped']) {
                                    const _0x41c792 = b({ 'focusReason': _0x1fb291['value'] });
                                    _0x37ce1f('focusout-prevented', _0x41c792), _0x41c792['defaultPrevented'] || l(_0xe125a4, !0x0);
                                }
                            }, 0x0);
                        } else {
                            const _0x4271ec = _0x3f08a8['target'];
                            _0x4271ec && _0x55633a['contains'](_0x4271ec) || _0x37ce1f('focusout', _0x3f08a8);
                        }
                    }
                };
            async function _0x2b79bb() {
                await _0x39163b();
                const _0x228090 = _0xbbaf49(_0x330fe9);
                if (_0x228090) {
                    X['push'](_0xf58e76);
                    const _0x3a6533 = _0x228090['contains'](document['activeElement']) ? _0x4645f8 : document['activeElement'];
                    if (_0x4645f8 = _0x3a6533, !_0x228090['contains'](_0x3a6533)) {
                        const _0x41dcf8 = new Event(g, j);
                        _0x228090['addEventListener'](g, _0x1a265e), _0x228090['dispatchEvent'](_0x41dcf8), _0x41dcf8['defaultPrevented'] || _0x39163b(() => {
                            let _0x10e65a = _0x1e0d35['focusStartEl'];
                            _0x4e2d30(_0x10e65a) || (l(_0x10e65a), document['activeElement'] !== _0x10e65a && (_0x10e65a = 'first')), _0x10e65a === 'first' && pe(Z(_0x228090), !0x0), (document['activeElement'] === _0x3a6533 || _0x10e65a === 'container') && l(_0x228090);
                        });
                    }
                }
            }
            function _0x42e355() {
                const _0x210334 = _0xbbaf49(_0x330fe9);
                if (_0x210334) {
                    _0x210334['removeEventListener'](g, _0x1a265e);
                    const _0x558924 = new CustomEvent(R, {
                        ...j,
                        'detail': { 'focusReason': _0x1fb291['value'] }
                    });
                    _0x210334['addEventListener'](R, _0x1c06a9), _0x210334['dispatchEvent'](_0x558924), !_0x558924['defaultPrevented'] && (_0x1fb291['value'] == 'keyboard' || !me() || _0x210334['contains'](document['activeElement'])) && l(_0x4645f8 ?? document['body']), _0x210334['removeEventListener'](R, _0x1c06a9), X['remove'](_0xf58e76), _0x4645f8 = null, _0xe125a4 = null;
                }
            }
            return _0x2d69c0(() => {
                _0x1e0d35['trapped'] && _0x2b79bb(), _0x1e3990(() => _0x1e0d35['trapped'], _0xa66047 => {
                    _0xa66047 ? _0x2b79bb() : _0x42e355();
                });
            }), _0x688582(() => {
                _0x1e0d35['trapped'] && _0x42e355(), _0x330fe9['value'] && (_0x330fe9['value']['removeEventListener']('keydown', _0x452a47), _0x330fe9['value']['removeEventListener']('focusin', _0x531fb1), _0x330fe9['value']['removeEventListener']('focusout', _0x123e8e), _0x330fe9['value'] = void 0x0);
            }), { 'onKeydown': _0x452a47 };
        }
    });
function be(_0x19aeba, _0xc7ef37, _0x2e5e0e, _0x54516b, _0x1f56f6, _0x2a5279) {
    return _0xfbcdef(_0x19aeba['$slots'], 'default', { 'handleKeydown': _0x19aeba['onKeydown'] });
}
var we = _0x5c12a7(_e, [
    [
        'render',
        be
    ],
    [
        '__file',
        'focus-trap.vue'
    ]
]);
export {
    we as E,
    de as F
};