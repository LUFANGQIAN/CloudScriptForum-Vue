const _0x55de2d = (function () {
        let _0x434923 = !![];
        return function (_0x2dc346, _0x46c3b1) {
            const _0x2908f7 = _0x434923 ? function () {
                if (_0x46c3b1) {
                    const _0x1d3733 = _0x46c3b1['apply'](_0x2dc346, arguments);
                    return _0x46c3b1 = null, _0x1d3733;
                }
            } : function () {
            };
            return _0x434923 = ![], _0x2908f7;
        };
    }()), _0x15149b = _0x55de2d(this, function () {
        const _0x1c68fd = function () {
                let _0x155f5b;
                try {
                    _0x155f5b = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0xca0350) {
                    _0x155f5b = window;
                }
                return _0x155f5b;
            }, _0xae998f = _0x1c68fd(), _0x368a2d = _0xae998f['console'] = _0xae998f['console'] || {}, _0x30e501 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x5cb79a = 0x0; _0x5cb79a < _0x30e501['length']; _0x5cb79a++) {
            const _0x266060 = _0x55de2d['constructor']['prototype']['bind'](_0x55de2d), _0x496b6b = _0x30e501[_0x5cb79a], _0x274be2 = _0x368a2d[_0x496b6b] || _0x266060;
            _0x266060['__proto__'] = _0x55de2d['bind'](_0x55de2d), _0x266060['toString'] = _0x274be2['toString']['bind'](_0x274be2), _0x368a2d[_0x496b6b] = _0x266060;
        }
    });
_0x15149b();
import {
    a3 as _0x1e1449,
    aN as _0x59eb4d
} from './index-54DmW9hq.js';
var o = (_0x3d9d26 => (_0x3d9d26[_0x3d9d26['TEXT'] = 0x1] = 'TEXT', _0x3d9d26[_0x3d9d26['CLASS'] = 0x2] = 'CLASS', _0x3d9d26[_0x3d9d26['STYLE'] = 0x4] = 'STYLE', _0x3d9d26[_0x3d9d26['PROPS'] = 0x8] = 'PROPS', _0x3d9d26[_0x3d9d26['FULL_PROPS'] = 0x10] = 'FULL_PROPS', _0x3d9d26[_0x3d9d26['HYDRATE_EVENTS'] = 0x20] = 'HYDRATE_EVENTS', _0x3d9d26[_0x3d9d26['STABLE_FRAGMENT'] = 0x40] = 'STABLE_FRAGMENT', _0x3d9d26[_0x3d9d26['KEYED_FRAGMENT'] = 0x80] = 'KEYED_FRAGMENT', _0x3d9d26[_0x3d9d26['UNKEYED_FRAGMENT'] = 0x100] = 'UNKEYED_FRAGMENT', _0x3d9d26[_0x3d9d26['NEED_PATCH'] = 0x200] = 'NEED_PATCH', _0x3d9d26[_0x3d9d26['DYNAMIC_SLOTS'] = 0x400] = 'DYNAMIC_SLOTS', _0x3d9d26[_0x3d9d26['HOISTED'] = -0x1] = 'HOISTED', _0x3d9d26[_0x3d9d26['BAIL'] = -0x2] = 'BAIL', _0x3d9d26))(o || {});
const S = _0x4320d9 => {
    const _0x79208a = _0x1e1449(_0x4320d9) ? _0x4320d9 : [_0x4320d9], _0x3113a4 = [];
    return _0x79208a['forEach'](_0x5cfacb => {
        var _0x504d79;
        _0x1e1449(_0x5cfacb) ? _0x3113a4['push'](...S(_0x5cfacb)) : _0x59eb4d(_0x5cfacb) && ((_0x504d79 = _0x5cfacb['component']) != null && _0x504d79['subTree']) ? _0x3113a4['push'](_0x5cfacb, ...S(_0x5cfacb['component']['subTree'])) : _0x59eb4d(_0x5cfacb) && _0x1e1449(_0x5cfacb['children']) ? _0x3113a4['push'](...S(_0x5cfacb['children'])) : _0x59eb4d(_0x5cfacb) && _0x5cfacb['shapeFlag'] === 0x2 ? _0x3113a4['push'](...S(_0x5cfacb['type']())) : _0x3113a4['push'](_0x5cfacb);
    }), _0x3113a4;
};
export {
    o as P,
    S as f
};