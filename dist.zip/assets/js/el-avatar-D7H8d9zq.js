const _0x5ceb63 = (function () {
        let _0xb1189c = !![];
        return function (_0x599821, _0x4e7c6b) {
            const _0x2eb821 = _0xb1189c ? function () {
                if (_0x4e7c6b) {
                    const _0x3d92fd = _0x4e7c6b['apply'](_0x599821, arguments);
                    return _0x4e7c6b = null, _0x3d92fd;
                }
            } : function () {
            };
            return _0xb1189c = ![], _0x2eb821;
        };
    }()), _0x2f6115 = _0x5ceb63(this, function () {
        const _0x59c9de = function () {
                let _0x40390a;
                try {
                    _0x40390a = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x29c2da) {
                    _0x40390a = window;
                }
                return _0x40390a;
            }, _0x34ad18 = _0x59c9de(), _0x32ea48 = _0x34ad18['console'] = _0x34ad18['console'] || {}, _0x1eac10 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0xb8920d = 0x0; _0xb8920d < _0x1eac10['length']; _0xb8920d++) {
            const _0x32587a = _0x5ceb63['constructor']['prototype']['bind'](_0x5ceb63), _0x5a8bae = _0x1eac10[_0xb8920d], _0x409f54 = _0x32ea48[_0x5a8bae] || _0x32587a;
            _0x32587a['__proto__'] = _0x5ceb63['bind'](_0x5ceb63), _0x32587a['toString'] = _0x409f54['toString']['bind'](_0x409f54), _0x32ea48[_0x5a8bae] = _0x32587a;
        }
    });
_0x2f6115();
import {
    c as _0x4d85e4,
    d as _0x37d453,
    j as _0x5b9072,
    i as _0x1f3f24,
    a1 as _0x3a54ba,
    _ as _0x2a0f3e,
    e as _0x35a135,
    k as _0x5bdfdb,
    a as _0x452c31,
    w as _0x4471fc
} from './Request-CHKnUlo5.js';
import {
    X as _0x195de1,
    r as _0x3c1679,
    Y as _0x2280eb,
    V as _0x4be2ad,
    w as _0x27e031,
    c as _0x2a22d7,
    b as _0x310513,
    e as _0x2ce1a6,
    a2 as _0x4aa04c,
    $ as _0x3f13d7,
    m as _0x13f4b9,
    f as _0x1c8eed,
    ak as _0x363b02,
    z as _0xcde15c
} from './index-54DmW9hq.js';
const q = _0x4d85e4({
        'size': {
            'type': [
                Number,
                String
            ],
            'values': _0x3a54ba,
            'default': '',
            'validator': _0x14b4e3 => _0x1f3f24(_0x14b4e3)
        },
        'shape': {
            'type': String,
            'values': [
                'circle',
                'square'
            ],
            'default': 'circle'
        },
        'icon': { 'type': _0x5b9072 },
        'src': {
            'type': String,
            'default': ''
        },
        'alt': String,
        'srcSet': String,
        'fit': {
            'type': _0x37d453(String),
            'default': 'cover'
        }
    }), D = { 'error': _0x2a3667 => _0x2a3667 instanceof Event }, F = _0x195de1({ 'name': 'ElAvatar' }), U = _0x195de1({
        ...F,
        'props': q,
        'emits': D,
        'setup'(_0x285aa9, {emit: _0x5705fc}) {
            const _0x2c3e1c = _0x285aa9, _0x4130cf = _0x35a135('avatar'), _0x1b2283 = _0x3c1679(!0x1), _0x1df023 = _0x2280eb(() => {
                    const {
                            size: _0x436ad1,
                            icon: _0x3c8a39,
                            shape: _0x26428c
                        } = _0x2c3e1c, _0x3e7268 = [_0x4130cf['b']()];
                    return _0x4be2ad(_0x436ad1) && _0x3e7268['push'](_0x4130cf['m'](_0x436ad1)), _0x3c8a39 && _0x3e7268['push'](_0x4130cf['m']('icon')), _0x26428c && _0x3e7268['push'](_0x4130cf['m'](_0x26428c)), _0x3e7268;
                }), _0x42c56a = _0x2280eb(() => {
                    const {size: _0x4cfe77} = _0x2c3e1c;
                    return _0x1f3f24(_0x4cfe77) ? _0x4130cf['cssVarBlock']({ 'size': _0x5bdfdb(_0x4cfe77) || '' }) : void 0x0;
                }), _0x43d72f = _0x2280eb(() => ({ 'objectFit': _0x2c3e1c['fit'] }));
            _0x27e031(() => _0x2c3e1c['src'], () => _0x1b2283['value'] = !0x1);
            function _0x96a4f8(_0x5ef78b) {
                _0x1b2283['value'] = !0x0, _0x5705fc('error', _0x5ef78b);
            }
            return (_0x3b74d2, _0x21cc87) => (_0x310513(), _0x2a22d7('span', {
                'class': _0xcde15c(_0x13f4b9(_0x1df023)),
                'style': _0x3f13d7(_0x13f4b9(_0x42c56a))
            }, [(_0x3b74d2['src'] || _0x3b74d2['srcSet']) && !_0x1b2283['value'] ? (_0x310513(), _0x2a22d7('img', {
                    'key': 0x0,
                    'src': _0x3b74d2['src'],
                    'alt': _0x3b74d2['alt'],
                    'srcset': _0x3b74d2['srcSet'],
                    'style': _0x3f13d7(_0x13f4b9(_0x43d72f)),
                    'onError': _0x96a4f8
                }, null, 0x2c, [
                    'src',
                    'alt',
                    'srcset'
                ])) : _0x3b74d2['icon'] ? (_0x310513(), _0x2ce1a6(_0x13f4b9(_0x452c31), { 'key': 0x1 }, {
                    'default': _0x1c8eed(() => [(_0x310513(), _0x2ce1a6(_0x363b02(_0x3b74d2['icon'])))]),
                    '_': 0x1
                })) : _0x4aa04c(_0x3b74d2['$slots'], 'default', { 'key': 0x2 })], 0x6));
        }
    });
var X = _0x2a0f3e(U, [[
        '__file',
        'avatar.vue'
    ]]);
const H = _0x4471fc(X);
export {
    H as E
};