const _0x30fcef = (function () {
        let _0xb15342 = !![];
        return function (_0x504c44, _0x42de62) {
            const _0x3a5e12 = _0xb15342 ? function () {
                if (_0x42de62) {
                    const _0xf5f663 = _0x42de62['apply'](_0x504c44, arguments);
                    return _0x42de62 = null, _0xf5f663;
                }
            } : function () {
            };
            return _0xb15342 = ![], _0x3a5e12;
        };
    }()), _0x345bf6 = _0x30fcef(this, function () {
        let _0x456c1f;
        try {
            const _0x211b5c = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x456c1f = _0x211b5c();
        } catch (_0x266aae) {
            _0x456c1f = window;
        }
        const _0x2a207c = _0x456c1f['console'] = _0x456c1f['console'] || {}, _0xad659c = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x194cce = 0x0; _0x194cce < _0xad659c['length']; _0x194cce++) {
            const _0x3e0b23 = _0x30fcef['constructor']['prototype']['bind'](_0x30fcef), _0x48161f = _0xad659c[_0x194cce], _0x3ad974 = _0x2a207c[_0x48161f] || _0x3e0b23;
            _0x3e0b23['__proto__'] = _0x30fcef['bind'](_0x30fcef), _0x3e0b23['toString'] = _0x3ad974['toString']['bind'](_0x3ad974), _0x2a207c[_0x48161f] = _0x3e0b23;
        }
    });
_0x345bf6();
import {
    a as _0x3726a9,
    b as _0x2d4115
} from './Request-CHKnUlo5.js';
import {
    E as _0x139621,
    a as _0x249f0c
} from './el-skeleton-item-BG_lS1DD.js';
import {
    _ as _0x35a082,
    r as _0x1eece6,
    o as _0x5112a2,
    c as _0x13d870,
    g as _0xcc2930,
    ah as _0x879928,
    d as _0x5cdc42,
    f as _0x2db650,
    i as _0x2b7aa1,
    t as _0x449d37,
    h as _0x4a847d,
    u as _0x1438e1,
    b as _0x3cbd67,
    m as _0x3a6acf,
    J as _0x29295f,
    aP as _0x8b9a82,
    N as _0x2f86f5,
    aU as _0x544619,
    aE as _0x36c2a7,
    n as _0x5bb7fa,
    M as _0x2d03c5,
    v as _0xd975eb,
    K as _0x238bab,
    aQ as _0x6869c,
    an as _0x3916f9,
    ac as _0x182fb3
} from './index-54DmW9hq.js';
import { i as _0x3ee1a5 } from './article-IrYQ22on.js';
const nt = { 'class': 'creation-home' }, et = { 'class': 'welcome-banner' }, dt = { 'class': 'banner-content' }, ct = { 'class': 'quick-actions' }, _t = {
        'href': '/editor',
        'target': '_blank',
        'class': 'action-btn\x20primary'
    }, rt = { 'class': 'statistics-section' }, vt = {
        'key': 0x0,
        'class': 'statistics-grid'
    }, ut = { 'class': 'stat-card\x20article-stats' }, pt = { 'class': 'stat-header' }, ft = { 'class': 'stat-icon\x20article' }, mt = { 'class': 'stat-info' }, ht = { 'class': 'stat-total' }, gt = { 'class': 'stat-details' }, kt = { 'class': 'detail-item' }, xt = { 'class': 'value\x20published' }, Ct = { 'class': 'detail-item' }, wt = { 'class': 'value\x20draft' }, bt = { 'class': 'detail-item' }, yt = { 'class': 'value\x20reviewing' }, St = { 'class': 'stat-card' }, Et = { 'class': 'stat-header' }, Mt = { 'class': 'stat-icon\x20column' }, Nt = { 'class': 'stat-info' }, Tt = { 'class': 'stat-total' }, Bt = { 'class': 'stat-action' }, It = { 'class': 'stat-card' }, Vt = { 'class': 'stat-header' }, qt = { 'class': 'stat-icon\x20comment' }, Lt = { 'class': 'stat-info' }, Rt = { 'class': 'stat-total' }, At = { 'class': 'stat-action' }, Dt = { 'class': 'stat-card' }, Ft = { 'class': 'stat-header' }, Jt = { 'class': 'stat-icon\x20read' }, Kt = { 'class': 'stat-info' }, Pt = { 'class': 'stat-total' }, Qt = { 'class': 'stat-card' }, Ut = { 'class': 'stat-header' }, $t = { 'class': 'stat-icon\x20like' }, jt = { 'class': 'stat-info' }, zt = { 'class': 'stat-total' }, Gt = { 'class': 'stat-card' }, Ht = { 'class': 'stat-header' }, Ot = { 'class': 'stat-icon\x20fans' }, Wt = { 'class': 'stat-info' }, Xt = { 'class': 'stat-total' }, Yt = {
        'key': 0x1,
        'class': 'statistics-loading'
    }, Zt = { 'class': 'skeleton-card' }, ts = { 'class': 'skeleton-content' }, ss = { 'class': 'quick-tools-section' }, as = { 'class': 'tools-grid' }, os = { 'class': 'tool-icon\x20create' }, ls = { 'class': 'tool-icon\x20manage' }, is = { 'class': 'tool-icon\x20column' }, ns = { 'class': 'tool-icon\x20comment' }, es = {
        '__name': 'index',
        'setup'(_0x3c1b63) {
            const _0x166d4b = _0x1438e1(), _0x187c01 = _0x1eece6(!0x1), _0x58d42c = _0x1eece6(null), _0x2ad326 = _0x31c2d5 => _0x31c2d5 >= 0x2710 ? (_0x31c2d5 / 0x2710)['toFixed'](0x1) + '万' : _0x31c2d5['toString'](), _0x42befc = async () => {
                    try {
                        _0x187c01['value'] = !0x0;
                        const _0x3ac1ea = await _0x3ee1a5();
                        _0x58d42c['value'] = _0x3ac1ea['data']['data'];
                    } catch (_0x1153c7) {
                        _0x2d4115['error']('获取统计数据失败'), console['error']('获取统计数据失败:', _0x1153c7);
                    } finally {
                        _0x187c01['value'] = !0x1;
                    }
                }, _0x548b88 = () => {
                    window['open']('/editor', '_blank');
                }, _0x183846 = () => {
                    _0x166d4b['push']('/creation/articlemanage');
                }, _0x1a9456 = () => {
                    _0x166d4b['push']('/creation/columnmanage');
                }, _0x181cad = () => {
                    _0x166d4b['push']('/creation/commentmanage');
                };
            return _0x5112a2(() => {
                _0x42befc();
            }), (_0x156664, _0x51f951) => {
                var _0x179a5e, _0x590b8d, _0x53fe23, _0x4a602b, _0x3a13ff, _0x1a0f4a, _0x4b1e44, _0x255312, _0x2b392a, _0x211c7e, _0x21a130, _0x55d624, _0x20f0a2;
                const _0x2fd0a0 = _0x3726a9, _0x43a974 = _0x2b7aa1('router-link'), _0x2a7220 = _0x4a847d, _0x5352dc = _0x249f0c, _0x4a84d3 = _0x139621;
                return _0x3cbd67(), _0x13d870('div', nt, [
                    _0xcc2930('div', et, [_0xcc2930('div', dt, [
                            _0x51f951[0x2] || (_0x51f951[0x2] = _0xcc2930('div', { 'class': 'welcome-text' }, [
                                _0xcc2930('h1', { 'class': 'welcome-title' }, '欢迎回到创作中心'),
                                _0xcc2930('p', { 'class': 'welcome-subtitle' }, '分享您的想法，记录美好时光')
                            ], -0x1)),
                            _0xcc2930('div', ct, [
                                _0xcc2930('a', _t, [
                                    _0x5cdc42(_0x2fd0a0, null, {
                                        'default': _0x2db650(() => [_0x5cdc42(_0x3a6acf(_0x29295f))]),
                                        '_': 0x1
                                    }),
                                    _0x51f951[0x0] || (_0x51f951[0x0] = _0xcc2930('span', null, '开始创作', -0x1))
                                ]),
                                _0x5cdc42(_0x43a974, {
                                    'to': '/creation/articlemanage',
                                    'class': 'action-btn\x20secondary'
                                }, {
                                    'default': _0x2db650(() => [
                                        _0x5cdc42(_0x2fd0a0, null, {
                                            'default': _0x2db650(() => [_0x5cdc42(_0x3a6acf(_0x8b9a82))]),
                                            '_': 0x1
                                        }),
                                        _0x51f951[0x1] || (_0x51f951[0x1] = _0xcc2930('span', null, '管理文章', -0x1))
                                    ]),
                                    '_': 0x1,
                                    '__': [0x1]
                                })
                            ])
                        ])]),
                    _0xcc2930('div', rt, [
                        _0x51f951[0x11] || (_0x51f951[0x11] = _0xcc2930('div', { 'class': 'section-title' }, [
                            _0xcc2930('h2', null, '数据概览'),
                            _0xcc2930('p', null, '了解您的创作表现')
                        ], -0x1)),
                        _0x187c01['value'] ? (_0x3cbd67(), _0x13d870('div', Yt, [_0x5cdc42(_0x4a84d3, {
                                'animated': '',
                                'count': 0x6
                            }, {
                                'template': _0x2db650(() => [_0xcc2930('div', Zt, [
                                        _0x5cdc42(_0x5352dc, {
                                            'variant': 'circle',
                                            'style': {
                                                'width': '60px',
                                                'height': '60px'
                                            }
                                        }),
                                        _0xcc2930('div', ts, [
                                            _0x5cdc42(_0x5352dc, {
                                                'variant': 'h3',
                                                'style': {
                                                    'width': '80px',
                                                    'margin': '8px\x200'
                                                }
                                            }),
                                            _0x5cdc42(_0x5352dc, {
                                                'variant': 'text',
                                                'style': { 'width': '120px' }
                                            })
                                        ])
                                    ])]),
                                '_': 0x1
                            })])) : (_0x3cbd67(), _0x13d870('div', vt, [
                            _0xcc2930('div', ut, [
                                _0xcc2930('div', pt, [
                                    _0xcc2930('div', ft, [_0x5cdc42(_0x2fd0a0, null, {
                                            'default': _0x2db650(() => [_0x5cdc42(_0x3a6acf(_0x2f86f5))]),
                                            '_': 0x1
                                        })]),
                                    _0xcc2930('div', mt, [
                                        _0x51f951[0x3] || (_0x51f951[0x3] = _0xcc2930('h3', null, '文章', -0x1)),
                                        _0xcc2930('p', ht, _0x449d37(((_0x590b8d = (_0x179a5e = _0x58d42c['value']) == null ? void 0x0 : _0x179a5e['articleStatistics']) == null ? void 0x0 : _0x590b8d['totalCount']) || 0x0), 0x1)
                                    ])
                                ]),
                                _0xcc2930('div', gt, [
                                    _0xcc2930('div', kt, [
                                        _0x51f951[0x4] || (_0x51f951[0x4] = _0xcc2930('span', { 'class': 'label' }, '已发布', -0x1)),
                                        _0xcc2930('span', xt, _0x449d37(((_0x4a602b = (_0x53fe23 = _0x58d42c['value']) == null ? void 0x0 : _0x53fe23['articleStatistics']) == null ? void 0x0 : _0x4a602b['publishedCount']) || 0x0), 0x1)
                                    ]),
                                    _0xcc2930('div', Ct, [
                                        _0x51f951[0x5] || (_0x51f951[0x5] = _0xcc2930('span', { 'class': 'label' }, '草稿', -0x1)),
                                        _0xcc2930('span', wt, _0x449d37(((_0x1a0f4a = (_0x3a13ff = _0x58d42c['value']) == null ? void 0x0 : _0x3a13ff['articleStatistics']) == null ? void 0x0 : _0x1a0f4a['draftCount']) || 0x0), 0x1)
                                    ]),
                                    _0xcc2930('div', bt, [
                                        _0x51f951[0x6] || (_0x51f951[0x6] = _0xcc2930('span', { 'class': 'label' }, '审核中', -0x1)),
                                        _0xcc2930('span', yt, _0x449d37(((_0x255312 = (_0x4b1e44 = _0x58d42c['value']) == null ? void 0x0 : _0x4b1e44['articleStatistics']) == null ? void 0x0 : _0x255312['reviewingCount']) || 0x0), 0x1)
                                    ])
                                ])
                            ]),
                            _0xcc2930('div', St, [
                                _0xcc2930('div', Et, [
                                    _0xcc2930('div', Mt, [_0x5cdc42(_0x2fd0a0, null, {
                                            'default': _0x2db650(() => [_0x5cdc42(_0x3a6acf(_0x544619))]),
                                            '_': 0x1
                                        })]),
                                    _0xcc2930('div', Nt, [
                                        _0x51f951[0x7] || (_0x51f951[0x7] = _0xcc2930('h3', null, '专栏', -0x1)),
                                        _0xcc2930('p', Tt, _0x449d37(((_0x2b392a = _0x58d42c['value']) == null ? void 0x0 : _0x2b392a['columnCount']) || 0x0), 0x1)
                                    ])
                                ]),
                                _0xcc2930('div', Bt, [_0x5cdc42(_0x43a974, {
                                        'to': '/creation/columnmanage',
                                        'class': 'manage-link'
                                    }, {
                                        'default': _0x2db650(() => [
                                            _0x51f951[0x8] || (_0x51f951[0x8] = _0xcc2930('span', null, '管理专栏', -0x1)),
                                            _0x5cdc42(_0x2fd0a0, null, {
                                                'default': _0x2db650(() => [_0x5cdc42(_0x3a6acf(_0x36c2a7))]),
                                                '_': 0x1
                                            })
                                        ]),
                                        '_': 0x1,
                                        '__': [0x8]
                                    })])
                            ]),
                            _0xcc2930('div', It, [
                                _0xcc2930('div', Vt, [
                                    _0xcc2930('div', qt, [_0x5cdc42(_0x2fd0a0, null, {
                                            'default': _0x2db650(() => [_0x5cdc42(_0x3a6acf(_0x5bb7fa))]),
                                            '_': 0x1
                                        })]),
                                    _0xcc2930('div', Lt, [
                                        _0x51f951[0x9] || (_0x51f951[0x9] = _0xcc2930('h3', null, '评论', -0x1)),
                                        _0xcc2930('p', Rt, _0x449d37(((_0x211c7e = _0x58d42c['value']) == null ? void 0x0 : _0x211c7e['commentCount']) || 0x0), 0x1)
                                    ])
                                ]),
                                _0xcc2930('div', At, [_0x5cdc42(_0x43a974, {
                                        'to': '/creation/commentmanage',
                                        'class': 'manage-link'
                                    }, {
                                        'default': _0x2db650(() => [
                                            _0x51f951[0xa] || (_0x51f951[0xa] = _0xcc2930('span', null, '管理评论', -0x1)),
                                            _0x5cdc42(_0x2fd0a0, null, {
                                                'default': _0x2db650(() => [_0x5cdc42(_0x3a6acf(_0x36c2a7))]),
                                                '_': 0x1
                                            })
                                        ]),
                                        '_': 0x1,
                                        '__': [0xa]
                                    })])
                            ]),
                            _0xcc2930('div', Dt, [
                                _0xcc2930('div', Ft, [
                                    _0xcc2930('div', Jt, [_0x5cdc42(_0x2fd0a0, null, {
                                            'default': _0x2db650(() => [_0x5cdc42(_0x3a6acf(_0x2d03c5))]),
                                            '_': 0x1
                                        })]),
                                    _0xcc2930('div', Kt, [
                                        _0x51f951[0xb] || (_0x51f951[0xb] = _0xcc2930('h3', null, '总阅读量', -0x1)),
                                        _0xcc2930('p', Pt, _0x449d37(_0x2ad326(((_0x21a130 = _0x58d42c['value']) == null ? void 0x0 : _0x21a130['totalReadCount']) || 0x0)), 0x1)
                                    ])
                                ]),
                                _0x51f951[0xc] || (_0x51f951[0xc] = _0xcc2930('div', { 'class': 'stat-trend' }, [_0xcc2930('span', { 'class': 'trend-text' }, '持续增长中')], -0x1))
                            ]),
                            _0xcc2930('div', Qt, [
                                _0xcc2930('div', Ut, [
                                    _0xcc2930('div', $t, [_0x5cdc42(_0x2a7220, {
                                            'name': 'like',
                                            'width': '18px',
                                            'height': '18px',
                                            'color': '#fff'
                                        })]),
                                    _0xcc2930('div', jt, [
                                        _0x51f951[0xd] || (_0x51f951[0xd] = _0xcc2930('h3', null, '获赞数', -0x1)),
                                        _0xcc2930('p', zt, _0x449d37(((_0x55d624 = _0x58d42c['value']) == null ? void 0x0 : _0x55d624['totalLikeCount']) || 0x0), 0x1)
                                    ])
                                ]),
                                _0x51f951[0xe] || (_0x51f951[0xe] = _0xcc2930('div', { 'class': 'stat-trend' }, [_0xcc2930('span', { 'class': 'trend-text' }, '感谢支持')], -0x1))
                            ]),
                            _0xcc2930('div', Gt, [
                                _0xcc2930('div', Ht, [
                                    _0xcc2930('div', Ot, [_0x5cdc42(_0x2fd0a0, { 'color': '#fff' }, {
                                            'default': _0x2db650(() => [_0x5cdc42(_0x3a6acf(_0xd975eb))]),
                                            '_': 0x1
                                        })]),
                                    _0xcc2930('div', Wt, [
                                        _0x51f951[0xf] || (_0x51f951[0xf] = _0xcc2930('h3', null, '粉丝数', -0x1)),
                                        _0xcc2930('p', Xt, _0x449d37(((_0x20f0a2 = _0x58d42c['value']) == null ? void 0x0 : _0x20f0a2['fansCount']) || 0x0), 0x1)
                                    ])
                                ]),
                                _0x51f951[0x10] || (_0x51f951[0x10] = _0xcc2930('div', { 'class': 'stat-trend' }, [_0xcc2930('span', { 'class': 'trend-text' }, '影响力提升')], -0x1))
                            ])
                        ]))
                    ]),
                    _0xcc2930('div', ss, [
                        _0x51f951[0x16] || (_0x51f951[0x16] = _0xcc2930('div', { 'class': 'section-title' }, [
                            _0xcc2930('h2', null, '快捷工具'),
                            _0xcc2930('p', null, '高效管理您的内容')
                        ], -0x1)),
                        _0xcc2930('div', as, [
                            _0xcc2930('div', {
                                'class': 'tool-card',
                                'onClick': _0x548b88
                            }, [
                                _0xcc2930('div', os, [_0x5cdc42(_0x2fd0a0, null, {
                                        'default': _0x2db650(() => [_0x5cdc42(_0x3a6acf(_0x238bab))]),
                                        '_': 0x1
                                    })]),
                                _0x51f951[0x12] || (_0x51f951[0x12] = _0xcc2930('div', { 'class': 'tool-info' }, [
                                    _0xcc2930('h3', null, '写文章'),
                                    _0xcc2930('p', null, '记录您的想法和见解')
                                ], -0x1))
                            ]),
                            _0xcc2930('div', {
                                'class': 'tool-card',
                                'onClick': _0x183846
                            }, [
                                _0xcc2930('div', ls, [_0x5cdc42(_0x2fd0a0, null, {
                                        'default': _0x2db650(() => [_0x5cdc42(_0x3a6acf(_0x6869c))]),
                                        '_': 0x1
                                    })]),
                                _0x51f951[0x13] || (_0x51f951[0x13] = _0xcc2930('div', { 'class': 'tool-info' }, [
                                    _0xcc2930('h3', null, '文章管理'),
                                    _0xcc2930('p', null, '管理已发布的文章')
                                ], -0x1))
                            ]),
                            _0xcc2930('div', {
                                'class': 'tool-card',
                                'onClick': _0x1a9456
                            }, [
                                _0xcc2930('div', is, [_0x5cdc42(_0x2fd0a0, null, {
                                        'default': _0x2db650(() => [_0x5cdc42(_0x3a6acf(_0x3916f9))]),
                                        '_': 0x1
                                    })]),
                                _0x51f951[0x14] || (_0x51f951[0x14] = _0xcc2930('div', { 'class': 'tool-info' }, [
                                    _0xcc2930('h3', null, '专栏管理'),
                                    _0xcc2930('p', null, '组织和管理专栏内容')
                                ], -0x1))
                            ]),
                            _0xcc2930('div', {
                                'class': 'tool-card',
                                'onClick': _0x181cad
                            }, [
                                _0xcc2930('div', ns, [_0x5cdc42(_0x2fd0a0, null, {
                                        'default': _0x2db650(() => [_0x5cdc42(_0x3a6acf(_0x182fb3))]),
                                        '_': 0x1
                                    })]),
                                _0x51f951[0x15] || (_0x51f951[0x15] = _0xcc2930('div', { 'class': 'tool-info' }, [
                                    _0xcc2930('h3', null, '评论管理'),
                                    _0xcc2930('p', null, '回复和管理评论互动')
                                ], -0x1))
                            ])
                        ])
                    ]),
                    _0x51f951[0x17] || (_0x51f951[0x17] = _0x879928('<div\x20class=\x22creation-assistant\x22\x20data-v-c4e9d4c6><div\x20class=\x22section-title\x22\x20data-v-c4e9d4c6><h2\x20data-v-c4e9d4c6>创作助手</h2><p\x20data-v-c4e9d4c6>提升您的创作效率</p></div><div\x20class=\x22assistant-cards\x22\x20data-v-c4e9d4c6><div\x20class=\x22assistant-card\x20tips\x22\x20data-v-c4e9d4c6><div\x20class=\x22card-header\x22\x20data-v-c4e9d4c6><h3\x20data-v-c4e9d4c6>写作建议</h3></div><div\x20class=\x22card-content\x22\x20data-v-c4e9d4c6><ul\x20class=\x22tips-list\x22\x20data-v-c4e9d4c6><li\x20data-v-c4e9d4c6>保持文章结构清晰，使用标题和段落分隔</li><li\x20data-v-c4e9d4c6>添加合适的配图能让文章更生动</li><li\x20data-v-c4e9d4c6>定期更新内容，保持读者的关注度</li><li\x20data-v-c4e9d4c6>回应读者评论，建立良好的互动关系</li></ul></div></div><div\x20class=\x22assistant-card\x20trends\x22\x20data-v-c4e9d4c6><div\x20class=\x22card-header\x22\x20data-v-c4e9d4c6><h3\x20data-v-c4e9d4c6>热门话题</h3></div><div\x20class=\x22card-content\x22\x20data-v-c4e9d4c6><div\x20class=\x22topic-tags\x22\x20data-v-c4e9d4c6><span\x20class=\x22topic-tag\x22\x20data-v-c4e9d4c6>前端开发</span><span\x20class=\x22topic-tag\x22\x20data-v-c4e9d4c6>人工智能</span><span\x20class=\x22topic-tag\x22\x20data-v-c4e9d4c6>生活随笔</span><span\x20class=\x22topic-tag\x22\x20data-v-c4e9d4c6>技术分享</span><span\x20class=\x22topic-tag\x22\x20data-v-c4e9d4c6>读书笔记</span><span\x20class=\x22topic-tag\x22\x20data-v-c4e9d4c6>职场感悟</span></div></div></div></div></div>', 0x1))
                ]);
            };
        }
    }, ps = _0x35a082(es, [[
            '__scopeId',
            'data-v-c4e9d4c6'
        ]]);
export {
    ps as default
};