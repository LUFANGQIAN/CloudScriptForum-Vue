const _0x2eb7fd = (function () {
        let _0x4178ee = !![];
        return function (_0x21154f, _0x1456ae) {
            const _0x23310b = _0x4178ee ? function () {
                if (_0x1456ae) {
                    const _0x24e82 = _0x1456ae['apply'](_0x21154f, arguments);
                    return _0x1456ae = null, _0x24e82;
                }
            } : function () {
            };
            return _0x4178ee = ![], _0x23310b;
        };
    }()), _0x43b0fc = _0x2eb7fd(this, function () {
        let _0x1413ae;
        try {
            const _0x5e8080 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x1413ae = _0x5e8080();
        } catch (_0x50f756) {
            _0x1413ae = window;
        }
        const _0x78cca = _0x1413ae['console'] = _0x1413ae['console'] || {}, _0x25e909 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x2deb18 = 0x0; _0x2deb18 < _0x25e909['length']; _0x2deb18++) {
            const _0x4c8098 = _0x2eb7fd['constructor']['prototype']['bind'](_0x2eb7fd), _0x56e274 = _0x25e909[_0x2deb18], _0x45caab = _0x78cca[_0x56e274] || _0x4c8098;
            _0x4c8098['__proto__'] = _0x2eb7fd['bind'](_0x2eb7fd), _0x4c8098['toString'] = _0x45caab['toString']['bind'](_0x45caab), _0x78cca[_0x56e274] = _0x4c8098;
        }
    });
_0x43b0fc();
import {
    W as _0x19e6a0,
    X as _0x34bf22,
    d as _0x105a49,
    aK as _0x3a1479,
    a2 as _0x2ecc9f,
    r as _0x7cc514,
    o as _0x5d0453,
    aS as _0x5e7878,
    a as _0x342361,
    aL as _0x4ec8b8,
    Y as _0x5a971c,
    w as _0x230f2a,
    bi as _0x50d1da
} from './index-54DmW9hq.js';
import { P as _0x21a41e } from './vnode-C3QoD07S.js';
import {
    c as _0x37cf26,
    e as _0x1c4a7d,
    d as _0x26c661,
    k as _0x1a1e4f,
    n as _0x2014fe,
    Q as _0x299bcf,
    P as _0x4b9bed,
    O as _0x40074f,
    N as _0x164570
} from './Request-CHKnUlo5.js';
import { t as _0x4baa0d } from './index-DMxv2JmO.js';
import { a as _0x40c1c6 } from './scroll-DDB7nuLj.js';
const _ = _0x4a2dfb => {
        if (!_0x4a2dfb)
            return {
                'onClick': _0x19e6a0,
                'onMousedown': _0x19e6a0,
                'onMouseup': _0x19e6a0
            };
        let _0x40f970 = !0x1, _0x2fdf91 = !0x1;
        return {
            'onClick': _0x1a0a50 => {
                _0x40f970 && _0x2fdf91 && _0x4a2dfb(_0x1a0a50), _0x40f970 = _0x2fdf91 = !0x1;
            },
            'onMousedown': _0x47ea6c => {
                _0x40f970 = _0x47ea6c['target'] === _0x47ea6c['currentTarget'];
            },
            'onMouseup': _0x166630 => {
                _0x2fdf91 = _0x166630['target'] === _0x166630['currentTarget'];
            }
        };
    }, R = _0x37cf26({
        'mask': {
            'type': Boolean,
            'default': !0x0
        },
        'customMaskEvent': Boolean,
        'overlayClass': {
            'type': _0x26c661([
                String,
                Array,
                Object
            ])
        },
        'zIndex': {
            'type': _0x26c661([
                String,
                Number
            ])
        }
    }), ee = { 'click': _0x998a32 => _0x998a32 instanceof MouseEvent }, te = 'overlay';
var oe = _0x34bf22({
    'name': 'ElOverlay',
    'props': R,
    'emits': ee,
    'setup'(_0x7fbead, {
        slots: _0xe5a588,
        emit: _0x14c681
    }) {
        const _0x32e6b8 = _0x1c4a7d(te), _0x546c44 = _0x841b56 => {
                _0x14c681('click', _0x841b56);
            }, {
                onClick: _0xf9b719,
                onMousedown: _0x56bc52,
                onMouseup: _0x1e8fea
            } = _(_0x7fbead['customMaskEvent'] ? void 0x0 : _0x546c44);
        return () => _0x7fbead['mask'] ? _0x105a49('div', {
            'class': [
                _0x32e6b8['b'](),
                _0x7fbead['overlayClass']
            ],
            'style': { 'zIndex': _0x7fbead['zIndex'] },
            'onClick': _0xf9b719,
            'onMousedown': _0x56bc52,
            'onMouseup': _0x1e8fea
        }, [_0x2ecc9f(_0xe5a588, 'default')], _0x21a41e['STYLE'] | _0x21a41e['CLASS'] | _0x21a41e['PROPS'], [
            'onClick',
            'onMouseup',
            'onMousedown'
        ]) : _0x3a1479('div', {
            'class': _0x7fbead['overlayClass'],
            'style': {
                'zIndex': _0x7fbead['zIndex'],
                'position': 'fixed',
                'top': '0px',
                'right': '0px',
                'bottom': '0px',
                'left': '0px'
            }
        }, [_0x2ecc9f(_0xe5a588, 'default')]);
    }
});
const le = oe, ie = (_0x40bee0, _0x2c59ac, _0x2495f6, _0x4ab4c3) => {
        const _0xc95f1 = {
                'offsetX': 0x0,
                'offsetY': 0x0
            }, _0x10b4ff = _0x7cc514(!0x1), _0x5ecd8f = (_0x380b0c, _0x2cc6d6) => {
                if (_0x40bee0['value']) {
                    const {
                            offsetX: _0x12d5e9,
                            offsetY: _0x336a5e
                        } = _0xc95f1, _0x54968c = _0x40bee0['value']['getBoundingClientRect'](), _0x167858 = _0x54968c['left'], _0x2a4284 = _0x54968c['top'], _0x4987ef = _0x54968c['width'], _0x1c5091 = _0x54968c['height'], _0x3c02ed = document['documentElement']['clientWidth'], _0x107c63 = document['documentElement']['clientHeight'], _0x3ba486 = -_0x167858 + _0x12d5e9, _0x2f7b4d = -_0x2a4284 + _0x336a5e, _0x45c236 = _0x3c02ed - _0x167858 - _0x4987ef + _0x12d5e9, _0x233582 = _0x107c63 - _0x2a4284 - (_0x1c5091 < _0x107c63 ? _0x1c5091 : 0x0) + _0x336a5e;
                    _0x4ab4c3 != null && _0x4ab4c3['value'] || (_0x380b0c = Math['min'](Math['max'](_0x380b0c, _0x3ba486), _0x45c236), _0x2cc6d6 = Math['min'](Math['max'](_0x2cc6d6, _0x2f7b4d), _0x233582)), _0xc95f1['offsetX'] = _0x380b0c, _0xc95f1['offsetY'] = _0x2cc6d6, _0x40bee0['value']['style']['transform'] = 'translate(' + _0x1a1e4f(_0x380b0c) + ',\x20' + _0x1a1e4f(_0x2cc6d6) + ')';
                }
            }, _0xaeffd2 = _0x3dc81e => {
                const _0x34e064 = _0x3dc81e['clientX'], _0x1a4d72 = _0x3dc81e['clientY'], {
                        offsetX: _0x25409a,
                        offsetY: _0xbecbee
                    } = _0xc95f1, _0x192f2d = _0x3cf12b => {
                        _0x10b4ff['value'] || (_0x10b4ff['value'] = !0x0);
                        const _0x3d9602 = _0x25409a + _0x3cf12b['clientX'] - _0x34e064, _0x575b92 = _0xbecbee + _0x3cf12b['clientY'] - _0x1a4d72;
                        _0x5ecd8f(_0x3d9602, _0x575b92);
                    }, _0x149f14 = () => {
                        _0x10b4ff['value'] = !0x1, document['removeEventListener']('mousemove', _0x192f2d), document['removeEventListener']('mouseup', _0x149f14);
                    };
                document['addEventListener']('mousemove', _0x192f2d), document['addEventListener']('mouseup', _0x149f14);
            }, _0x5704e9 = () => {
                _0x2c59ac['value'] && _0x40bee0['value'] && (_0x2c59ac['value']['addEventListener']('mousedown', _0xaeffd2), window['addEventListener']('resize', _0x27968f));
            }, _0x26ef53 = () => {
                _0x2c59ac['value'] && _0x40bee0['value'] && (_0x2c59ac['value']['removeEventListener']('mousedown', _0xaeffd2), window['removeEventListener']('resize', _0x27968f));
            }, _0x3c1e20 = () => {
                _0xc95f1['offsetX'] = 0x0, _0xc95f1['offsetY'] = 0x0, _0x40bee0['value'] && (_0x40bee0['value']['style']['transform'] = '');
            }, _0x27968f = () => {
                const {
                    offsetX: _0x484216,
                    offsetY: _0x3edabe
                } = _0xc95f1;
                _0x5ecd8f(_0x484216, _0x3edabe);
            };
        return _0x5d0453(() => {
            _0x5e7878(() => {
                _0x2495f6['value'] ? _0x5704e9() : _0x26ef53();
            });
        }), _0x342361(() => {
            _0x26ef53();
        }), {
            'isDragging': _0x10b4ff,
            'resetPosition': _0x3c1e20,
            'updatePosition': _0x27968f
        };
    }, re = (_0x23d716, _0x597520 = {}) => {
        _0x4ec8b8(_0x23d716) || _0x4baa0d('[useLockscreen]', 'You\x20need\x20to\x20pass\x20a\x20ref\x20param\x20to\x20this\x20function');
        const _0x3f5595 = _0x597520['ns'] || _0x1c4a7d('popup'), _0x342749 = _0x5a971c(() => _0x3f5595['bm']('parent', 'hidden'));
        if (!_0x2014fe || _0x299bcf(document['body'], _0x342749['value']))
            return;
        let _0x423677 = 0x0, _0x1d4304 = !0x1, _0x4dee8d = '0';
        const _0x49b163 = () => {
            setTimeout(() => {
                typeof document > 'u' || _0x1d4304 && document && (document['body']['style']['width'] = _0x4dee8d, _0x164570(document['body'], _0x342749['value']));
            }, 0xc8);
        };
        _0x230f2a(_0x23d716, _0x3a93ae => {
            if (!_0x3a93ae) {
                _0x49b163();
                return;
            }
            _0x1d4304 = !_0x299bcf(document['body'], _0x342749['value']), _0x1d4304 && (_0x4dee8d = document['body']['style']['width'], _0x4b9bed(document['body'], _0x342749['value'])), _0x423677 = _0x40c1c6(_0x3f5595['namespace']['value']);
            const _0x483fd9 = document['documentElement']['clientHeight'] < document['body']['scrollHeight'], _0x233c84 = _0x40074f(document['body'], 'overflowY');
            _0x423677 > 0x0 && (_0x483fd9 || _0x233c84 === 'scroll') && _0x1d4304 && (document['body']['style']['width'] = 'calc(100%\x20-\x20' + _0x423677 + 'px)');
        }), _0x50d1da(() => _0x49b163());
    };
export {
    le as E,
    re as a,
    _ as b,
    ie as u
};