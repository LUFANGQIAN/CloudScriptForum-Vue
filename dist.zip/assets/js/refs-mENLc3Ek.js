const _0x3f53e2 = (function () {
        let _0x4b11a7 = !![];
        return function (_0x59620c, _0x321de9) {
            const _0x2e1815 = _0x4b11a7 ? function () {
                if (_0x321de9) {
                    const _0x2c047e = _0x321de9['apply'](_0x59620c, arguments);
                    return _0x321de9 = null, _0x2c047e;
                }
            } : function () {
            };
            return _0x4b11a7 = ![], _0x2e1815;
        };
    }()), _0x146dc7 = _0x3f53e2(this, function () {
        let _0x423fba;
        try {
            const _0x39e8bc = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x423fba = _0x39e8bc();
        } catch (_0xd3ebbf) {
            _0x423fba = window;
        }
        const _0x10ad5c = _0x423fba['console'] = _0x423fba['console'] || {}, _0x4c4a43 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x52195e = 0x0; _0x52195e < _0x4c4a43['length']; _0x52195e++) {
            const _0x3d5428 = _0x3f53e2['constructor']['prototype']['bind'](_0x3f53e2), _0x29e07b = _0x4c4a43[_0x52195e], _0x1500a6 = _0x10ad5c[_0x29e07b] || _0x3d5428;
            _0x3d5428['__proto__'] = _0x3f53e2['bind'](_0x3f53e2), _0x3d5428['toString'] = _0x1500a6['toString']['bind'](_0x1500a6), _0x10ad5c[_0x29e07b] = _0x3d5428;
        }
    });
_0x146dc7();
import { aV as _0x4f80f5 } from './index-54DmW9hq.js';
const e = (..._0x53d146) => _0x7c077 => {
    _0x53d146['forEach'](_0x666781 => {
        _0x4f80f5(_0x666781) ? _0x666781(_0x7c077) : _0x666781['value'] = _0x7c077;
    });
};
export {
    e as c
};