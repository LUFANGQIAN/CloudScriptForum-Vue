const _0x2b583b = (function () {
        let _0x537e57 = !![];
        return function (_0xe5d8df, _0x5ca7ba) {
            const _0x3f0230 = _0x537e57 ? function () {
                if (_0x5ca7ba) {
                    const _0x3f33ef = _0x5ca7ba['apply'](_0xe5d8df, arguments);
                    return _0x5ca7ba = null, _0x3f33ef;
                }
            } : function () {
            };
            return _0x537e57 = ![], _0x3f0230;
        };
    }()), _0x56253c = _0x2b583b(this, function () {
        let _0x4e973e;
        try {
            const _0x1f82b1 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x4e973e = _0x1f82b1();
        } catch (_0x256e54) {
            _0x4e973e = window;
        }
        const _0x29166f = _0x4e973e['console'] = _0x4e973e['console'] || {}, _0x56f8c0 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x491380 = 0x0; _0x491380 < _0x56f8c0['length']; _0x491380++) {
            const _0x1c1d13 = _0x2b583b['constructor']['prototype']['bind'](_0x2b583b), _0x542d21 = _0x56f8c0[_0x491380], _0x4eef1 = _0x29166f[_0x542d21] || _0x1c1d13;
            _0x1c1d13['__proto__'] = _0x2b583b['bind'](_0x2b583b), _0x1c1d13['toString'] = _0x4eef1['toString']['bind'](_0x4eef1), _0x29166f[_0x542d21] = _0x1c1d13;
        }
    });
_0x56253c();
import { E as _0x229bae } from './Request-CHKnUlo5.js';
import { v as _0x4cfde1 } from './el-loading-BYktkv7A.js';
import { E as _0x1d4cef } from './el-empty-o9RgIX3C.js';
import { E as _0x3adc3c } from './el-button-D6wSrR74.js';
import { E as _0x1cb509 } from './el-avatar-D7H8d9zq.js';
import {
    _ as _0x185e52,
    r as _0x4230cb,
    o as _0x1aaf45,
    Q as _0x4489d5,
    c as _0x5cec4e,
    g as _0x117a2e,
    A as _0x114133,
    k as _0x335151,
    m as _0x5647f9,
    t as _0xbd635a,
    e as _0xb3a588,
    F as _0x569c44,
    G,
    u as _0x24999e,
    b as _0x1e67f3,
    d as _0x353c7b,
    C as _0x4a0898,
    ag as _0x3afb5e
} from './index-54DmW9hq.js';
import {
    g as _0x32787e,
    d as _0x2ac116
} from './conversation-BnzxcDLp.js';
import {
    u as _0x199449,
    W as _0x4ddc2d
} from './WebSocketClient-CQU1CbB3.js';
import { c as _0x358bae } from './formatTime-B8qE7LcY.js';
import './el-input-D-8X7_j3.js';
import './el-overlay-D3x7h4La.js';
import { E as _0x10b08c } from './index-DbtH6USO.js';
import './aria-DyaK1nXM.js';
import './index-DMxv2JmO.js';
import './event-BB_Ol6Sd.js';
import './index-ijNW1fhk.js';
import './vnode-C3QoD07S.js';
import './scroll-DDB7nuLj.js';
import './focus-trap-Cbj9GFlW.js';
const q = { 'class': 'conversation-page' }, J = { 'class': 'container' }, K = { 'class': 'conversation-container' }, P = { 'class': 'page-header' }, X = {
        'key': 0x0,
        'class': 'unread-badge'
    }, Y = { 'class': 'conversation-list' }, Z = ['onClick'], ee = ['onClick'], te = {
        'key': 0x0,
        'class': 'online-status'
    }, se = { 'class': 'conversation-info' }, oe = { 'class': 'conversation-header' }, ae = { 'class': 'nickname' }, ne = { 'class': 'time' }, re = { 'class': 'conversation-content' }, ie = { 'class': 'last-message' }, ce = {
        '__name': 'ConversationList',
        'setup'(_0x5e7e0e) {
            const _0x31bcd6 = _0x24999e(), _0x4be20f = _0x199449(), _0x109447 = _0x4230cb(!0x1), _0x4bbbef = async () => {
                    try {
                        _0x109447['value'] = !0x0;
                        const _0x100d1c = await _0x32787e();
                        _0x4be20f['setConversationList'](_0x100d1c['data']['data']);
                    } catch (_0x460133) {
                        console['error']('获取会话列表失败:', _0x460133);
                    } finally {
                        _0x109447['value'] = !0x1;
                    }
                }, _0x589432 = _0x80e1c2 => {
                    _0x31bcd6['push']('/message/chat/' + _0x80e1c2);
                }, _0x252f99 = _0x155a86 => {
                    _0x31bcd6['push']('/user/' + _0x155a86);
                }, _0x24d9a4 = async _0x30d0aa => {
                    try {
                        await _0x10b08c['confirm']('确定要删除该会话吗？', '提示', {
                            'confirmButtonText': '确定',
                            'cancelButtonText': '取消',
                            'type': 'warning'
                        }), await _0x2ac116(_0x30d0aa), _0x4be20f['removeConversation'](_0x30d0aa);
                    } catch (_0x251ea3) {
                        _0x251ea3 !== 'cancel' && console['error']('删除会话失败:', _0x251ea3);
                    }
                }, _0x49ddb4 = _0x5871d0 => {
                    _0x4be20f['conversationList']['some'](_0x273da4 => _0x273da4['targetUserId'] === _0x5871d0['fromUserId']) || _0x4bbbef();
                }, _0x1a52ac = _0xd523b3 => {
                    _0x4be20f['updateUserOnlineStatus'](_0xd523b3['userId'], _0xd523b3['isOnline']);
                };
            return _0x1aaf45(() => {
                _0x4be20f['conversationList']['length'] === 0x0 && _0x4bbbef(), _0x4ddc2d['on']('NEW_MESSAGE', _0x49ddb4), _0x4ddc2d['on']('USER_ONLINE_STATUS', _0x1a52ac);
            }), _0x4489d5(() => {
                _0x4ddc2d['off']('NEW_MESSAGE', _0x49ddb4), _0x4ddc2d['off']('USER_ONLINE_STATUS', _0x1a52ac);
            }), (_0x586802, _0x327426) => {
                const _0x2c871b = _0x1cb509, _0x49a15f = _0x229bae, _0x21e397 = _0x3adc3c, _0x4e2ea2 = _0x1d4cef, _0x5ed818 = _0x4cfde1;
                return _0x1e67f3(), _0x5cec4e('div', q, [_0x117a2e('div', J, [_0x117a2e('div', K, [
                            _0x117a2e('div', P, [
                                _0x327426[0x0] || (_0x327426[0x0] = _0x117a2e('h2', { 'class': 'page-title' }, '私信', -0x1)),
                                _0x5647f9(_0x4be20f)['totalUnreadCount'] > 0x0 ? (_0x1e67f3(), _0x5cec4e('span', X, _0xbd635a(_0x5647f9(_0x4be20f)['totalUnreadCount']), 0x1)) : _0x335151('', !0x0)
                            ]),
                            _0x114133((_0x1e67f3(), _0x5cec4e('div', Y, [
                                (_0x1e67f3(!0x0), _0x5cec4e(_0x569c44, null, G(_0x5647f9(_0x4be20f)['conversationList'], _0x3b9b96 => (_0x1e67f3(), _0x5cec4e('div', {
                                    'key': _0x3b9b96['id'],
                                    'class': 'conversation-item',
                                    'onClick': _0x558a87 => _0x589432(_0x3b9b96['targetUserId'])
                                }, [
                                    _0x117a2e('div', {
                                        'class': 'avatar-wrapper',
                                        'onClick': _0x4a0898(_0x472556 => _0x252f99(_0x3b9b96['targetUserId']), ['stop'])
                                    }, [
                                        _0x353c7b(_0x2c871b, {
                                            'size': 0x32,
                                            'src': _0x3b9b96['targetUserAvatar']
                                        }, null, 0x8, ['src']),
                                        _0x3b9b96['isOnline'] ? (_0x1e67f3(), _0x5cec4e('span', te)) : _0x335151('', !0x0)
                                    ], 0x8, ee),
                                    _0x117a2e('div', se, [
                                        _0x117a2e('div', oe, [
                                            _0x117a2e('span', ae, _0xbd635a(_0x3b9b96['targetUserNickname']), 0x1),
                                            _0x117a2e('span', ne, _0xbd635a(_0x5647f9(_0x358bae)(_0x3b9b96['lastMessageTime'])), 0x1)
                                        ]),
                                        _0x117a2e('div', re, [
                                            _0x117a2e('span', ie, _0xbd635a(_0x3b9b96['lastMessageContent']), 0x1),
                                            _0x3b9b96['unreadCount'] > 0x0 ? (_0x1e67f3(), _0xb3a588(_0x49a15f, {
                                                'key': 0x0,
                                                'value': _0x3b9b96['unreadCount'],
                                                'max': 0x63,
                                                'class': 'unread-badge'
                                            }, null, 0x8, ['value'])) : _0x335151('', !0x0)
                                        ])
                                    ]),
                                    _0x353c7b(_0x21e397, {
                                        'type': 'danger',
                                        'icon': _0x5647f9(_0x3afb5e),
                                        'circle': '',
                                        'size': 'small',
                                        'class': 'delete-btn',
                                        'onClick': _0x4a0898(_0x3a9450 => _0x24d9a4(_0x3b9b96['targetUserId']), ['stop'])
                                    }, null, 0x8, [
                                        'icon',
                                        'onClick'
                                    ])
                                ], 0x8, Z))), 0x80)),
                                _0x5647f9(_0x4be20f)['conversationList']['length'] === 0x0 && !_0x109447['value'] ? (_0x1e67f3(), _0xb3a588(_0x4e2ea2, {
                                    'key': 0x0,
                                    'description': '暂无会话'
                                })) : _0x335151('', !0x0)
                            ])), [[
                                    _0x5ed818,
                                    _0x109447['value']
                                ]])
                        ])])]);
            };
        }
    }, Ie = _0x185e52(ce, [[
            '__scopeId',
            'data-v-306310a5'
        ]]);
export {
    Ie as default
};