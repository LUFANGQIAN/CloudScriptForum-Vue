const _0x22738b = (function () {
        let _0x56b0da = !![];
        return function (_0x52048e, _0x22e63e) {
            const _0x17651f = _0x56b0da ? function () {
                if (_0x22e63e) {
                    const _0x1f9d7e = _0x22e63e['apply'](_0x52048e, arguments);
                    return _0x22e63e = null, _0x1f9d7e;
                }
            } : function () {
            };
            return _0x56b0da = ![], _0x17651f;
        };
    }()), _0x3f055e = _0x22738b(this, function () {
        let _0x17e37f;
        try {
            const _0x28164d = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x17e37f = _0x28164d();
        } catch (_0x57a9f7) {
            _0x17e37f = window;
        }
        const _0x465443 = _0x17e37f['console'] = _0x17e37f['console'] || {}, _0x2ad3ab = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x2def42 = 0x0; _0x2def42 < _0x2ad3ab['length']; _0x2def42++) {
            const _0x1992a3 = _0x22738b['constructor']['prototype']['bind'](_0x22738b), _0x121ff3 = _0x2ad3ab[_0x2def42], _0x4a6512 = _0x465443[_0x121ff3] || _0x1992a3;
            _0x1992a3['__proto__'] = _0x22738b['bind'](_0x22738b), _0x1992a3['toString'] = _0x4a6512['toString']['bind'](_0x4a6512), _0x465443[_0x121ff3] = _0x1992a3;
        }
    });
_0x3f055e();
import {
    f as _0x21f003,
    g as _0x4f63ca,
    _ as _0x1d2092,
    e as _0x4ac949,
    a as _0x145566,
    w as _0x2733e6,
    r as _0x1dd69e,
    b as _0x43247f,
    u as _0xe416ad
} from './Request-CHKnUlo5.js';
import { E as _0x279635 } from './el-image-viewer-DAjDHmiI.js';
import {
    E as _0x1f31a7,
    a as _0x40d988
} from './el-skeleton-item-BG_lS1DD.js';
import { E as _0x5dea3a } from './el-button-D6wSrR74.js';
import {
    a8 as _0x49a317,
    r as _0x991dd1,
    o as _0x2bbc21,
    X as _0x3b41fb,
    Y as _0x3eb7e5,
    e as _0x2fc9fc,
    b as _0x3ad99a,
    f as _0x13a101,
    c as _0x484c9b,
    k as _0x140f89,
    m as _0x41d4a8,
    C as _0x2adba6,
    z as _0x458d3c,
    $ as _0x49a46a,
    a2 as _0x57c512,
    d as _0x1cb2c4,
    a9 as _0x373362,
    T as _0x2e2219,
    _ as _0x3e47ae,
    aa as _0x72fda1,
    w as _0x1f4445,
    Q as _0x2b52c1,
    g as _0x5c00c1,
    ab as _0x3350bf,
    H as _0x3c83d1,
    O as _0x1c0f07,
    P as _0x25d5bf,
    ac as _0x2ad222,
    j as _0xca830e,
    L as _0x3b3f03,
    ad as _0x3fb081,
    t as _0x19f777,
    F as _0x38e901,
    G as _0x3089ad,
    u as _0x2b09f2,
    ae as _0x579175,
    af as _0x191885,
    M as _0x337594,
    v as _0x1739db,
    ag as _0x275ed6
} from './index-54DmW9hq.js';
import { E as _0x58a1d0 } from './el-dialog-BYTqBsxC.js';
import './el-overlay-D3x7h4La.js';
import {
    E as _0x40c391,
    a as _0x212b57
} from './el-form-item-CE_gZaOe.js';
import { E as _0x30894d } from './el-input-D-8X7_j3.js';
import { t as _0x80565d } from './index-DMxv2JmO.js';
import { E as _0x51d09e } from './index-DbtH6USO.js';
import './focus-trap-Cbj9GFlW.js';
import './aria-DyaK1nXM.js';
import './index-BLYrTdqd.js';
import './toNumber-DGNxa_rg.js';
import './index-ijNW1fhk.js';
import './scroll-DDB7nuLj.js';
import './refs-mENLc3Ek.js';
import './event-BB_Ol6Sd.js';
import './vnode-C3QoD07S.js';
import './castArray-BGw1D6E-.js';
import './_baseClone-DoJvIJg4.js';
const De = {
        'visibilityHeight': {
            'type': Number,
            'default': 0xc8
        },
        'target': {
            'type': String,
            'default': ''
        },
        'right': {
            'type': Number,
            'default': 0x28
        },
        'bottom': {
            'type': Number,
            'default': 0x28
        }
    }, qe = { 'click': _0x175afb => _0x175afb instanceof MouseEvent }, Oe = (_0x9ed5, _0x4604e2, _0x194555) => {
        const _0x47b8fe = _0x49a317(), _0x50b611 = _0x49a317(), _0x1ee31e = _0x991dd1(!0x1), _0x5b63ba = () => {
                _0x47b8fe['value'] && (_0x1ee31e['value'] = _0x47b8fe['value']['scrollTop'] >= _0x9ed5['visibilityHeight']);
            }, _0x3e3d21 = _0x4b3be2 => {
                var _0xeb07c0;
                (_0xeb07c0 = _0x47b8fe['value']) == null || _0xeb07c0['scrollTo']({
                    'top': 0x0,
                    'behavior': 'smooth'
                }), _0x4604e2('click', _0x4b3be2);
            }, _0x39b2e8 = _0x4f63ca(_0x5b63ba, 0x12c, !0x0);
        return _0x21f003(_0x50b611, 'scroll', _0x39b2e8), _0x2bbc21(() => {
            var _0x57513c;
            _0x50b611['value'] = document, _0x47b8fe['value'] = document['documentElement'], _0x9ed5['target'] && (_0x47b8fe['value'] = (_0x57513c = document['querySelector'](_0x9ed5['target'])) != null ? _0x57513c : void 0x0, _0x47b8fe['value'] || _0x80565d(_0x194555, 'target\x20does\x20not\x20exist:\x20' + _0x9ed5['target']), _0x50b611['value'] = _0x47b8fe['value']), _0x5b63ba();
        }), {
            'visible': _0x1ee31e,
            'handleClick': _0x3e3d21
        };
    }, se = 'ElBacktop', Re = _0x3b41fb({ 'name': se }), Ae = _0x3b41fb({
        ...Re,
        'props': De,
        'emits': qe,
        'setup'(_0x10a0d3, {emit: _0x27c852}) {
            const _0x241606 = _0x10a0d3, _0x9ebff = _0x4ac949('backtop'), {
                    handleClick: _0x45db5b,
                    visible: _0xa063b1
                } = Oe(_0x241606, _0x27c852, se), _0x2ee133 = _0x3eb7e5(() => ({
                    'right': _0x241606['right'] + 'px',
                    'bottom': _0x241606['bottom'] + 'px'
                }));
            return (_0x533291, _0x535b3d) => (_0x3ad99a(), _0x2fc9fc(_0x2e2219, { 'name': _0x41d4a8(_0x9ebff)['namespace']['value'] + '-fade-in' }, {
                'default': _0x13a101(() => [_0x41d4a8(_0xa063b1) ? (_0x3ad99a(), _0x484c9b('div', {
                        'key': 0x0,
                        'style': _0x49a46a(_0x41d4a8(_0x2ee133)),
                        'class': _0x458d3c(_0x41d4a8(_0x9ebff)['b']()),
                        'onClick': _0x2adba6(_0x41d4a8(_0x45db5b), ['stop'])
                    }, [_0x57c512(_0x533291['$slots'], 'default', {}, () => [_0x1cb2c4(_0x41d4a8(_0x145566), { 'class': _0x458d3c(_0x41d4a8(_0x9ebff)['e']('icon')) }, {
                                'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x373362))]),
                                '_': 0x1
                            }, 0x8, ['class'])])], 0xe, ['onClick'])) : _0x140f89('v-if', !0x0)]),
                '_': 0x3
            }, 0x8, ['name']));
        }
    });
var He = _0x1d2092(Ae, [[
        '__file',
        'backtop.vue'
    ]]);
const Pe = _0x2733e6(He);
function je(_0x4b1264) {
    return _0x1dd69e({
        'url': '/link/apply',
        'method': 'post',
        'data': _0x4b1264
    });
}
function We(_0x429f9a) {
    return _0x1dd69e({
        'url': '/link/' + _0x429f9a,
        'method': 'delete'
    });
}
function Ge(_0xbf7ea1, _0x46bdf2) {
    return _0x1dd69e({
        'url': '/link/list?pageNum=' + _0xbf7ea1 + '&pageSize=' + _0x46bdf2,
        'method': 'get'
    });
}
const Qe = { 'class': 'dialog-header' }, Xe = {
        'key': 0x0,
        'class': 'cover-preview'
    }, Ye = { 'class': 'image-placeholder' }, Je = { 'class': 'image-error' }, Ke = { 'class': 'apply-notice' }, Ze = { 'class': 'notice-title' }, et = { 'class': 'dialog-footer' }, tt = {
        '__name': 'LinkApplyDialog',
        'props': {
            'modelValue': {
                'type': Boolean,
                'default': !0x1
            }
        },
        'emits': [
            'update:modelValue',
            'success'
        ],
        'setup'(_0x4ddde3, {emit: _0x5cdb87}) {
            const _0x194c07 = _0x4ddde3, _0x2f7cd3 = _0x5cdb87, _0x43f27c = _0x991dd1(!0x1), _0x2c4092 = _0x991dd1(!0x1), _0x319877 = _0x991dd1(null), _0x298266 = _0x991dd1(!0x1), _0x39bddb = _0x72fda1({
                    'name': '',
                    'url': '',
                    'coverUrl': '',
                    'description': '',
                    'email': ''
                }), _0x1c6d14 = _0x3eb7e5(() => _0x39bddb['coverUrl'] && _0x39bddb['coverUrl']['trim']() ? [_0x39bddb['coverUrl']] : []), _0x5c3b93 = _0x3eb7e5(() => _0x298266['value'] ? '95%' : '500px'), _0x53e983 = {
                    'name': [
                        {
                            'required': !0x0,
                            'message': '请输入网站名称',
                            'trigger': 'blur'
                        },
                        {
                            'min': 0x1,
                            'max': 0x14,
                            'message': '网站名称长度在1到20个字符',
                            'trigger': 'blur'
                        }
                    ],
                    'url': [
                        {
                            'required': !0x0,
                            'message': '请输入网站地址',
                            'trigger': 'blur'
                        },
                        {
                            'max': 0xc8,
                            'message': '网站地址不能超过200个字符',
                            'trigger': 'blur'
                        },
                        {
                            'pattern': /^https?:\/\/.+/,
                            'message': '请输入有效的网站地址\x20(以http://或https://开头)',
                            'trigger': 'blur'
                        }
                    ],
                    'description': [
                        {
                            'required': !0x0,
                            'message': '请输入网站描述',
                            'trigger': 'blur'
                        },
                        {
                            'min': 0x1,
                            'max': 0x32,
                            'message': '网站描述长度在1到50个字符',
                            'trigger': 'blur'
                        }
                    ],
                    'email': [
                        {
                            'required': !0x0,
                            'message': '请输入邮箱地址',
                            'trigger': 'blur'
                        },
                        {
                            'type': 'email',
                            'message': '请输入有效的邮箱地址',
                            'trigger': 'blur'
                        }
                    ]
                };
            _0x1f4445(() => _0x194c07['modelValue'], _0x49c361 => {
                _0x43f27c['value'] = _0x49c361;
            }, { 'immediate': !0x0 }), _0x1f4445(_0x43f27c, _0x1f604d => {
                _0x2f7cd3('update:modelValue', _0x1f604d), _0x1f604d || _0x54f8db();
            });
            const _0x54f8db = () => {
                    _0x319877['value'] && _0x319877['value']['resetFields'](), Object['keys'](_0x39bddb)['forEach'](_0x5f4b79 => {
                        _0x39bddb[_0x5f4b79] = '';
                    });
                }, _0x391c3b = () => {
                    _0x43f27c['value'] = !0x1;
                }, _0x2e43c7 = () => {
                    _0x298266['value'] = window['innerWidth'] <= 0x300;
                }, _0x4c4442 = async () => {
                    if (_0x319877['value'])
                        try {
                            await _0x319877['value']['validate'](), _0x2c4092['value'] = !0x0, await je(_0x39bddb), _0x43247f['success']('友链申请提交成功，我们会尽快审核！'), _0x2f7cd3('success'), _0x391c3b();
                        } catch (_0x33a746) {
                            _0x33a746['message'] ? _0x43247f['error']('申请提交失败：' + _0x33a746['message']) : console['error']('友链申请失败:', _0x33a746);
                        } finally {
                            _0x2c4092['value'] = !0x1;
                        }
                };
            return _0x2bbc21(() => {
                _0x2e43c7(), window['addEventListener']('resize', _0x2e43c7);
            }), _0x2b52c1(() => {
                window['removeEventListener']('resize', _0x2e43c7);
            }), (_0x2d404d, _0x4b5a90) => {
                const _0x40300c = _0x145566, _0x4bbc87 = _0x30894d, _0x522c52 = _0x40c391, _0x25a01a = _0x279635, _0x4273fe = _0x212b57, _0x222e24 = _0x5dea3a, _0x15aad2 = _0x58a1d0;
                return _0x3ad99a(), _0x2fc9fc(_0x15aad2, {
                    'modelValue': _0x43f27c['value'],
                    'onUpdate:modelValue': _0x4b5a90[0x5] || (_0x4b5a90[0x5] = _0x237bb9 => _0x43f27c['value'] = _0x237bb9),
                    'title': '申请友链',
                    'width': _0x5c3b93['value'],
                    'before-close': _0x391c3b,
                    'class': 'link-apply-dialog'
                }, {
                    'footer': _0x13a101(() => [_0x5c00c1('div', et, [
                            _0x1cb2c4(_0x222e24, {
                                'onClick': _0x391c3b,
                                'size': 'large'
                            }, {
                                'default': _0x13a101(() => _0x4b5a90[0xb] || (_0x4b5a90[0xb] = [_0xca830e('取消')])),
                                '_': 0x1,
                                '__': [0xb]
                            }),
                            _0x1cb2c4(_0x222e24, {
                                'type': 'primary',
                                'onClick': _0x4c4442,
                                'loading': _0x2c4092['value'],
                                'size': 'large'
                            }, {
                                'default': _0x13a101(() => [
                                    _0x2c4092['value'] ? _0x140f89('', !0x0) : (_0x3ad99a(), _0x2fc9fc(_0x40300c, { 'key': 0x0 }, {
                                        'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x3fb081))]),
                                        '_': 0x1
                                    })),
                                    _0xca830e('\x20' + _0x19f777(_0x2c4092['value'] ? '提交中...' : '提交申请'), 0x1)
                                ]),
                                '_': 0x1
                            }, 0x8, ['loading'])
                        ])]),
                    'default': _0x13a101(() => [
                        _0x5c00c1('div', Qe, [
                            _0x1cb2c4(_0x40300c, { 'class': 'header-icon' }, {
                                'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x3350bf))]),
                                '_': 0x1
                            }),
                            _0x4b5a90[0x6] || (_0x4b5a90[0x6] = _0x5c00c1('div', { 'class': 'header-content' }, [
                                _0x5c00c1('h3', { 'class': 'header-title' }, '友链申请'),
                                _0x5c00c1('p', { 'class': 'header-description' }, '请填写您的网站信息，我们会尽快审核您的申请')
                            ], -0x1))
                        ]),
                        _0x1cb2c4(_0x4273fe, {
                            'ref_key': 'linkFormRef',
                            'ref': _0x319877,
                            'model': _0x39bddb,
                            'rules': _0x53e983,
                            'label-width': '80px',
                            'class': 'link-apply-form'
                        }, {
                            'default': _0x13a101(() => [
                                _0x1cb2c4(_0x522c52, {
                                    'label': '网站名称',
                                    'prop': 'name'
                                }, {
                                    'default': _0x13a101(() => [_0x1cb2c4(_0x4bbc87, {
                                            'modelValue': _0x39bddb['name'],
                                            'onUpdate:modelValue': _0x4b5a90[0x0] || (_0x4b5a90[0x0] = _0x5ae37f => _0x39bddb['name'] = _0x5ae37f),
                                            'placeholder': '请输入网站名称',
                                            'maxlength': '20',
                                            'show-word-limit': '',
                                            'clearable': ''
                                        }, {
                                            'prefix': _0x13a101(() => [_0x1cb2c4(_0x40300c, null, {
                                                    'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x3c83d1))]),
                                                    '_': 0x1
                                                })]),
                                            '_': 0x1
                                        }, 0x8, ['modelValue'])]),
                                    '_': 0x1
                                }),
                                _0x1cb2c4(_0x522c52, {
                                    'label': '网站地址',
                                    'prop': 'url'
                                }, {
                                    'default': _0x13a101(() => [_0x1cb2c4(_0x4bbc87, {
                                            'modelValue': _0x39bddb['url'],
                                            'onUpdate:modelValue': _0x4b5a90[0x1] || (_0x4b5a90[0x1] = _0x4f0324 => _0x39bddb['url'] = _0x4f0324),
                                            'placeholder': '请输入完整的网站地址\x20(如:\x20https://example.com)',
                                            'maxlength': '100',
                                            'show-word-limit': '',
                                            'clearable': ''
                                        }, {
                                            'prefix': _0x13a101(() => [_0x1cb2c4(_0x40300c, null, {
                                                    'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x3350bf))]),
                                                    '_': 0x1
                                                })]),
                                            '_': 0x1
                                        }, 0x8, ['modelValue'])]),
                                    '_': 0x1
                                }),
                                _0x1cb2c4(_0x522c52, {
                                    'label': '网站封面',
                                    'prop': 'coverUrl'
                                }, {
                                    'default': _0x13a101(() => [
                                        _0x1cb2c4(_0x4bbc87, {
                                            'modelValue': _0x39bddb['coverUrl'],
                                            'onUpdate:modelValue': _0x4b5a90[0x2] || (_0x4b5a90[0x2] = _0x68062 => _0x39bddb['coverUrl'] = _0x68062),
                                            'placeholder': '请输入网站封面图片地址\x20(可选)',
                                            'clearable': ''
                                        }, {
                                            'prefix': _0x13a101(() => [_0x1cb2c4(_0x40300c, null, {
                                                    'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x1c0f07))]),
                                                    '_': 0x1
                                                })]),
                                            '_': 0x1
                                        }, 0x8, ['modelValue']),
                                        _0x39bddb['coverUrl'] ? (_0x3ad99a(), _0x484c9b('div', Xe, [_0x1cb2c4(_0x25a01a, {
                                                'src': _0x39bddb['coverUrl'],
                                                'fit': 'cover',
                                                'class': 'preview-image',
                                                'preview-src-list': _0x1c6d14['value'],
                                                'preview-teleported': !0x0
                                            }, {
                                                'placeholder': _0x13a101(() => [_0x5c00c1('div', Ye, [
                                                        _0x1cb2c4(_0x40300c, null, {
                                                            'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x25d5bf))]),
                                                            '_': 0x1
                                                        }),
                                                        _0x4b5a90[0x7] || (_0x4b5a90[0x7] = _0x5c00c1('span', null, '加载中...', -0x1))
                                                    ])]),
                                                'error': _0x13a101(() => [_0x5c00c1('div', Je, [
                                                        _0x1cb2c4(_0x40300c, null, {
                                                            'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x1c0f07))]),
                                                            '_': 0x1
                                                        }),
                                                        _0x4b5a90[0x8] || (_0x4b5a90[0x8] = _0x5c00c1('span', null, '图片加载失败', -0x1))
                                                    ])]),
                                                '_': 0x1
                                            }, 0x8, [
                                                'src',
                                                'preview-src-list'
                                            ])])) : _0x140f89('', !0x0)
                                    ]),
                                    '_': 0x1
                                }),
                                _0x1cb2c4(_0x522c52, {
                                    'label': '网站描述',
                                    'prop': 'description'
                                }, {
                                    'default': _0x13a101(() => [_0x1cb2c4(_0x4bbc87, {
                                            'modelValue': _0x39bddb['description'],
                                            'onUpdate:modelValue': _0x4b5a90[0x3] || (_0x4b5a90[0x3] = _0xdf2e7 => _0x39bddb['description'] = _0xdf2e7),
                                            'type': 'textarea',
                                            'rows': 0x3,
                                            'placeholder': '请简单描述您的网站内容和特色',
                                            'maxlength': '50',
                                            'show-word-limit': '',
                                            'resize': 'none'
                                        }, null, 0x8, ['modelValue'])]),
                                    '_': 0x1
                                }),
                                _0x1cb2c4(_0x522c52, {
                                    'label': '联系邮箱',
                                    'prop': 'email'
                                }, {
                                    'default': _0x13a101(() => [_0x1cb2c4(_0x4bbc87, {
                                            'modelValue': _0x39bddb['email'],
                                            'onUpdate:modelValue': _0x4b5a90[0x4] || (_0x4b5a90[0x4] = _0x306850 => _0x39bddb['email'] = _0x306850),
                                            'placeholder': '请输入您的邮箱地址',
                                            'clearable': ''
                                        }, {
                                            'prefix': _0x13a101(() => [_0x1cb2c4(_0x40300c, null, {
                                                    'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x2ad222))]),
                                                    '_': 0x1
                                                })]),
                                            '_': 0x1
                                        }, 0x8, ['modelValue'])]),
                                    '_': 0x1
                                })
                            ]),
                            '_': 0x1
                        }, 0x8, ['model']),
                        _0x5c00c1('div', Ke, [
                            _0x5c00c1('h4', Ze, [
                                _0x1cb2c4(_0x40300c, null, {
                                    'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x3b3f03))]),
                                    '_': 0x1
                                }),
                                _0x4b5a90[0x9] || (_0x4b5a90[0x9] = _0xca830e('\x20申请须知\x20'))
                            ]),
                            _0x4b5a90[0xa] || (_0x4b5a90[0xa] = _0x5c00c1('ul', { 'class': 'notice-list' }, [
                                _0x5c00c1('li', null, '请确保网站内容健康，符合相关法律法规'),
                                _0x5c00c1('li', null, '网站应正常运行，内容更新频率较高'),
                                _0x5c00c1('li', null, '管理员收到消息后会尽快完成审核'),
                                _0x5c00c1('li', null, '审核结果将通过邮箱通知您')
                            ], -0x1))
                        ])
                    ]),
                    '_': 0x1
                }, 0x8, [
                    'modelValue',
                    'width'
                ]);
            };
        }
    }, lt = _0x3e47ae(tt, [[
            '__scopeId',
            'data-v-466aaa33'
        ]]), st = { 'class': 'link-page' }, ot = { 'class': 'page-header' }, at = { 'class': 'container' }, nt = { 'class': 'header-content' }, it = { 'class': 'header-info' }, rt = { 'class': 'page-title' }, ut = {
        'key': 0x0,
        'class': 'header-actions'
    }, dt = {
        'key': 0x1,
        'class': 'header-actions'
    }, ct = { 'class': 'main-content' }, mt = { 'class': 'container' }, pt = { 'class': 'links-section' }, vt = {
        'key': 0x0,
        'class': 'loading-container'
    }, _t = { 'class': 'skeleton-content' }, ft = {
        'key': 0x1,
        'class': 'empty-state'
    }, gt = { 'class': 'empty-content' }, ht = { 'class': 'empty-icon' }, kt = { 'class': 'empty-description' }, yt = {
        'key': 0x2,
        'class': 'links-grid'
    }, bt = ['onClick'], wt = { 'class': 'link-cover' }, Et = { 'class': 'image-placeholder' }, xt = { 'class': 'image-error' }, Vt = { 'class': 'cover-overlay' }, Lt = { 'class': 'overlay-content' }, Ct = {
        'key': 0x0,
        'class': 'my-link-badge'
    }, Ut = { 'class': 'link-info' }, $t = ['title'], St = ['title'], Bt = { 'class': 'link-footer' }, Tt = { 'class': 'link-url' }, zt = {
        'key': 0x3,
        'class': 'loading-more'
    }, Mt = {
        'key': 0x4,
        'class': 'no-more'
    }, Nt = {
        '__name': 'index',
        'setup'(_0x4da7c5) {
            const _0x3ac02b = _0x2b09f2(), _0x578e7d = _0xe416ad(), _0x586d38 = _0x991dd1(!0x1), _0x199fea = _0x991dd1(!0x1), _0x48186b = _0x991dd1(!0x1), _0xd90195 = _0x991dd1(0x1), _0xb62e6 = _0x991dd1(0x18), _0x3bd1dc = _0x991dd1(0x0), _0x5ac0d0 = _0x991dd1(!0x0), _0x2be0fa = _0x991dd1([]), _0x538e36 = _0x991dd1(null), _0x14409d = _0x3eb7e5(() => _0x578e7d['user'] && _0x578e7d['user']['id']), _0x1c7233 = _0xc1254e => _0x578e7d['user'] && _0x578e7d['user']['id'] === _0xc1254e['userId'], _0x5c207c = async (_0x5a80c4 = !0x1) => {
                    if (!(_0x199fea['value'] || !_0x5ac0d0['value'] && !_0x5a80c4))
                        try {
                            _0x5a80c4 ? (_0x586d38['value'] = !0x0, _0xd90195['value'] = 0x1, _0x5ac0d0['value'] = !0x0) : _0x199fea['value'] = !0x0;
                            const _0x42f247 = (await Ge(_0xd90195['value'], _0xb62e6['value']))['data']['data'], _0xbc4149 = _0x42f247['data'] || [];
                            _0x5a80c4 ? _0x2be0fa['value'] = _0xbc4149 : _0x2be0fa['value'] = [
                                ..._0x2be0fa['value'],
                                ..._0xbc4149
                            ], _0x3bd1dc['value'] = _0x42f247['total'] || 0x0, _0x5ac0d0['value'] = _0x2be0fa['value']['length'] < _0x3bd1dc['value'], _0x5ac0d0['value'] && _0xbc4149['length'] > 0x0 && _0xd90195['value']++;
                        } catch (_0x3f99c6) {
                            _0x43247f['error']('获取友链列表失败'), console['error']('获取友链列表失败:', _0x3f99c6);
                        } finally {
                            _0x586d38['value'] = !0x1, _0x199fea['value'] = !0x1;
                        }
                }, _0x287504 = () => {
                    if (_0x586d38['value'] || _0x199fea['value'] || !_0x5ac0d0['value'])
                        return;
                    const {
                        scrollTop: _0x17017f,
                        scrollHeight: _0x4e9e30,
                        clientHeight: _0xdae714
                    } = document['documentElement'];
                    _0x17017f + _0xdae714 >= _0x4e9e30 - 0xc8 && _0x5c207c();
                }, _0x1a5893 = () => {
                    _0x48186b['value'] = !0x0;
                }, _0x5c2940 = () => {
                    _0x3ac02b['push']('/login');
                }, _0x69bfdf = () => {
                }, _0x109077 = _0x4247d7 => {
                    window['open'](_0x4247d7['url'], '_blank', 'noopener,noreferrer');
                }, _0x51ccc5 = _0x2a2939 => {
                    try {
                        return new URL(_0x2a2939)['hostname'];
                    } catch {
                        return _0x2a2939;
                    }
                }, _0x1f26b9 = async _0x19a075 => {
                    try {
                        await _0x51d09e['confirm']('确定要删除友链\x20\x22' + _0x19a075['name'] + '\x22\x20吗？此操作不可恢复。', '确认删除', {
                            'confirmButtonText': '确定',
                            'cancelButtonText': '取消',
                            'type': 'warning',
                            'confirmButtonClass': 'el-button--danger',
                            'lockScroll': !0x1
                        }), _0x538e36['value'] = _0x19a075['id'], await We(_0x19a075['id']), _0x2be0fa['value'] = _0x2be0fa['value']['filter'](_0x2d1c09 => _0x2d1c09['id'] !== _0x19a075['id']), _0x3bd1dc['value'] = Math['max'](0x0, _0x3bd1dc['value'] - 0x1), _0x43247f['success']('友链删除成功');
                    } catch (_0x5c13b3) {
                        _0x5c13b3 !== 'cancel' && (_0x43247f['error']('删除友链失败'), console['error']('删除友链失败:', _0x5c13b3));
                    } finally {
                        _0x538e36['value'] = null;
                    }
                };
            return _0x2bbc21(() => {
                _0x5c207c(!0x0), window['addEventListener']('scroll', _0x287504);
            }), _0x2b52c1(() => {
                window['removeEventListener']('scroll', _0x287504);
            }), (_0x372604, _0x3d438a) => {
                const _0x50e06e = _0x145566, _0x5acb48 = _0x5dea3a, _0x33fc5d = _0x40d988, _0x5609c1 = _0x1f31a7, _0x1ed777 = _0x279635, _0x1edbdd = Pe;
                return _0x3ad99a(), _0x484c9b('div', st, [
                    _0x5c00c1('div', ot, [_0x5c00c1('div', at, [_0x5c00c1('div', nt, [
                                _0x5c00c1('div', it, [
                                    _0x5c00c1('h1', rt, [
                                        _0x1cb2c4(_0x50e06e, { 'class': 'title-icon' }, {
                                            'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x3350bf))]),
                                            '_': 0x1
                                        }),
                                        _0x3d438a[0x2] || (_0x3d438a[0x2] = _0xca830e('\x20友情链接\x20'))
                                    ]),
                                    _0x3d438a[0x3] || (_0x3d438a[0x3] = _0x5c00c1('p', { 'class': 'page-description' }, '发现更多优质网站，与志同道合的朋友交换友链，共同成长', -0x1))
                                ]),
                                _0x14409d['value'] ? (_0x3ad99a(), _0x484c9b('div', ut, [_0x1cb2c4(_0x5acb48, {
                                        'type': 'primary',
                                        'size': 'large',
                                        'onClick': _0x1a5893,
                                        'class': 'apply-btn'
                                    }, {
                                        'default': _0x13a101(() => [
                                            _0x1cb2c4(_0x50e06e, null, {
                                                'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x579175))]),
                                                '_': 0x1
                                            }),
                                            _0x3d438a[0x4] || (_0x3d438a[0x4] = _0xca830e('\x20申请友链\x20'))
                                        ]),
                                        '_': 0x1,
                                        '__': [0x4]
                                    })])) : (_0x3ad99a(), _0x484c9b('div', dt, [_0x1cb2c4(_0x5acb48, {
                                        'size': 'large',
                                        'onClick': _0x5c2940,
                                        'class': 'login-btn'
                                    }, {
                                        'default': _0x13a101(() => [
                                            _0x1cb2c4(_0x50e06e, null, {
                                                'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x579175))]),
                                                '_': 0x1
                                            }),
                                            _0x3d438a[0x5] || (_0x3d438a[0x5] = _0xca830e('\x20登录后申请友链\x20'))
                                        ]),
                                        '_': 0x1,
                                        '__': [0x5]
                                    })]))
                            ])])]),
                    _0x5c00c1('div', ct, [_0x5c00c1('div', mt, [_0x5c00c1('div', pt, [
                                _0x586d38['value'] ? (_0x3ad99a(), _0x484c9b('div', vt, [_0x1cb2c4(_0x5609c1, {
                                        'animated': '',
                                        'count': 0x8
                                    }, {
                                        'template': _0x13a101(() => [_0x5c00c1('div', {
                                                'class': _0x458d3c([
                                                    'link-skeleton',
                                                    { 'list-mode': _0x372604['viewMode'] === 'list' }
                                                ])
                                            }, [
                                                _0x1cb2c4(_0x33fc5d, {
                                                    'variant': 'image',
                                                    'class': 'skeleton-image'
                                                }),
                                                _0x5c00c1('div', _t, [
                                                    _0x1cb2c4(_0x33fc5d, {
                                                        'variant': 'h3',
                                                        'style': {
                                                            'width': '60%',
                                                            'margin-bottom': '8px'
                                                        }
                                                    }),
                                                    _0x1cb2c4(_0x33fc5d, {
                                                        'variant': 'text',
                                                        'style': { 'width': '100%' }
                                                    }),
                                                    _0x1cb2c4(_0x33fc5d, {
                                                        'variant': 'text',
                                                        'style': { 'width': '80%' }
                                                    })
                                                ])
                                            ], 0x2)]),
                                        '_': 0x1
                                    })])) : _0x2be0fa['value']['length'] === 0x0 ? (_0x3ad99a(), _0x484c9b('div', ft, [_0x5c00c1('div', gt, [
                                        _0x5c00c1('div', ht, [_0x1cb2c4(_0x50e06e, null, {
                                                'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x191885))]),
                                                '_': 0x1
                                            })]),
                                        _0x3d438a[0x7] || (_0x3d438a[0x7] = _0x5c00c1('h3', { 'class': 'empty-title' }, '暂无友链', -0x1)),
                                        _0x5c00c1('p', kt, _0x19f777(_0x14409d['value'] ? '快来申请第一个友链吧！' : '暂时还没有友链，期待更多精彩网站加入！'), 0x1),
                                        _0x14409d['value'] ? (_0x3ad99a(), _0x2fc9fc(_0x5acb48, {
                                            'key': 0x0,
                                            'type': 'primary',
                                            'onClick': _0x1a5893
                                        }, {
                                            'default': _0x13a101(() => [
                                                _0x1cb2c4(_0x50e06e, null, {
                                                    'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x579175))]),
                                                    '_': 0x1
                                                }),
                                                _0x3d438a[0x6] || (_0x3d438a[0x6] = _0xca830e('\x20申请友链\x20'))
                                            ]),
                                            '_': 0x1,
                                            '__': [0x6]
                                        })) : _0x140f89('', !0x0)
                                    ])])) : (_0x3ad99a(), _0x484c9b('div', yt, [(_0x3ad99a(!0x0), _0x484c9b(_0x38e901, null, _0x3089ad(_0x2be0fa['value'], _0x5626a1 => (_0x3ad99a(), _0x484c9b('div', {
                                        'key': _0x5626a1['id'],
                                        'class': 'link-card',
                                        'onClick': _0x2d7c28 => _0x109077(_0x5626a1)
                                    }, [
                                        _0x3d438a[0xa] || (_0x3d438a[0xa] = _0x5c00c1('div', { 'class': 'card-bg-decoration' }, null, -0x1)),
                                        _0x5c00c1('div', wt, [
                                            _0x1cb2c4(_0x1ed777, {
                                                'src': _0x5626a1['coverUrl'] || '',
                                                'fit': 'contain',
                                                'class': 'cover-image',
                                                'alt': _0x5626a1['name']
                                            }, {
                                                'placeholder': _0x13a101(() => [_0x5c00c1('div', Et, [_0x1cb2c4(_0x50e06e, null, {
                                                            'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x25d5bf))]),
                                                            '_': 0x1
                                                        })])]),
                                                'error': _0x13a101(() => [_0x5c00c1('div', xt, [_0x1cb2c4(_0x50e06e, null, {
                                                            'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x1c0f07))]),
                                                            '_': 0x1
                                                        })])]),
                                                '_': 0x2
                                            }, 0x408, [
                                                'src',
                                                'alt'
                                            ]),
                                            _0x5c00c1('div', Vt, [_0x5c00c1('div', Lt, [
                                                    _0x1cb2c4(_0x50e06e, { 'class': 'visit-icon' }, {
                                                        'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x337594))]),
                                                        '_': 0x1
                                                    }),
                                                    _0x3d438a[0x8] || (_0x3d438a[0x8] = _0x5c00c1('span', { 'class': 'visit-text' }, '访问网站', -0x1))
                                                ])]),
                                            _0x1c7233(_0x5626a1) ? (_0x3ad99a(), _0x484c9b('div', Ct, [
                                                _0x1cb2c4(_0x50e06e, null, {
                                                    'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x1739db))]),
                                                    '_': 0x1
                                                }),
                                                _0x3d438a[0x9] || (_0x3d438a[0x9] = _0x5c00c1('span', null, '我的', -0x1))
                                            ])) : _0x140f89('', !0x0)
                                        ]),
                                        _0x5c00c1('div', Ut, [
                                            _0x5c00c1('h3', {
                                                'class': 'link-name',
                                                'title': _0x5626a1['name']
                                            }, _0x19f777(_0x5626a1['name']), 0x9, $t),
                                            _0x5c00c1('p', {
                                                'class': 'link-description',
                                                'title': _0x5626a1['description']
                                            }, _0x19f777(_0x5626a1['description']), 0x9, St),
                                            _0x5c00c1('div', Bt, [
                                                _0x5c00c1('div', Tt, [
                                                    _0x1cb2c4(_0x50e06e, { 'class': 'url-icon' }, {
                                                        'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x3350bf))]),
                                                        '_': 0x1
                                                    }),
                                                    _0x5c00c1('span', null, _0x19f777(_0x51ccc5(_0x5626a1['url'])), 0x1)
                                                ]),
                                                _0x1c7233(_0x5626a1) ? (_0x3ad99a(), _0x484c9b('div', {
                                                    'key': 0x0,
                                                    'class': 'delete-action',
                                                    'onClick': _0x3d438a[0x0] || (_0x3d438a[0x0] = _0x2adba6(() => {
                                                    }, ['stop']))
                                                }, [_0x1cb2c4(_0x5acb48, {
                                                        'type': 'danger',
                                                        'size': 'small',
                                                        'circle': '',
                                                        'class': 'delete-btn',
                                                        'onClick': _0x2d6ce9 => _0x1f26b9(_0x5626a1),
                                                        'loading': _0x538e36['value'] === _0x5626a1['id']
                                                    }, {
                                                        'default': _0x13a101(() => [_0x1cb2c4(_0x50e06e, null, {
                                                                'default': _0x13a101(() => [_0x1cb2c4(_0x41d4a8(_0x275ed6))]),
                                                                '_': 0x1
                                                            })]),
                                                        '_': 0x2
                                                    }, 0x408, [
                                                        'onClick',
                                                        'loading'
                                                    ])])) : _0x140f89('', !0x0)
                                            ])
                                        ])
                                    ], 0x8, bt))), 0x80))])),
                                _0x199fea['value'] && _0x2be0fa['value']['length'] > 0x0 ? (_0x3ad99a(), _0x484c9b('div', zt, _0x3d438a[0xb] || (_0x3d438a[0xb] = [
                                    _0x5c00c1('div', { 'class': 'loading-spinner' }, null, -0x1),
                                    _0x5c00c1('span', null, '加载更多...', -0x1)
                                ]))) : _0x140f89('', !0x0),
                                !_0x5ac0d0['value'] && _0x2be0fa['value']['length'] > 0x0 && !_0x586d38['value'] ? (_0x3ad99a(), _0x484c9b('div', Mt, _0x3d438a[0xc] || (_0x3d438a[0xc] = [_0x5c00c1('span', null, '已经到底了~', -0x1)]))) : _0x140f89('', !0x0)
                            ])])]),
                    _0x1cb2c4(lt, {
                        'modelValue': _0x48186b['value'],
                        'onUpdate:modelValue': _0x3d438a[0x1] || (_0x3d438a[0x1] = _0x2ea7a5 => _0x48186b['value'] = _0x2ea7a5),
                        'onSuccess': _0x69bfdf
                    }, null, 0x8, ['modelValue']),
                    _0x1cb2c4(_0x1edbdd, {
                        'right': 0x1e,
                        'bottom': 0x1e
                    })
                ]);
            };
        }
    }, nl = _0x3e47ae(Nt, [[
            '__scopeId',
            'data-v-75ae0e68'
        ]]);
export {
    nl as default
};