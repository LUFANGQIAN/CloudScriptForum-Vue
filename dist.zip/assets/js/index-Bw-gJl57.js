const _0x5baed9 = (function () {
        let _0xb1e880 = !![];
        return function (_0x5d6666, _0x26a3ee) {
            const _0x1bdcaf = _0xb1e880 ? function () {
                if (_0x26a3ee) {
                    const _0x52e5b7 = _0x26a3ee['apply'](_0x5d6666, arguments);
                    return _0x26a3ee = null, _0x52e5b7;
                }
            } : function () {
            };
            return _0xb1e880 = ![], _0x1bdcaf;
        };
    }()), _0x548d93 = _0x5baed9(this, function () {
        let _0x4e25e1;
        try {
            const _0x3bc001 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x4e25e1 = _0x3bc001();
        } catch (_0x423c1d) {
            _0x4e25e1 = window;
        }
        const _0x2496f1 = _0x4e25e1['console'] = _0x4e25e1['console'] || {}, _0x12c949 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x187ad1 = 0x0; _0x187ad1 < _0x12c949['length']; _0x187ad1++) {
            const _0x3ee1bc = _0x5baed9['constructor']['prototype']['bind'](_0x5baed9), _0x560613 = _0x12c949[_0x187ad1], _0xb9c321 = _0x2496f1[_0x560613] || _0x3ee1bc;
            _0x3ee1bc['__proto__'] = _0x5baed9['bind'](_0x5baed9), _0x3ee1bc['toString'] = _0xb9c321['toString']['bind'](_0xb9c321), _0x2496f1[_0x560613] = _0x3ee1bc;
        }
    });
_0x548d93();
import {
    b as _0x5bf294,
    E as _0x9f95ea,
    a as _0x3b0712
} from './Request-CHKnUlo5.js';
import { v as _0x1fa5e2 } from './el-loading-BYktkv7A.js';
import { E as _0x3c9ad4 } from './el-button-D6wSrR74.js';
import { E as _0x20c5b2 } from './el-avatar-D7H8d9zq.js';
import { E as _0x4a749b } from './el-empty-o9RgIX3C.js';
import {
    a as _0x2d4c9d,
    E as _0x190e30
} from './el-tab-pane-4BceK_p5.js';
import {
    _ as _0xf817ac,
    r as _0x42c3dc,
    aa as _0x5b5520,
    o as _0x19122d,
    Q as _0x3443aa,
    c as _0x7203fc,
    g as _0x510e75,
    A as _0xa415c5,
    d as _0x225846,
    f as _0x261880,
    k as _0x19d654,
    F as _0x114237,
    G as _0x5b009f,
    u as _0x122789,
    b as _0x5a2a17,
    j as _0xde5d67,
    e as _0x5e6147,
    z as _0x15c55f,
    C as _0x3a3140,
    m as _0xbba0d1,
    p as _0x370404,
    v as _0x2571e6,
    t as _0x4ebb24,
    ag as _0x1dd5b5
} from './index-54DmW9hq.js';
import {
    a as _0x581935,
    g as _0x401489,
    m as _0x1dfa20,
    d as _0x46a7ce
} from './notification-DP1N5YWr.js';
import './el-input-D-8X7_j3.js';
import './el-overlay-D3x7h4La.js';
import { E as _0x55afd0 } from './index-DbtH6USO.js';
import './aria-DyaK1nXM.js';
import './strings-D1s8bMmJ.js';
import './index-DMxv2JmO.js';
import './toNumber-DGNxa_rg.js';
import './event-BB_Ol6Sd.js';
import './index-Cbvjn2bC.js';
import './vnode-C3QoD07S.js';
import './_baseClone-DoJvIJg4.js';
import './index-ijNW1fhk.js';
import './scroll-DDB7nuLj.js';
import './focus-trap-Cbj9GFlW.js';
function $t(_0x315a52) {
    if (!_0x315a52)
        return '';
    const _0xe33d5c = new Date(_0x315a52), _0x27a08c = new Date(), _0x22f071 = _0x27a08c - _0xe33d5c;
    if (_0x22f071 < 0x3c * 0x3e8)
        return '刚刚';
    if (_0x22f071 < 0x3c * 0x3c * 0x3e8)
        return Math['floor'](_0x22f071 / 0xea60) + '分钟前';
    if (_0x22f071 < 0x18 * 0x3c * 0x3c * 0x3e8)
        return Math['floor'](_0x22f071 / 0x36ee80) + '小时前';
    if (_0x22f071 < 0x7 * 0x18 * 0x3c * 0x3c * 0x3e8)
        return Math['floor'](_0x22f071 / 0x5265c00) + '天前';
    const _0x3023c9 = _0xe33d5c['getFullYear'](), _0x533338 = String(_0xe33d5c['getMonth']() + 0x1)['padStart'](0x2, '0'), _0x5d2e0f = String(_0xe33d5c['getDate']())['padStart'](0x2, '0');
    return _0x3023c9 === _0x27a08c['getFullYear']() ? _0x533338 + '-' + _0x5d2e0f : _0x3023c9 + '-' + _0x533338 + '-' + _0x5d2e0f;
}
const Mt = { 'class': 'notification-center' }, Nt = { 'class': 'container' }, Bt = { 'class': 'notification-tabs' }, It = { 'class': 'tab-label' }, St = { 'class': 'tab-label' }, Lt = { 'class': 'tab-label' }, Rt = { 'class': 'tab-label' }, Vt = { 'class': 'tab-label' }, At = { 'class': 'notification-list' }, Ut = {
        'key': 0x0,
        'class': 'empty-state'
    }, zt = {
        'key': 0x1,
        'class': 'notification-items'
    }, Ft = ['onClick'], Ht = ['onClick'], Ot = { 'class': 'notification-text' }, Pt = ['onClick'], Yt = { 'class': 'message-text' }, jt = ['onClick'], Gt = {
        'key': 0x0,
        'class': 'comment-content'
    }, Jt = { 'class': 'comment-text' }, Qt = { 'class': 'notification-time' }, qt = { 'class': 'notification-actions' }, Kt = {
        'key': 0x0,
        'class': 'loading-more'
    }, Wt = {
        'key': 0x1,
        'class': 'no-more'
    }, Xt = {
        '__name': 'index',
        'setup'(_0x32132d) {
            const _0x5f25c4 = _0x122789(), _0x3310db = _0x42c3dc('system'), _0x3837a1 = _0x42c3dc(!0x1), _0x288c0d = _0x42c3dc(!0x1), _0x34a879 = _0x42c3dc([]), _0x1561cf = _0x42c3dc(0x1), _0x5dc53d = _0x42c3dc(0x14), _0x102171 = _0x42c3dc(0x0), _0x237431 = _0x42c3dc(!0x0), _0x17725e = _0x5b5520({
                    'total': 0x0,
                    'system': 0x0,
                    'comment': 0x0,
                    'like': 0x0,
                    'collect': 0x0,
                    'follow': 0x0
                }), _0x26af50 = {
                    'system': 0x0,
                    'comment': 0x1,
                    'like': 0x2,
                    'collect': 0x3,
                    'follow': 0x4
                }, _0x428fb8 = _0x5d61ee => {
                    try {
                        const _0x43d169 = JSON['parse'](_0x5d61ee['content']);
                        return {
                            ..._0x5d61ee,
                            'contentData': _0x43d169
                        };
                    } catch (_0x4347c0) {
                        return console['warn']('解析通知内容失败:', _0x4347c0), {
                            ..._0x5d61ee,
                            'contentData': {
                                'title': _0x5d61ee['content'],
                                'nickname': '系统'
                            }
                        };
                    }
                }, _0x2dffcf = async (_0x58f4c9 = !0x1) => {
                    try {
                        _0x58f4c9 ? (_0x3837a1['value'] = !0x0, _0x1561cf['value'] = 0x1, _0x34a879['value'] = []) : _0x288c0d['value'] = !0x0;
                        const _0x135117 = _0x26af50[_0x3310db['value']], _0x3437ff = (await _0x581935(_0x135117, _0x1561cf['value'], _0x5dc53d['value']))['data']['data'], _0x30fdc8 = (_0x3437ff['data'] || [])['map'](_0x89ee51 => _0x428fb8(_0x89ee51));
                        _0x58f4c9 ? _0x34a879['value'] = _0x30fdc8 : _0x34a879['value'] = [
                            ..._0x34a879['value'],
                            ..._0x30fdc8
                        ], _0x102171['value'] = _0x3437ff['total'] || 0x0, _0x237431['value'] = _0x34a879['value']['length'] < _0x102171['value'], _0x552bec(_0x30fdc8);
                    } catch (_0x9ef827) {
                        _0x5bf294['error']('获取通知列表失败'), console['error']('获取通知列表失败:', _0x9ef827);
                    } finally {
                        _0x3837a1['value'] = !0x1, _0x288c0d['value'] = !0x1;
                    }
                }, _0x552bec = async _0x2f245b => {
                    if (!_0x2f245b || _0x2f245b['length'] === 0x0)
                        return;
                    const _0x207f99 = _0x2f245b['filter'](_0x2a3407 => !_0x2a3407['isRead'])['map'](_0x37e8a8 => _0x37e8a8['id']);
                    if (_0x207f99['length'] !== 0x0)
                        try {
                            await _0x1dfa20(_0x207f99), _0x34a879['value']['forEach'](_0x4fa782 => {
                                _0x207f99['includes'](_0x4fa782['id']) && (_0x4fa782['isRead'] = 0x1);
                            }), await _0x174315(), window['dispatchEvent'](new CustomEvent('notification-read'));
                        } catch (_0x66401b) {
                            console['error']('自动标记已读失败:', _0x66401b);
                        }
                }, _0x174315 = async () => {
                    try {
                        const _0x239eca = (await _0x401489())['data']['data'];
                        Object['assign'](_0x17725e, _0x239eca);
                    } catch (_0x59d8d7) {
                        console['error']('获取未读数量失败:', _0x59d8d7);
                    }
                }, _0x5c9bb6 = _0x536adb => {
                    _0x3310db['value'] = _0x536adb, _0x2dffcf(!0x0);
                }, _0x2c5c1b = () => {
                    if (_0x3837a1['value'] || _0x288c0d['value'] || !_0x237431['value'])
                        return;
                    const _0x2aab38 = window['pageYOffset'] || document['documentElement']['scrollTop'] || document['body']['scrollTop'], _0xc54fa9 = window['innerHeight'], _0x2b3e56 = document['documentElement']['scrollHeight'];
                    _0x2aab38 + _0xc54fa9 >= _0x2b3e56 - 0x12c && (_0x1561cf['value']++, _0x2dffcf(!0x1));
                }, _0xd0b1ff = async _0x1c0d8d => {
                    try {
                        await _0x55afd0['confirm']('确定要删除这条通知吗？', '提示', {
                            'confirmButtonText': '确定',
                            'cancelButtonText': '取消',
                            'type': 'warning'
                        }), await _0x46a7ce([_0x1c0d8d]), _0x34a879['value'] = _0x34a879['value']['filter'](_0x5b6232 => _0x5b6232['id'] !== _0x1c0d8d), _0x102171['value']--, _0x174315(), _0x5bf294['success']('删除成功');
                    } catch (_0x332b03) {
                        _0x332b03 !== 'cancel' && (_0x5bf294['error']('删除失败'), console['error']('删除通知失败:', _0x332b03));
                    }
                }, _0x890bf1 = _0x30b6f3 => {
                    const _0x53dec6 = _0x30b6f3['contentData'];
                    if (!_0x53dec6 || !_0x53dec6['title'])
                        return _0x30b6f3['content'];
                    let _0x386954 = _0x53dec6['title'];
                    return _0x53dec6['nickname'] && (_0x386954 = _0x386954['replace'](_0x53dec6['nickname'], '')['trim']()), _0x53dec6['articleTitle'] && (_0x386954 = _0x386954['replace']('《' + _0x53dec6['articleTitle'] + '》', '')['trim']()), _0x386954;
                }, _0x4a73a1 = _0xd973f3 => {
                    _0xd973f3 && _0x5f25c4['push']('/user/' + _0xd973f3);
                }, _0x398332 = (_0x1ccad5, _0x17c6e1) => {
                    !_0x1ccad5 || !_0x17c6e1 || _0x5f25c4['push']('/user/' + _0x1ccad5 + '/article/' + _0x17c6e1);
                }, _0x35ddeb = _0x251492 => {
                    const _0x2b46bb = _0x251492['contentData'];
                    _0x2b46bb && (_0x2b46bb['articleId'] && _0x2b46bb['authorId'] ? _0x398332(_0x2b46bb['authorId'], _0x2b46bb['articleId']) : _0x2b46bb['userId'] && _0x4a73a1(_0x2b46bb['userId']));
                }, _0x47eb6b = _0x4d2ae9 => $t(_0x4d2ae9), _0x335eb6 = async () => {
                    _0x1561cf['value'] = 0x1, _0x237431['value'] = !0x0, await _0x2dffcf(!0x0), await _0x174315();
                };
            return _0x19122d(async () => {
                await _0x2dffcf(!0x0), _0x174315(), window['addEventListener']('scroll', _0x2c5c1b), window['addEventListener']('refresh-notifications', _0x335eb6);
            }), _0x3443aa(() => {
                window['removeEventListener']('scroll', _0x2c5c1b), window['removeEventListener']('refresh-notifications', _0x335eb6);
            }), (_0x1dc546, _0x3f8733) => {
                const _0x3ddbec = _0x9f95ea, _0x41fc09 = _0x190e30, _0x5f316b = _0x2d4c9d, _0x3810ba = _0x4a749b, _0x219731 = _0x3b0712, _0x570d03 = _0x20c5b2, _0x4bd31f = _0x3c9ad4, _0x22adf8 = _0x1fa5e2;
                return _0x5a2a17(), _0x7203fc('div', Mt, [_0x510e75('div', Nt, [
                        _0x3f8733[0x8] || (_0x3f8733[0x8] = _0x510e75('div', { 'class': 'page-header' }, [_0x510e75('h2', { 'class': 'page-title' }, '消息中心')], -0x1)),
                        _0x510e75('div', Bt, [_0x225846(_0x5f316b, {
                                'modelValue': _0x3310db['value'],
                                'onUpdate:modelValue': _0x3f8733[0x0] || (_0x3f8733[0x0] = _0x1bc71e => _0x3310db['value'] = _0x1bc71e),
                                'onTabChange': _0x5c9bb6
                            }, {
                                'default': _0x261880(() => [
                                    _0x225846(_0x41fc09, { 'name': 'system' }, {
                                        'label': _0x261880(() => [_0x510e75('span', It, [
                                                _0x3f8733[0x1] || (_0x3f8733[0x1] = _0xde5d67('\x20系统\x20')),
                                                _0x17725e['system'] > 0x0 ? (_0x5a2a17(), _0x5e6147(_0x3ddbec, {
                                                    'key': 0x0,
                                                    'value': _0x17725e['system'],
                                                    'max': 0x63,
                                                    'class': 'tab-badge'
                                                }, null, 0x8, ['value'])) : _0x19d654('', !0x0)
                                            ])]),
                                        '_': 0x1
                                    }),
                                    _0x225846(_0x41fc09, { 'name': 'comment' }, {
                                        'label': _0x261880(() => [_0x510e75('span', St, [
                                                _0x3f8733[0x2] || (_0x3f8733[0x2] = _0xde5d67('\x20评论\x20')),
                                                _0x17725e['comment'] > 0x0 ? (_0x5a2a17(), _0x5e6147(_0x3ddbec, {
                                                    'key': 0x0,
                                                    'value': _0x17725e['comment'],
                                                    'max': 0x63,
                                                    'class': 'tab-badge'
                                                }, null, 0x8, ['value'])) : _0x19d654('', !0x0)
                                            ])]),
                                        '_': 0x1
                                    }),
                                    _0x225846(_0x41fc09, { 'name': 'like' }, {
                                        'label': _0x261880(() => [_0x510e75('span', Lt, [
                                                _0x3f8733[0x3] || (_0x3f8733[0x3] = _0xde5d67('\x20点赞\x20')),
                                                _0x17725e['like'] > 0x0 ? (_0x5a2a17(), _0x5e6147(_0x3ddbec, {
                                                    'key': 0x0,
                                                    'value': _0x17725e['like'],
                                                    'max': 0x63,
                                                    'class': 'tab-badge'
                                                }, null, 0x8, ['value'])) : _0x19d654('', !0x0)
                                            ])]),
                                        '_': 0x1
                                    }),
                                    _0x225846(_0x41fc09, { 'name': 'collect' }, {
                                        'label': _0x261880(() => [_0x510e75('span', Rt, [
                                                _0x3f8733[0x4] || (_0x3f8733[0x4] = _0xde5d67('\x20收藏\x20')),
                                                _0x17725e['collect'] > 0x0 ? (_0x5a2a17(), _0x5e6147(_0x3ddbec, {
                                                    'key': 0x0,
                                                    'value': _0x17725e['collect'],
                                                    'max': 0x63,
                                                    'class': 'tab-badge'
                                                }, null, 0x8, ['value'])) : _0x19d654('', !0x0)
                                            ])]),
                                        '_': 0x1
                                    }),
                                    _0x225846(_0x41fc09, { 'name': 'follow' }, {
                                        'label': _0x261880(() => [_0x510e75('span', Vt, [
                                                _0x3f8733[0x5] || (_0x3f8733[0x5] = _0xde5d67('\x20关注\x20')),
                                                _0x17725e['follow'] > 0x0 ? (_0x5a2a17(), _0x5e6147(_0x3ddbec, {
                                                    'key': 0x0,
                                                    'value': _0x17725e['follow'],
                                                    'max': 0x63,
                                                    'class': 'tab-badge'
                                                }, null, 0x8, ['value'])) : _0x19d654('', !0x0)
                                            ])]),
                                        '_': 0x1
                                    })
                                ]),
                                '_': 0x1
                            }, 0x8, ['modelValue'])]),
                        _0xa415c5((_0x5a2a17(), _0x7203fc('div', At, [_0x34a879['value']['length'] === 0x0 && !_0x3837a1['value'] ? (_0x5a2a17(), _0x7203fc('div', Ut, [_0x225846(_0x3810ba, { 'description': '暂无通知' })])) : (_0x5a2a17(), _0x7203fc('div', zt, [
                                (_0x5a2a17(!0x0), _0x7203fc(_0x114237, null, _0x5b009f(_0x34a879['value'], _0x5e131d => {
                                    var _0x1688a7, _0x35f6ad, _0x31a482, _0x3ebfd7, _0x20c02a;
                                    return _0x5a2a17(), _0x7203fc('div', {
                                        'key': _0x5e131d['id'],
                                        'class': _0x15c55f([
                                            'notification-item',
                                            { 'unread': !_0x5e131d['isRead'] }
                                        ])
                                    }, [
                                        _0x510e75('div', {
                                            'class': 'notification-avatar',
                                            'onClick': _0x3a3140(_0x453d6a => {
                                                var _0x407ca6;
                                                return _0x4a73a1((_0x407ca6 = _0x5e131d['contentData']) == null ? void 0x0 : _0x407ca6['userId']);
                                            }, ['stop'])
                                        }, [_0x225846(_0x570d03, {
                                                'size': 0x30,
                                                'src': (_0x1688a7 = _0x5e131d['contentData']) == null ? void 0x0 : _0x1688a7['avatar'],
                                                'class': 'user-avatar'
                                            }, {
                                                'default': _0x261880(() => [_0x5e131d['type'] === 0x0 ? (_0x5a2a17(), _0x5e6147(_0x219731, {
                                                        'key': 0x0,
                                                        'class': 'icon-system'
                                                    }, {
                                                        'default': _0x261880(() => [_0x225846(_0xbba0d1(_0x370404))]),
                                                        '_': 0x1
                                                    })) : (_0x5a2a17(), _0x5e6147(_0x219731, { 'key': 0x1 }, {
                                                        'default': _0x261880(() => [_0x225846(_0xbba0d1(_0x2571e6))]),
                                                        '_': 0x1
                                                    }))]),
                                                '_': 0x2
                                            }, 0x408, ['src'])], 0x8, Ft),
                                        _0x510e75('div', {
                                            'class': 'notification-content',
                                            'onClick': _0x294f2d => _0x35ddeb(_0x5e131d)
                                        }, [
                                            _0x510e75('div', Ot, [
                                                _0x510e75('span', {
                                                    'class': 'user-nickname',
                                                    'onClick': _0x3a3140(_0x470679 => {
                                                        var _0x10ec67;
                                                        return _0x4a73a1((_0x10ec67 = _0x5e131d['contentData']) == null ? void 0x0 : _0x10ec67['userId']);
                                                    }, ['stop'])
                                                }, _0x4ebb24((_0x35f6ad = _0x5e131d['contentData']) == null ? void 0x0 : _0x35f6ad['nickname']), 0x9, Pt),
                                                _0x510e75('span', Yt, _0x4ebb24(_0x890bf1(_0x5e131d)), 0x1),
                                                (_0x31a482 = _0x5e131d['contentData']) != null && _0x31a482['articleTitle'] ? (_0x5a2a17(), _0x7203fc('span', {
                                                    'key': 0x0,
                                                    'class': 'article-title',
                                                    'onClick': _0x3a3140(_0x317dcc => {
                                                        var _0x2a143a, _0x253f4f;
                                                        return _0x398332((_0x2a143a = _0x5e131d['contentData']) == null ? void 0x0 : _0x2a143a['authorId'], (_0x253f4f = _0x5e131d['contentData']) == null ? void 0x0 : _0x253f4f['articleId']);
                                                    }, ['stop'])
                                                }, '\x20《' + _0x4ebb24((_0x3ebfd7 = _0x5e131d['contentData']) == null ? void 0x0 : _0x3ebfd7['articleTitle']) + '》\x20', 0x9, jt)) : _0x19d654('', !0x0)
                                            ]),
                                            (_0x20c02a = _0x5e131d['contentData']) != null && _0x20c02a['commentContent'] ? (_0x5a2a17(), _0x7203fc('div', Gt, [_0x510e75('span', Jt, _0x4ebb24(_0x5e131d['contentData']['commentContent']), 0x1)])) : _0x19d654('', !0x0),
                                            _0x510e75('div', Qt, _0x4ebb24(_0x47eb6b(_0x5e131d['createTime'])), 0x1)
                                        ], 0x8, Ht),
                                        _0x510e75('div', qt, [_0x225846(_0x4bd31f, {
                                                'type': 'danger',
                                                'size': 'small',
                                                'circle': '',
                                                'icon': _0xbba0d1(_0x1dd5b5),
                                                'onClick': _0x3a3140(_0x29ba69 => _0xd0b1ff(_0x5e131d['id']), ['stop']),
                                                'title': '删除'
                                            }, null, 0x8, [
                                                'icon',
                                                'onClick'
                                            ])])
                                    ], 0x2);
                                }), 0x80)),
                                _0x288c0d['value'] ? (_0x5a2a17(), _0x7203fc('div', Kt, _0x3f8733[0x6] || (_0x3f8733[0x6] = [
                                    _0x510e75('div', { 'class': 'loading-spinner' }, null, -0x1),
                                    _0x510e75('span', null, '加载中...', -0x1)
                                ]))) : !_0x237431['value'] && _0x34a879['value']['length'] > 0x0 ? (_0x5a2a17(), _0x7203fc('div', Wt, _0x3f8733[0x7] || (_0x3f8733[0x7] = [_0x510e75('span', null, '没有更多了', -0x1)]))) : _0x19d654('', !0x0)
                            ]))])), [[
                                _0x22adf8,
                                _0x3837a1['value']
                            ]])
                    ])]);
            };
        }
    }, Ee = _0xf817ac(Xt, [[
            '__scopeId',
            'data-v-d509ccda'
        ]]);
export {
    Ee as default
};