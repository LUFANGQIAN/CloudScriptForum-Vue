const _0x2d9004 = (function () {
        let _0x5bbb69 = !![];
        return function (_0xe34121, _0x1b7400) {
            const _0x161161 = _0x5bbb69 ? function () {
                if (_0x1b7400) {
                    const _0x231369 = _0x1b7400['apply'](_0xe34121, arguments);
                    return _0x1b7400 = null, _0x231369;
                }
            } : function () {
            };
            return _0x5bbb69 = ![], _0x161161;
        };
    }()), _0x360b8b = _0x2d9004(this, function () {
        const _0x431d4e = function () {
                let _0x407ba8;
                try {
                    _0x407ba8 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x412e3d) {
                    _0x407ba8 = window;
                }
                return _0x407ba8;
            }, _0x5dadb0 = _0x431d4e(), _0x479281 = _0x5dadb0['console'] = _0x5dadb0['console'] || {}, _0x2d1f08 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x145857 = 0x0; _0x145857 < _0x2d1f08['length']; _0x145857++) {
            const _0x18699d = _0x2d9004['constructor']['prototype']['bind'](_0x2d9004), _0x51285a = _0x2d1f08[_0x145857], _0x3d24ac = _0x479281[_0x51285a] || _0x18699d;
            _0x18699d['__proto__'] = _0x2d9004['bind'](_0x2d9004), _0x18699d['toString'] = _0x3d24ac['toString']['bind'](_0x3d24ac), _0x479281[_0x51285a] = _0x18699d;
        }
    });
_0x360b8b();
import {
    _ as _0x31b7ec,
    e as _0x4e87fa,
    i as _0x43ef36,
    b as _0x127dbf
} from './index-54DmW9hq.js';
const n = {};
function s(_0x3e806c, _0x14cd91) {
    const _0x507a89 = _0x43ef36('router-view');
    return _0x127dbf(), _0x4e87fa(_0x507a89, { 'class': 'album-router-view' });
}
const d = _0x31b7ec(n, [
    [
        'render',
        s
    ],
    [
        '__scopeId',
        'data-v-868d69a9'
    ]
]);
export {
    d as default
};