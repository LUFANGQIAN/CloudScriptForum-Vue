const _0x1935f1 = (function () {
        let _0x43d7aa = !![];
        return function (_0x31b063, _0x12a8c4) {
            const _0x45323c = _0x43d7aa ? function () {
                if (_0x12a8c4) {
                    const _0x274474 = _0x12a8c4['apply'](_0x31b063, arguments);
                    return _0x12a8c4 = null, _0x274474;
                }
            } : function () {
            };
            return _0x43d7aa = ![], _0x45323c;
        };
    }()), _0x391d9f = _0x1935f1(this, function () {
        let _0x293108;
        try {
            const _0x52d6e0 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x293108 = _0x52d6e0();
        } catch (_0x55748c) {
            _0x293108 = window;
        }
        const _0x376e37 = _0x293108['console'] = _0x293108['console'] || {}, _0x1ed892 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x1c4057 = 0x0; _0x1c4057 < _0x1ed892['length']; _0x1c4057++) {
            const _0x19c7e3 = _0x1935f1['constructor']['prototype']['bind'](_0x1935f1), _0x170d73 = _0x1ed892[_0x1c4057], _0xd220e2 = _0x376e37[_0x170d73] || _0x19c7e3;
            _0x19c7e3['__proto__'] = _0x1935f1['bind'](_0x1935f1), _0x19c7e3['toString'] = _0xd220e2['toString']['bind'](_0xd220e2), _0x376e37[_0x170d73] = _0x19c7e3;
        }
    });
_0x391d9f();
import {
    u as _0x2dcb21,
    b as _0x5bf3d6,
    a as _0x26772b
} from './Request-CHKnUlo5.js';
import { E as _0x3d18b6 } from './el-card-BzXeyFZ5.js';
import { E as _0x5018e0 } from './el-dialog-BYTqBsxC.js';
import './el-overlay-D3x7h4La.js';
import {
    a as _0x1091a8,
    E as _0x52bb3f
} from './el-form-item-CE_gZaOe.js';
import { E as _0x394dbb } from './el-input-D-8X7_j3.js';
import { E as _0x2984f3 } from './el-empty-o9RgIX3C.js';
import { E as _0x5166dc } from './el-image-viewer-DAjDHmiI.js';
import { E as _0x427acb } from './el-button-D6wSrR74.js';
import { E as _0x482274 } from './el-text-CbMl16cr.js';
import {
    a as _0x25a1d0,
    u as _0x108a80,
    c as _0x5313a1
} from './album-BHCMrxkD.js';
import {
    _ as _0x2992e0,
    s as _0x2e2a48,
    r as _0x2ac16c,
    o as _0x37a115,
    u as _0x35a451,
    c as _0x336ebc,
    d as _0x3e3027,
    f as _0x19118f,
    i as _0x3f9709,
    b as _0x9acbe9,
    e as _0x47b1c3,
    k as _0x58f3c4,
    g as _0x291d29,
    aj as _0x2e2f1c,
    F as _0x26dc51,
    G as _0x234f55,
    t as _0x332b3a,
    j as _0x13eb45,
    m as _0x531cdc
} from './index-54DmW9hq.js';
import './focus-trap-Cbj9GFlW.js';
import './aria-DyaK1nXM.js';
import './index-BLYrTdqd.js';
import './refs-mENLc3Ek.js';
import './event-BB_Ol6Sd.js';
import './vnode-C3QoD07S.js';
import './index-DMxv2JmO.js';
import './scroll-DDB7nuLj.js';
import './castArray-BGw1D6E-.js';
import './_baseClone-DoJvIJg4.js';
import './index-ijNW1fhk.js';
import './toNumber-DGNxa_rg.js';
const me = { 'class': 'album-container' }, ie = { 'class': 'card-header' }, ue = { 'class': 'album-grid' }, ce = ['onClick'], de = { 'class': 'error' }, _e = { 'class': 'album-info' }, pe = { 'class': 'album-name' }, fe = { 'class': 'dialog-footer' }, ve = {
        '__name': 'MyAlbum',
        'setup'(_0xa61c29) {
            const _0x10cad1 = _0x2dcb21(), {user: _0x6c9a36} = _0x2e2a48(_0x10cad1), _0x1b6603 = _0x35a451(), _0x3836e3 = _0x2ac16c(!0x1), _0x45fad4 = _0x2ac16c([]), _0xe626ad = _0x2ac16c(!0x1), _0x11145e = _0x2ac16c({
                    'name': '',
                    'coverUrl': ''
                }), _0x46f195 = () => {
                    _0x1b6603['push']({ 'name': 'AlbumSquare' });
                }, _0x210ddb = async () => {
                    _0x3836e3['value'] = !0x0;
                    try {
                        const _0x29f71a = await _0x25a1d0();
                        _0x45fad4['value'] = _0x29f71a['data']['data']['sort']((_0x7131f2, _0x282b6f) => _0x7131f2['id'] - _0x282b6f['id']);
                    } catch {
                        _0x5bf3d6['error']('获取相册列表失败');
                    } finally {
                        _0x3836e3['value'] = !0x1;
                    }
                }, _0x4ec567 = () => {
                    _0x11145e['value'] = {
                        'name': '',
                        'description': ''
                    }, _0xe626ad['value'] = !0x0;
                }, _0x8d5cbe = async () => {
                    if (!_0x11145e['value']['name']) {
                        _0x5bf3d6['warning']('请输入相册名称');
                        return;
                    }
                    try {
                        if (_0x11145e['value']['id']) {
                            const _0x276256 = {
                                'id': _0x11145e['value']['id'],
                                'name': _0x11145e['value']['name'],
                                'coverUrl': _0x11145e['value']['coverUrl']
                            };
                            await _0x108a80(_0x276256), _0x5bf3d6['success']('更新相册成功');
                        } else
                            await _0x5313a1(_0x11145e['value']), _0x5bf3d6['success']('创建相册成功');
                        _0xe626ad['value'] = !0x1, _0x210ddb();
                    } catch {
                        _0x5bf3d6['error']('操作相册失败');
                    }
                }, _0x41d4d6 = _0x17d136 => {
                    _0x1b6603['push']({
                        'name': 'AlbumDetail',
                        'params': { 'albumId': _0x17d136 }
                    });
                };
            return _0x37a115(() => {
                _0x6c9a36['value'] ? _0x210ddb() : (_0x5bf3d6['error']('请先登录'), _0x1b6603['push']('/login'));
            }), (_0x325d0d, _0x26bb57) => {
                const _0x2267f3 = _0x482274, _0x3420cd = _0x3f9709('HomeFilled'), _0x5aa2a7 = _0x26772b, _0x32eab5 = _0x427acb, _0x674250 = _0x3f9709('DocumentAdd'), _0x27755e = _0x3f9709('Picture'), _0x36663f = _0x5166dc, _0x5df754 = _0x2984f3, _0x2384b0 = _0x394dbb, _0x8a8b05 = _0x52bb3f, _0x4707f2 = _0x1091a8, _0x3c9747 = _0x5018e0, _0x4dd28e = _0x3d18b6;
                return _0x9acbe9(), _0x336ebc('div', me, [_0x3e3027(_0x4dd28e, {
                        'shadow': 'hover',
                        'class': 'main-card'
                    }, {
                        'header': _0x19118f(() => [_0x291d29('div', ie, [
                                _0x3e3027(_0x2267f3, {
                                    'class': 'title',
                                    'size': 'large'
                                }, {
                                    'default': _0x19118f(() => _0x26bb57[0x3] || (_0x26bb57[0x3] = [_0x13eb45('我的相册')])),
                                    '_': 0x1,
                                    '__': [0x3]
                                }),
                                _0x291d29('div', null, [
                                    _0x3e3027(_0x32eab5, {
                                        'type': 'primary',
                                        'onClick': _0x46f195,
                                        'class': 'album-square-btn'
                                    }, {
                                        'default': _0x19118f(() => [
                                            _0x3e3027(_0x5aa2a7, { 'style': { 'margin-right': '2px' } }, {
                                                'default': _0x19118f(() => [_0x3e3027(_0x3420cd)]),
                                                '_': 0x1
                                            }),
                                            _0x26bb57[0x4] || (_0x26bb57[0x4] = _0x13eb45('相册广场\x20'))
                                        ]),
                                        '_': 0x1,
                                        '__': [0x4]
                                    }),
                                    _0x531cdc(_0x6c9a36) ? (_0x9acbe9(), _0x47b1c3(_0x32eab5, {
                                        'key': 0x0,
                                        'type': 'primary',
                                        'onClick': _0x4ec567,
                                        'class': 'create-btn'
                                    }, {
                                        'default': _0x19118f(() => [
                                            _0x3e3027(_0x5aa2a7, { 'style': { 'margin-right': '2px' } }, {
                                                'default': _0x19118f(() => [_0x3e3027(_0x674250)]),
                                                '_': 0x1
                                            }),
                                            _0x26bb57[0x5] || (_0x26bb57[0x5] = _0x13eb45('新建相册\x20'))
                                        ]),
                                        '_': 0x1,
                                        '__': [0x5]
                                    })) : _0x58f3c4('', !0x0)
                                ])
                            ])]),
                        'default': _0x19118f(() => [
                            _0x3836e3['value'] ? (_0x9acbe9(), _0x47b1c3(_0x2e2f1c, { 'key': 0x0 })) : _0x58f3c4('', !0x0),
                            _0x291d29('div', ue, [(_0x9acbe9(!0x0), _0x336ebc(_0x26dc51, null, _0x234f55(_0x45fad4['value'], _0x39f170 => (_0x9acbe9(), _0x336ebc('div', {
                                    'key': _0x39f170['id'],
                                    'class': 'album-card'
                                }, [_0x291d29('div', {
                                        'class': 'album-image-container',
                                        'onClick': _0x21a52d => _0x41d4d6(_0x39f170['id'])
                                    }, [
                                        _0x3e3027(_0x36663f, {
                                            'src': _0x39f170['coverUrl'] || '',
                                            'class': 'album-image',
                                            'fit': 'cover',
                                            'lazy': 'true',
                                            'loading': 'lazy'
                                        }, {
                                            'placeholder': _0x19118f(() => _0x26bb57[0x6] || (_0x26bb57[0x6] = [_0x291d29('div', { 'class': 'loading-text' }, '加载中...', -0x1)])),
                                            'error': _0x19118f(() => [_0x291d29('div', de, [_0x3e3027(_0x5aa2a7, null, {
                                                        'default': _0x19118f(() => [_0x3e3027(_0x27755e)]),
                                                        '_': 0x1
                                                    })])]),
                                            '_': 0x2
                                        }, 0x408, ['src']),
                                        _0x291d29('div', _e, [_0x291d29('h3', pe, _0x332b3a(_0x39f170['name']), 0x1)])
                                    ], 0x8, ce)]))), 0x80))]),
                            _0x45fad4['value']['length'] === 0x0 && !_0x3836e3['value'] ? (_0x9acbe9(), _0x47b1c3(_0x5df754, {
                                'key': 0x1,
                                'image-size': 0xc8,
                                'description': '暂无相册'
                            })) : _0x58f3c4('', !0x0),
                            _0x3e3027(_0x3c9747, {
                                'modelValue': _0xe626ad['value'],
                                'onUpdate:modelValue': _0x26bb57[0x2] || (_0x26bb57[0x2] = _0x227370 => _0xe626ad['value'] = _0x227370),
                                'title': '新建相册'
                            }, {
                                'footer': _0x19118f(() => [_0x291d29('span', fe, [
                                        _0x3e3027(_0x32eab5, { 'onClick': _0x26bb57[0x1] || (_0x26bb57[0x1] = _0x5ad387 => _0xe626ad['value'] = !0x1) }, {
                                            'default': _0x19118f(() => _0x26bb57[0x7] || (_0x26bb57[0x7] = [_0x13eb45('取消')])),
                                            '_': 0x1,
                                            '__': [0x7]
                                        }),
                                        _0x3e3027(_0x32eab5, {
                                            'type': 'primary',
                                            'onClick': _0x8d5cbe
                                        }, {
                                            'default': _0x19118f(() => _0x26bb57[0x8] || (_0x26bb57[0x8] = [_0x13eb45('确定')])),
                                            '_': 0x1,
                                            '__': [0x8]
                                        })
                                    ])]),
                                'default': _0x19118f(() => [_0x3e3027(_0x4707f2, {
                                        'model': _0x11145e['value'],
                                        'label-width': '80px'
                                    }, {
                                        'default': _0x19118f(() => [_0x3e3027(_0x8a8b05, { 'label': '相册名称' }, {
                                                'default': _0x19118f(() => [_0x3e3027(_0x2384b0, {
                                                        'modelValue': _0x11145e['value']['name'],
                                                        'onUpdate:modelValue': _0x26bb57[0x0] || (_0x26bb57[0x0] = _0x334a4e => _0x11145e['value']['name'] = _0x334a4e)
                                                    }, null, 0x8, ['modelValue'])]),
                                                '_': 0x1
                                            })]),
                                        '_': 0x1
                                    }, 0x8, ['model'])]),
                                '_': 0x1
                            }, 0x8, ['modelValue'])
                        ]),
                        '_': 0x1
                    })]);
            };
        }
    }, Re = _0x2992e0(ve, [[
            '__scopeId',
            'data-v-99ecfd9e'
        ]]);
export {
    Re as default
};