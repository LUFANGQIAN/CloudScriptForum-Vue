const _0x1a9779 = (function () {
        let _0xca5a71 = !![];
        return function (_0x42fdfb, _0x18307b) {
            const _0x1f9911 = _0xca5a71 ? function () {
                if (_0x18307b) {
                    const _0x57730c = _0x18307b['apply'](_0x42fdfb, arguments);
                    return _0x18307b = null, _0x57730c;
                }
            } : function () {
            };
            return _0xca5a71 = ![], _0x1f9911;
        };
    }()), _0x501b34 = _0x1a9779(this, function () {
        let _0x3394d1;
        try {
            const _0x4b2f05 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x3394d1 = _0x4b2f05();
        } catch (_0x2bd09a) {
            _0x3394d1 = window;
        }
        const _0x174dd6 = _0x3394d1['console'] = _0x3394d1['console'] || {}, _0x239ae1 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x3d958a = 0x0; _0x3d958a < _0x239ae1['length']; _0x3d958a++) {
            const _0x1c2170 = _0x1a9779['constructor']['prototype']['bind'](_0x1a9779), _0x39a795 = _0x239ae1[_0x3d958a], _0x177949 = _0x174dd6[_0x39a795] || _0x1c2170;
            _0x1c2170['__proto__'] = _0x1a9779['bind'](_0x1a9779), _0x1c2170['toString'] = _0x177949['toString']['bind'](_0x177949), _0x174dd6[_0x39a795] = _0x1c2170;
        }
    });
_0x501b34();
import {
    _ as _0x43f57c,
    r as _0xf021bc,
    o as _0x4a924c,
    Q as _0x4b5e1f,
    c as _0x427caf,
    g as _0x409ed4,
    A as _0x1d638a,
    d as _0x375335,
    f as _0x47edae,
    k as _0xe4a8db,
    F as _0x6b4716,
    G as _0x3d8d24,
    B as _0x29010f,
    j as _0x45c2d3,
    E as _0x567f28,
    u as _0x33e00b,
    b as _0x22ed55,
    m as _0x5efc34,
    O as _0x836373,
    C as _0x41a6cc,
    t as _0x515adf,
    M as _0x5ab19b,
    h as _0xfc21be,
    R as _0x52127d,
    S as _0x189b87
} from './index-54DmW9hq.js';
import {
    u as _0x3cb8c5,
    a as _0x10afae,
    b as _0x493285
} from './Request-CHKnUlo5.js';
import { E as _0x4411d4 } from './el-avatar-D7H8d9zq.js';
import { E as _0x5e4d54 } from './el-image-viewer-DAjDHmiI.js';
import { E as _0x10c218 } from './el-empty-o9RgIX3C.js';
import {
    E as _0x38b627,
    a as _0x4e0659
} from './el-skeleton-item-BG_lS1DD.js';
import {
    g as _0x291337,
    a as _0x540427
} from './article-IrYQ22on.js';
import './focus-trap-Cbj9GFlW.js';
import './aria-DyaK1nXM.js';
import './index-BLYrTdqd.js';
import './toNumber-DGNxa_rg.js';
import './index-ijNW1fhk.js';
import './scroll-DDB7nuLj.js';
const dt = { 'class': 'article-page' }, _t = { 'class': 'content-section' }, ut = { 'class': 'container' }, ht = { 'class': 'content-layout' }, vt = { 'class': 'main-content' }, pt = { 'class': 'article-list-wrapper' }, mt = {
        'key': 0x0,
        'class': 'loading-container'
    }, ft = { 'class': 'article-skeleton' }, gt = { 'class': 'skeleton-content' }, kt = {
        'key': 0x1,
        'class': 'empty-state'
    }, wt = {
        'key': 0x2,
        'class': 'article-list'
    }, yt = ['onClick'], xt = { 'class': 'error' }, Ct = { 'class': 'article-content' }, Et = ['onClick'], At = { 'class': 'author-name' }, Lt = { 'class': 'article-title' }, bt = { 'class': 'article-description' }, St = { 'class': 'article-meta' }, Tt = { 'class': 'article-date' }, It = { 'class': 'article-readCount' }, $t = { 'class': 'article-likes' }, Mt = { 'class': 'article-collections' }, Bt = {
        'key': 0x0,
        'class': 'loading-more'
    }, Ht = { 'class': 'sidebar' }, Nt = { 'class': 'sidebar-card' }, Ut = { 'class': 'card-title' }, Vt = {
        'key': 0x0,
        'class': 'hot-articles-loading'
    }, zt = { 'class': 'hot-skeleton-item' }, Rt = {
        'key': 0x1,
        'class': 'hot-articles-empty'
    }, Dt = {
        'key': 0x2,
        'class': 'hot-articles'
    }, Ft = ['onClick'], Pt = { 'class': 'hot-article-rank' }, Yt = { 'class': 'hot-article-content' }, jt = { 'class': 'hot-article-title' }, Gt = { 'class': 'hot-article-meta' }, Ot = { 'class': 'hot-article-readCount' }, Qt = { 'class': 'hot-article-score' }, qt = {
        '__name': 'index',
        'setup'(_0x5ebaea) {
            _0x567f28();
            const _0x4a4ef4 = _0x33e00b();
            _0x3cb8c5();
            const _0x4b023d = _0xf021bc(!0x1), _0xf54c61 = _0xf021bc(!0x1), _0x364c53 = _0xf021bc([]), _0x2c7500 = _0xf021bc(0x0), _0x14b4ac = _0xf021bc(!0x0), _0x4fff60 = _0xf021bc(0x1), _0x406d3f = _0xf021bc(!0x1), _0x527bca = _0xf021bc(!0x1), _0x3b1758 = _0xf021bc([]), _0x4dc2f7 = _0xf021bc(0xa), _0xd81725 = _0xf021bc(null), _0x138ed2 = async (_0x55252e = !0x1) => {
                    if (!(!_0x14b4ac['value'] || _0x4b023d['value'] || _0xf54c61['value']))
                        try {
                            _0x55252e ? _0x4b023d['value'] = !0x0 : _0xf54c61['value'] = !0x0;
                            const _0x49ae8d = await _0x291337(_0x4fff60['value'], _0x4dc2f7['value']), _0x16171d = _0x49ae8d['data']['data']['data'] || [];
                            _0x2c7500['value'] = _0x49ae8d['data']['data']['total'] || 0x0, _0x55252e ? _0x364c53['value'] = _0x16171d : _0x364c53['value'] = [
                                ..._0x364c53['value'],
                                ..._0x16171d
                            ], _0x14b4ac['value'] = _0x364c53['value']['length'] < _0x2c7500['value'], _0x14b4ac['value'] && _0x16171d['length'] > 0x0 && _0x4fff60['value']++;
                        } catch (_0x24da37) {
                            _0x493285['error']('获取文章列表失败'), console['error']('获取文章列表失败:', _0x24da37);
                        } finally {
                            _0x4b023d['value'] = !0x1, _0xf54c61['value'] = !0x1;
                        }
                }, _0x25ab95 = () => {
                    window['scrollTo']({
                        'top': 0x0,
                        'behavior': 'smooth'
                    });
                }, _0x54c860 = () => {
                    _0x4b023d['value'] || _0xf54c61['value'] || !_0x14b4ac['value'] || (_0x406d3f['value'] = window['scrollY'] > 0xc8, window['innerHeight'] + window['scrollY'] >= document['documentElement']['scrollHeight'] - 0x64 && _0x138ed2());
                }, _0x3ebdaa = (_0x395eda, _0x58fd65) => {
                    _0x4a4ef4['push']('/user/' + _0x58fd65 + '/article/' + _0x395eda);
                }, _0x7989d5 = _0x3e759d => {
                    _0x4a4ef4['push']('/user/' + _0x3e759d);
                }, _0x3e159d = async () => {
                    try {
                        _0x527bca['value'] = !0x0;
                        const _0x38f98e = await _0x540427(0x1, 0xa);
                        _0x3b1758['value'] = _0x38f98e['data']['data']['data'] || [];
                    } catch (_0x2ad7a5) {
                        console['error']('获取热门文章列表失败:', _0x2ad7a5);
                    } finally {
                        _0x527bca['value'] = !0x1;
                    }
                };
            return _0x4a924c(() => {
                _0x138ed2(!0x0), _0x3e159d(), window['addEventListener']('scroll', _0x54c860);
            }), _0x4b5e1f(() => {
                window['removeEventListener']('scroll', _0x54c860);
            }), (_0x4b942d, _0x2a8e20) => {
                const _0x209355 = _0x4e0659, _0x4d286b = _0x38b627, _0x1878bf = _0x10c218, _0x2642ad = _0x10afae, _0x9a2216 = _0x5e4d54, _0x4ca7a0 = _0x4411d4, _0x42232c = _0xfc21be;
                return _0x22ed55(), _0x427caf('div', dt, [_0x409ed4('div', _t, [_0x409ed4('div', ut, [_0x409ed4('div', ht, [
                                _0x409ed4('div', vt, [_0x409ed4('div', pt, [_0x409ed4('div', {
                                            'class': 'article-list-section',
                                            'ref_key': 'listContainer',
                                            'ref': _0xd81725
                                        }, [
                                            _0x4b023d['value'] ? (_0x22ed55(), _0x427caf('div', mt, [_0x375335(_0x4d286b, {
                                                    'animated': '',
                                                    'count': 0x8
                                                }, {
                                                    'template': _0x47edae(() => [_0x409ed4('div', ft, [
                                                            _0x375335(_0x209355, {
                                                                'variant': 'image',
                                                                'style': {
                                                                    'width': '160px',
                                                                    'height': '100px'
                                                                }
                                                            }),
                                                            _0x409ed4('div', gt, [
                                                                _0x375335(_0x209355, {
                                                                    'variant': 'h3',
                                                                    'style': { 'width': '70%' }
                                                                }),
                                                                _0x375335(_0x209355, {
                                                                    'variant': 'text',
                                                                    'style': { 'width': '100%' }
                                                                }),
                                                                _0x375335(_0x209355, {
                                                                    'variant': 'text',
                                                                    'style': { 'width': '60%' }
                                                                })
                                                            ])
                                                        ])]),
                                                    '_': 0x1
                                                })])) : _0x364c53['value']['length'] === 0x0 ? (_0x22ed55(), _0x427caf('div', kt, [_0x375335(_0x1878bf, { 'description': '暂无文章' })])) : (_0x22ed55(), _0x427caf('div', wt, [
                                                (_0x22ed55(!0x0), _0x427caf(_0x6b4716, null, _0x3d8d24(_0x364c53['value'], _0x205d04 => (_0x22ed55(), _0x427caf('div', {
                                                    'key': _0x205d04['id'],
                                                    'class': 'article-item',
                                                    'onClick': _0x22c65d => _0x3ebdaa(_0x205d04['id'], _0x205d04['userId'])
                                                }, [
                                                    _0x375335(_0x9a2216, {
                                                        'src': _0x205d04['coverUrl'],
                                                        'class': 'article-cover'
                                                    }, {
                                                        'placeholder': _0x47edae(() => _0x2a8e20[0x0] || (_0x2a8e20[0x0] = [_0x409ed4('div', { 'class': 'loading-text' }, '加载中...', -0x1)])),
                                                        'error': _0x47edae(() => [_0x409ed4('div', xt, [_0x375335(_0x2642ad, null, {
                                                                    'default': _0x47edae(() => [_0x375335(_0x5efc34(_0x836373))]),
                                                                    '_': 0x1
                                                                })])]),
                                                        '_': 0x2
                                                    }, 0x408, ['src']),
                                                    _0x409ed4('div', Ct, [
                                                        _0x409ed4('div', {
                                                            'class': 'article-author',
                                                            'onClick': _0x41a6cc(_0x509a1f => _0x7989d5(_0x205d04['userId']), ['stop'])
                                                        }, [
                                                            _0x375335(_0x4ca7a0, {
                                                                'size': 0x18,
                                                                'src': _0x205d04['avatar'],
                                                                'class': 'author-avatar'
                                                            }, null, 0x8, ['src']),
                                                            _0x409ed4('span', At, _0x515adf(_0x205d04['nickname']), 0x1)
                                                        ], 0x8, Et),
                                                        _0x409ed4('h3', Lt, _0x515adf(_0x205d04['title']), 0x1),
                                                        _0x409ed4('p', bt, _0x515adf(_0x205d04['description']), 0x1),
                                                        _0x409ed4('div', St, [
                                                            _0x409ed4('span', Tt, _0x515adf(_0x205d04['createTime']), 0x1),
                                                            _0x409ed4('span', It, [
                                                                _0x375335(_0x2642ad, null, {
                                                                    'default': _0x47edae(() => [_0x375335(_0x5efc34(_0x5ab19b))]),
                                                                    '_': 0x1
                                                                }),
                                                                _0x45c2d3('\x20' + _0x515adf(_0x205d04['readCount']) + '\x20阅读', 0x1)
                                                            ]),
                                                            _0x409ed4('span', $t, [
                                                                _0x375335(_0x42232c, {
                                                                    'name': 'like',
                                                                    'width': '13px',
                                                                    'height': '13px',
                                                                    'color': '#909399'
                                                                }),
                                                                _0x45c2d3('\x20' + _0x515adf(_0x205d04['likeCount'] || 0x0) + '\x20点赞', 0x1)
                                                            ]),
                                                            _0x409ed4('span', Mt, [
                                                                _0x375335(_0x2642ad, null, {
                                                                    'default': _0x47edae(() => [_0x375335(_0x5efc34(_0x52127d))]),
                                                                    '_': 0x1
                                                                }),
                                                                _0x45c2d3('\x20' + _0x515adf(_0x205d04['collectCount'] || 0x0) + '\x20收藏', 0x1)
                                                            ])
                                                        ])
                                                    ])
                                                ], 0x8, yt))), 0x80)),
                                                _0xf54c61['value'] ? (_0x22ed55(), _0x427caf('div', Bt, _0x2a8e20[0x1] || (_0x2a8e20[0x1] = [
                                                    _0x409ed4('div', { 'class': 'loading-spinner' }, null, -0x1),
                                                    _0x409ed4('span', null, '加载更多...', -0x1)
                                                ]))) : _0xe4a8db('', !0x0)
                                            ])),
                                            _0x1d638a(_0x409ed4('div', {
                                                'class': 'back-to-top',
                                                'onClick': _0x25ab95
                                            }, [_0x375335(_0x2642ad, null, {
                                                    'default': _0x47edae(() => [_0x375335(_0x5efc34(_0x189b87))]),
                                                    '_': 0x1
                                                })], 0x200), [[
                                                    _0x29010f,
                                                    _0x406d3f['value']
                                                ]])
                                        ], 0x200)])]),
                                _0x409ed4('div', Ht, [_0x409ed4('div', Nt, [
                                        _0x409ed4('h4', Ut, [
                                            _0x375335(_0x2642ad, { 'style': { 'margin-right': '4px' } }, {
                                                'default': _0x47edae(() => [_0x375335(_0x5efc34(_0x5ab19b))]),
                                                '_': 0x1
                                            }),
                                            _0x2a8e20[0x2] || (_0x2a8e20[0x2] = _0x45c2d3('\x20热门文章\x20'))
                                        ]),
                                        _0x527bca['value'] ? (_0x22ed55(), _0x427caf('div', Vt, [_0x375335(_0x4d286b, {
                                                'animated': '',
                                                'count': 0x5
                                            }, {
                                                'template': _0x47edae(() => [_0x409ed4('div', zt, [
                                                        _0x375335(_0x209355, {
                                                            'variant': 'text',
                                                            'style': {
                                                                'width': '100%',
                                                                'height': '16px',
                                                                'margin-bottom': '4px'
                                                            }
                                                        }),
                                                        _0x375335(_0x209355, {
                                                            'variant': 'text',
                                                            'style': {
                                                                'width': '60%',
                                                                'height': '14px'
                                                            }
                                                        })
                                                    ])]),
                                                '_': 0x1
                                            })])) : _0x3b1758['value']['length'] === 0x0 ? (_0x22ed55(), _0x427caf('div', Rt, [_0x375335(_0x1878bf, {
                                                'description': '暂无热门文章',
                                                'image-size': 0x3c
                                            })])) : (_0x22ed55(), _0x427caf('div', Dt, [(_0x22ed55(!0x0), _0x427caf(_0x6b4716, null, _0x3d8d24(_0x3b1758['value'], (_0x4bdccf, _0x45371d) => (_0x22ed55(), _0x427caf('div', {
                                                'key': _0x4bdccf['id'],
                                                'class': 'hot-article-item',
                                                'onClick': _0x3a9ab6 => _0x3ebdaa(_0x4bdccf['id'], _0x4bdccf['userId'])
                                            }, [
                                                _0x409ed4('div', Pt, _0x515adf(_0x45371d + 0x1), 0x1),
                                                _0x409ed4('div', Yt, [
                                                    _0x409ed4('span', jt, _0x515adf(_0x4bdccf['title']), 0x1),
                                                    _0x409ed4('div', Gt, [
                                                        _0x409ed4('span', Ot, [
                                                            _0x375335(_0x2642ad, null, {
                                                                'default': _0x47edae(() => [_0x375335(_0x5efc34(_0x5ab19b))]),
                                                                '_': 0x1
                                                            }),
                                                            _0x45c2d3('\x20' + _0x515adf(_0x4bdccf['readCount']), 0x1)
                                                        ]),
                                                        _0x409ed4('span', Qt, '🔥\x20' + _0x515adf(_0x4bdccf['hotScore']), 0x1)
                                                    ])
                                                ])
                                            ], 0x8, Ft))), 0x80))]))
                                    ])])
                            ])])])]);
            };
        }
    }, _e = _0x43f57c(qt, [[
            '__scopeId',
            'data-v-b2bc056d'
        ]]);
export {
    _e as default
};