var _0x3a0c99 = (function () {
        var _0x32c09c = !![];
        return function (_0x4d2c99, _0x3aa67e) {
            var _0xfff240 = _0x32c09c ? function () {
                if (_0x3aa67e) {
                    var _0x3ae770 = _0x3aa67e['apply'](_0x4d2c99, arguments);
                    return _0x3aa67e = null, _0x3ae770;
                }
            } : function () {
            };
            return _0x32c09c = ![], _0xfff240;
        };
    }()), _0x5a85db = _0x3a0c99(this, function () {
        var _0x4f9d51 = function () {
                var _0x399af6;
                try {
                    _0x399af6 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x2eb40e) {
                    _0x399af6 = window;
                }
                return _0x399af6;
            }, _0x6d1e39 = _0x4f9d51(), _0xb65cfa = _0x6d1e39['console'] = _0x6d1e39['console'] || {}, _0x3cd40b = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (var _0x31aace = 0x0; _0x31aace < _0x3cd40b['length']; _0x31aace++) {
            var _0x174a60 = _0x3a0c99['constructor']['prototype']['bind'](_0x3a0c99), _0x149df6 = _0x3cd40b[_0x31aace], _0x38bf36 = _0xb65cfa[_0x149df6] || _0x174a60;
            _0x174a60['__proto__'] = _0x3a0c99['bind'](_0x3a0c99), _0x174a60['toString'] = _0x38bf36['toString']['bind'](_0x38bf36), _0xb65cfa[_0x149df6] = _0x174a60;
        }
    });
_0x5a85db();
import {
    am as _0x18bbcb,
    a6 as _0x4c0cab
} from './Request-CHKnUlo5.js';
var f = /\s/;
function a(_0x1c889a) {
    for (var _0xd9f065 = _0x1c889a['length']; _0xd9f065-- && f['test'](_0x1c889a['charAt'](_0xd9f065)););
    return _0xd9f065;
}
var c = /^\s+/;
function o(_0x36dfe2) {
    return _0x36dfe2 && _0x36dfe2['slice'](0x0, a(_0x36dfe2) + 0x1)['replace'](c, '');
}
var n = NaN, m = /^[-+]0x[0-9a-f]+$/i, p = /^0b[01]+$/i, b = /^0o[0-7]+$/i, y = parseInt;
function d(_0x195942) {
    if (typeof _0x195942 == 'number')
        return _0x195942;
    if (_0x18bbcb(_0x195942))
        return n;
    if (_0x4c0cab(_0x195942)) {
        var _0x23bbf9 = typeof _0x195942['valueOf'] == 'function' ? _0x195942['valueOf']() : _0x195942;
        _0x195942 = _0x4c0cab(_0x23bbf9) ? _0x23bbf9 + '' : _0x23bbf9;
    }
    if (typeof _0x195942 != 'string')
        return _0x195942 === 0x0 ? _0x195942 : +_0x195942;
    _0x195942 = o(_0x195942);
    var _0x455ffc = p['test'](_0x195942);
    return _0x455ffc || b['test'](_0x195942) ? y(_0x195942['slice'](0x2), _0x455ffc ? 0x2 : 0x8) : m['test'](_0x195942) ? n : +_0x195942;
}
export {
    d as t
};