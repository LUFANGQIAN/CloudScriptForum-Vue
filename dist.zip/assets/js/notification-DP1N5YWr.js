var _0x2352ad = (function () {
        var _0x172ad0 = !![];
        return function (_0x4ee7e0, _0x3f6161) {
            var _0x42b9f1 = _0x172ad0 ? function () {
                if (_0x3f6161) {
                    var _0x51ba68 = _0x3f6161['apply'](_0x4ee7e0, arguments);
                    return _0x3f6161 = null, _0x51ba68;
                }
            } : function () {
            };
            return _0x172ad0 = ![], _0x42b9f1;
        };
    }()), _0x17fbc8 = _0x2352ad(this, function () {
        var _0x14f682 = function () {
                var _0x125447;
                try {
                    _0x125447 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x24eb3b) {
                    _0x125447 = window;
                }
                return _0x125447;
            }, _0x41715f = _0x14f682(), _0x198b79 = _0x41715f['console'] = _0x41715f['console'] || {}, _0x9dbd9 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (var _0x29215d = 0x0; _0x29215d < _0x9dbd9['length']; _0x29215d++) {
            var _0x3522e8 = _0x2352ad['constructor']['prototype']['bind'](_0x2352ad), _0x4613fd = _0x9dbd9[_0x29215d], _0x1eaf4a = _0x198b79[_0x4613fd] || _0x3522e8;
            _0x3522e8['__proto__'] = _0x2352ad['bind'](_0x2352ad), _0x3522e8['toString'] = _0x1eaf4a['toString']['bind'](_0x1eaf4a), _0x198b79[_0x4613fd] = _0x3522e8;
        }
    });
_0x17fbc8();
import { r as _0x33efcd } from './Request-CHKnUlo5.js';
function n(_0xa73f3, _0x33a1dd, _0x21c616) {
    return _0x33efcd({
        'url': '/message/notifications',
        'method': 'get',
        'params': {
            'type': _0xa73f3,
            'pageNum': _0x33a1dd,
            'pageSize': _0x21c616
        }
    });
}
function s() {
    return _0x33efcd({
        'url': '/message/notifications/unread/count',
        'method': 'get'
    });
}
function r(_0x5aafd8) {
    return _0x33efcd({
        'url': '/message/notifications/read',
        'method': 'put',
        'data': _0x5aafd8
    });
}
function u(_0x311289) {
    return _0x33efcd({
        'url': '/message/notifications',
        'method': 'delete',
        'data': _0x311289
    });
}
export {
    n as a,
    u as d,
    s as g,
    r as m
};