var _0xb66f9 = (function () {
        var _0x16fd2e = !![];
        return function (_0x5ae027, _0x564c07) {
            var _0x60760e = _0x16fd2e ? function () {
                if (_0x564c07) {
                    var _0x46d4c1 = _0x564c07['apply'](_0x5ae027, arguments);
                    return _0x564c07 = null, _0x46d4c1;
                }
            } : function () {
            };
            return _0x16fd2e = ![], _0x60760e;
        };
    }()), _0x11a755 = _0xb66f9(this, function () {
        var _0x41f482;
        try {
            var _0x594674 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x41f482 = _0x594674();
        } catch (_0x2483e4) {
            _0x41f482 = window;
        }
        var _0x504eb5 = _0x41f482['console'] = _0x41f482['console'] || {}, _0x2723fd = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (var _0x2222d6 = 0x0; _0x2222d6 < _0x2723fd['length']; _0x2222d6++) {
            var _0x8c878 = _0xb66f9['constructor']['prototype']['bind'](_0xb66f9), _0x11d609 = _0x2723fd[_0x2222d6], _0x6f53bb = _0x504eb5[_0x11d609] || _0x8c878;
            _0x8c878['__proto__'] = _0xb66f9['bind'](_0xb66f9), _0x8c878['toString'] = _0x6f53bb['toString']['bind'](_0x6f53bb), _0x504eb5[_0x11d609] = _0x8c878;
        }
    });
_0x11a755();
import { r as _0x3dc8d2 } from './Request-CHKnUlo5.js';
function s(_0x245ad0) {
    return _0x3dc8d2({
        'url': '/article/add',
        'method': 'post',
        'data': _0x245ad0
    });
}
function u(_0x1b2d23) {
    return _0x3dc8d2({
        'url': '/article/saveDraft',
        'method': 'post',
        'data': _0x1b2d23
    });
}
function n(_0x20c1ca) {
    return _0x3dc8d2({
        'url': '/article/get/' + _0x20c1ca,
        'method': 'get'
    });
}
function c(_0x3a3a83, _0x115155, _0x28d023) {
    return _0x3dc8d2({
        'url': '/article/user/list?pageNum=' + _0x3a3a83 + '&pageSize=' + _0x115155,
        'method': 'post',
        'data': _0x28d023
    });
}
function l(_0x3c34e0, _0x1df4e8, _0x4698e7) {
    return _0x3dc8d2({
        'url': '/article/manage/list?pageNum=' + _0x3c34e0 + '&pageSize=' + _0x1df4e8,
        'method': 'post',
        'data': _0x4698e7
    });
}
function o(_0x58bc9b) {
    return _0x3dc8d2({
        'url': '/article/update',
        'method': 'put',
        'data': _0x58bc9b
    });
}
function g(_0x41a05b) {
    return _0x3dc8d2({
        'url': '/article/delete/' + _0x41a05b,
        'method': 'delete'
    });
}
function d() {
    return _0x3dc8d2({
        'url': '/article/user/statistics',
        'method': 'get'
    });
}
function m(_0x46b159) {
    return _0x3dc8d2({
        'url': '/article/user/' + _0x46b159 + '/statistics',
        'method': 'get'
    });
}
function h(_0x4d034b, _0x2567e6) {
    return _0x3dc8d2({
        'url': '/article/listAll?pageNum=' + _0x4d034b + '&pageSize=' + _0x2567e6,
        'method': 'get'
    });
}
function p() {
    return _0x3dc8d2({
        'url': '/article/creation/statistics',
        'method': 'get'
    });
}
function f(_0xc3f960, _0x47e813, _0x1c9d9c) {
    return _0x3dc8d2({
        'url': '/article/search?title=' + _0xc3f960 + '&pageNum=' + _0x47e813 + '&pageSize=' + _0x1c9d9c,
        'method': 'get'
    });
}
function $(_0x3033cf, _0xd390c, _0x1313d3) {
    return _0x3dc8d2({
        'url': '/article/search/tag?tag=' + _0x3033cf + '&pageNum=' + _0xd390c + '&pageSize=' + _0x1313d3,
        'method': 'get'
    });
}
function A(_0x5c2b32) {
    return _0x3dc8d2({
        'url': '/article/search/suggestions/title?keyword=' + encodeURIComponent(_0x5c2b32),
        'method': 'get'
    });
}
function S(_0x42f517) {
    return _0x3dc8d2({
        'url': '/article/search/suggestions/tag?keyword=' + encodeURIComponent(_0x42f517),
        'method': 'get'
    });
}
function z(_0x854914, _0x451f27) {
    return _0x3dc8d2({
        'url': '/article/hot?pageNum=' + _0x854914 + '&pageSize=' + _0x451f27,
        'method': 'get'
    });
}
export {
    z as a,
    $ as b,
    S as c,
    A as d,
    c as e,
    m as f,
    h as g,
    n as h,
    p as i,
    l as j,
    d as k,
    g as l,
    s as m,
    u as n,
    f as s,
    o as u
};