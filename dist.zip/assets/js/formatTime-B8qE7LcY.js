const _0x5999f7 = (function () {
        let _0x1bee03 = !![];
        return function (_0x2c25fe, _0x4d1a10) {
            const _0x2f7696 = _0x1bee03 ? function () {
                if (_0x4d1a10) {
                    const _0x3588e3 = _0x4d1a10['apply'](_0x2c25fe, arguments);
                    return _0x4d1a10 = null, _0x3588e3;
                }
            } : function () {
            };
            return _0x1bee03 = ![], _0x2f7696;
        };
    }()), _0x3b8025 = _0x5999f7(this, function () {
        const _0x121f53 = function () {
                let _0x1dc49f;
                try {
                    _0x1dc49f = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0xe5243c) {
                    _0x1dc49f = window;
                }
                return _0x1dc49f;
            }, _0x440de1 = _0x121f53(), _0x35f9ce = _0x440de1['console'] = _0x440de1['console'] || {}, _0x54a63f = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x31b3c4 = 0x0; _0x31b3c4 < _0x54a63f['length']; _0x31b3c4++) {
            const _0x113f8c = _0x5999f7['constructor']['prototype']['bind'](_0x5999f7), _0xd6919f = _0x54a63f[_0x31b3c4], _0x45903c = _0x35f9ce[_0xd6919f] || _0x113f8c;
            _0x113f8c['__proto__'] = _0x5999f7['bind'](_0x5999f7), _0x113f8c['toString'] = _0x45903c['toString']['bind'](_0x45903c), _0x35f9ce[_0xd6919f] = _0x113f8c;
        }
    });
_0x3b8025();
const D = _0x5cddc2 => {
        if (!_0x5cddc2)
            return '';
        const _0x277c47 = new Date(), _0x5d6582 = new Date(_0x5cddc2), _0x5da384 = _0x277c47['getTime']() - _0x5d6582['getTime'](), _0x1e3d79 = 0x3c * 0x3e8, _0x187b23 = 0x3c * _0x1e3d79, _0x540b4d = 0x18 * _0x187b23, _0x57a372 = 0x7 * _0x540b4d, _0x4aa4cf = 0x1e * _0x540b4d, _0x9a727e = 0x16d * _0x540b4d;
        return _0x5da384 < _0x1e3d79 ? '刚刚' : _0x5da384 < _0x187b23 ? Math['floor'](_0x5da384 / _0x1e3d79) + '分钟前' : _0x5da384 < _0x540b4d ? Math['floor'](_0x5da384 / _0x187b23) + '小时前' : _0x5da384 < _0x57a372 ? Math['floor'](_0x5da384 / _0x540b4d) + '天前' : _0x5da384 < _0x4aa4cf ? Math['floor'](_0x5da384 / _0x57a372) + '周前' : _0x5da384 < _0x9a727e ? Math['floor'](_0x5da384 / _0x4aa4cf) + '个月前' : i(_0x5d6582, 'YYYY-MM-DD');
    }, i = (_0x1bfefa, _0x345892 = 'YYYY-MM-DD\x20HH:mm:ss') => {
        if (!_0x1bfefa)
            return '';
        const _0x3a87f8 = new Date(_0x1bfefa), _0x3f4fec = _0x3a87f8['getFullYear'](), _0x37283b = String(_0x3a87f8['getMonth']() + 0x1)['padStart'](0x2, '0'), _0x43ab0c = String(_0x3a87f8['getDate']())['padStart'](0x2, '0'), _0x2b2a61 = String(_0x3a87f8['getHours']())['padStart'](0x2, '0'), _0x505301 = String(_0x3a87f8['getMinutes']())['padStart'](0x2, '0'), _0x4e3154 = String(_0x3a87f8['getSeconds']())['padStart'](0x2, '0');
        return _0x345892['replace']('YYYY', _0x3f4fec)['replace']('MM', _0x37283b)['replace']('DD', _0x43ab0c)['replace']('HH', _0x2b2a61)['replace']('mm', _0x505301)['replace']('ss', _0x4e3154);
    }, l = _0x54163e => _0x54163e ? new Date(_0x54163e)['toLocaleDateString']('zh-CN', {
        'year': 'numeric',
        'month': '2-digit',
        'day': '2-digit'
    }) : '', g = _0x38ba2a => {
        if (!_0x38ba2a)
            return '';
        const _0x378ec2 = new Date(), _0x26412a = new Date(_0x38ba2a);
        if (_0x378ec2['toDateString']() === _0x26412a['toDateString']())
            return i(_0x26412a, 'HH:mm');
        const _0xa993bd = new Date(_0x378ec2);
        return _0xa993bd['setDate'](_0x378ec2['getDate']() - 0x1), _0xa993bd['toDateString']() === _0x26412a['toDateString']() ? '昨天\x20' + i(_0x26412a, 'HH:mm') : _0x378ec2['getFullYear']() === _0x26412a['getFullYear']() ? i(_0x26412a, 'MM-DD\x20HH:mm') : i(_0x26412a, 'YYYY-MM-DD\x20HH:mm');
    }, m = _0xb0f70e => {
        if (!_0xb0f70e)
            return '';
        const _0x400497 = new Date(_0xb0f70e), _0x4a0c6a = new Date() - _0x400497;
        return _0x4a0c6a < 0xea60 ? '刚刚' : _0x4a0c6a < 0x36ee80 ? Math['floor'](_0x4a0c6a / 0xea60) + '分钟前' : _0x4a0c6a < 0x5265c00 ? Math['floor'](_0x4a0c6a / 0x36ee80) + '小时前' : _0x400497['toLocaleDateString']();
    };
export {
    D as a,
    l as b,
    m as c,
    i as f,
    g
};