const _0x4dffdb = (function () {
        let _0x3a1e68 = !![];
        return function (_0x2d1c2b, _0x5aca8d) {
            const _0x40288b = _0x3a1e68 ? function () {
                if (_0x5aca8d) {
                    const _0x4950ae = _0x5aca8d['apply'](_0x2d1c2b, arguments);
                    return _0x5aca8d = null, _0x4950ae;
                }
            } : function () {
            };
            return _0x3a1e68 = ![], _0x40288b;
        };
    }()), _0x9588d = _0x4dffdb(this, function () {
        let _0x3e1624;
        try {
            const _0x1cc529 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x3e1624 = _0x1cc529();
        } catch (_0x57c965) {
            _0x3e1624 = window;
        }
        const _0x54ef78 = _0x3e1624['console'] = _0x3e1624['console'] || {}, _0x24db2d = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x10502b = 0x0; _0x10502b < _0x24db2d['length']; _0x10502b++) {
            const _0x563bff = _0x4dffdb['constructor']['prototype']['bind'](_0x4dffdb), _0x369d57 = _0x24db2d[_0x10502b], _0x21a43b = _0x54ef78[_0x369d57] || _0x563bff;
            _0x563bff['__proto__'] = _0x4dffdb['bind'](_0x4dffdb), _0x563bff['toString'] = _0x21a43b['toString']['bind'](_0x21a43b), _0x54ef78[_0x369d57] = _0x563bff;
        }
    });
_0x9588d();
import {
    aH as _0x57d2d4,
    K as _0x551384
} from './Request-CHKnUlo5.js';
import {
    aB as _0x52db7e,
    aF as _0x17b54b,
    m as _0x5123b3
} from './index-54DmW9hq.js';
const i = {
        'prefix': Math['floor'](Math['random']() * 0x2710),
        'current': 0x0
    }, l = Symbol('elIdInjection'), E = () => _0x17b54b() ? _0x52db7e(l, i) : i, v = _0x30ca26 => {
        const _0x2b904d = E(), _0x4615ba = _0x57d2d4();
        return _0x551384(() => _0x5123b3(_0x30ca26) || _0x4615ba['value'] + '-id-' + _0x2b904d['prefix'] + '-' + _0x2b904d['current']++);
    }, p = 'a[href],button:not([disabled]),button:not([hidden]),:not([tabindex=\x22-1\x22]),input:not([disabled]),input:not([type=\x22hidden\x22]),select:not([disabled]),textarea:not([disabled])', a = _0x221f42 => typeof Element > 'u' ? !0x1 : _0x221f42 instanceof Element, I = _0x199555 => getComputedStyle(_0x199555)['position'] === 'fixed' ? !0x1 : _0x199555['offsetParent'] !== null, T = _0x1ebd68 => Array['from'](_0x1ebd68['querySelectorAll'](p))['filter'](_0x220451 => o(_0x220451) && I(_0x220451)), o = _0x53a0e3 => {
        if (_0x53a0e3['tabIndex'] > 0x0 || _0x53a0e3['tabIndex'] === 0x0 && _0x53a0e3['getAttribute']('tabIndex') !== null)
            return !0x0;
        if (_0x53a0e3['tabIndex'] < 0x0 || _0x53a0e3['hasAttribute']('disabled') || _0x53a0e3['getAttribute']('aria-disabled') === 'true')
            return !0x1;
        switch (_0x53a0e3['nodeName']) {
        case 'A':
            return !!_0x53a0e3['href'] && _0x53a0e3['rel'] !== 'ignore';
        case 'INPUT':
            return !(_0x53a0e3['type'] === 'hidden' || _0x53a0e3['type'] === 'file');
        case 'BUTTON':
        case 'SELECT':
        case 'TEXTAREA':
            return !0x0;
        default:
            return !0x1;
        }
    }, h = function (_0x259f43, _0x401271, ..._0x6b6157) {
        let _0x1b6d77;
        _0x401271['includes']('mouse') || _0x401271['includes']('click') ? _0x1b6d77 = 'MouseEvents' : _0x401271['includes']('key') ? _0x1b6d77 = 'KeyboardEvent' : _0x1b6d77 = 'HTMLEvents';
        const _0x1ed54d = document['createEvent'](_0x1b6d77);
        return _0x1ed54d['initEvent'](_0x401271, ..._0x6b6157), _0x259f43['dispatchEvent'](_0x1ed54d), _0x259f43;
    }, y = (_0x25e701, _0x555259) => {
        if (!_0x25e701 || !_0x25e701['focus'])
            return;
        let _0x198c5f = !0x1;
        a(_0x25e701) && !o(_0x25e701) && !_0x25e701['getAttribute']('tabindex') && (_0x25e701['setAttribute']('tabindex', '-1'), _0x198c5f = !0x0), _0x25e701['focus'](_0x555259), a(_0x25e701) && _0x198c5f && _0x25e701['removeAttribute']('tabindex');
    };
export {
    E as a,
    y as f,
    o as i,
    T as o,
    h as t,
    v as u
};