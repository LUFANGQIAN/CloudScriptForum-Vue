var _0x364644 = (function () {
        var _0x1ca467 = !![];
        return function (_0x5ce902, _0x2afa37) {
            var _0x4d2a26 = _0x1ca467 ? function () {
                if (_0x2afa37) {
                    var _0x1be31b = _0x2afa37['apply'](_0x5ce902, arguments);
                    return _0x2afa37 = null, _0x1be31b;
                }
            } : function () {
            };
            return _0x1ca467 = ![], _0x4d2a26;
        };
    }()), _0x3575b3 = _0x364644(this, function () {
        var _0x291242;
        try {
            var _0x4744a4 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x291242 = _0x4744a4();
        } catch (_0x25d741) {
            _0x291242 = window;
        }
        var _0x108fd8 = _0x291242['console'] = _0x291242['console'] || {}, _0x292b48 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (var _0x521dfd = 0x0; _0x521dfd < _0x292b48['length']; _0x521dfd++) {
            var _0x2d2a8b = _0x364644['constructor']['prototype']['bind'](_0x364644), _0x2fb7ef = _0x292b48[_0x521dfd], _0x3bc0e5 = _0x108fd8[_0x2fb7ef] || _0x2d2a8b;
            _0x2d2a8b['__proto__'] = _0x364644['bind'](_0x364644), _0x2d2a8b['toString'] = _0x3bc0e5['toString']['bind'](_0x3bc0e5), _0x108fd8[_0x2fb7ef] = _0x2d2a8b;
        }
    });
_0x3575b3();
import { r as _0x3c9eec } from './Request-CHKnUlo5.js';
function l(_0x50398f) {
    return _0x3c9eec({
        'url': '/album/get/' + _0x50398f,
        'method': 'get'
    });
}
function r(_0x5e07a) {
    return _0x3c9eec({
        'url': '/album/create',
        'method': 'post',
        'data': _0x5e07a
    });
}
function a(_0x241fd3) {
    return _0x3c9eec({
        'url': '/album/update',
        'method': 'put',
        'data': _0x241fd3
    });
}
function n(_0x529c68) {
    return _0x3c9eec({
        'url': '/album/delete/' + _0x529c68,
        'method': 'delete'
    });
}
function m() {
    return _0x3c9eec({
        'url': '/album/list',
        'method': 'get'
    });
}
function o() {
    return _0x3c9eec({
        'url': '/album/listAll',
        'method': 'get'
    });
}
function s(_0x33f767) {
    return _0x3c9eec({
        'url': '/album/changeShowStatus',
        'method': 'put',
        'data': _0x33f767
    });
}
function b(_0x5e4d1d) {
    return _0x3c9eec({
        'url': '/album/changeCover',
        'method': 'put',
        'data': _0x5e4d1d
    });
}
export {
    m as a,
    s as b,
    r as c,
    n as d,
    b as e,
    l as g,
    o as l,
    a as u
};