var _0x3ac779 = (function () {
        var _0xb81ff4 = !![];
        return function (_0x5f50c8, _0x2263a8) {
            var _0x111caf = _0xb81ff4 ? function () {
                if (_0x2263a8) {
                    var _0xd3cd47 = _0x2263a8['apply'](_0x5f50c8, arguments);
                    return _0x2263a8 = null, _0xd3cd47;
                }
            } : function () {
            };
            return _0xb81ff4 = ![], _0x111caf;
        };
    }()), _0x4d98d5 = _0x3ac779(this, function () {
        var _0x2aca33 = function () {
                var _0x4dbe9a;
                try {
                    _0x4dbe9a = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x2c56e2) {
                    _0x4dbe9a = window;
                }
                return _0x4dbe9a;
            }, _0x455e8c = _0x2aca33(), _0x2863e7 = _0x455e8c['console'] = _0x455e8c['console'] || {}, _0x333fbc = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (var _0x577e9d = 0x0; _0x577e9d < _0x333fbc['length']; _0x577e9d++) {
            var _0x13b088 = _0x3ac779['constructor']['prototype']['bind'](_0x3ac779), _0x3a1617 = _0x333fbc[_0x577e9d], _0x4e04f6 = _0x2863e7[_0x3a1617] || _0x13b088;
            _0x13b088['__proto__'] = _0x3ac779['bind'](_0x3ac779), _0x13b088['toString'] = _0x4e04f6['toString']['bind'](_0x4e04f6), _0x2863e7[_0x3a1617] = _0x13b088;
        }
    });
_0x4d98d5();
import { aa as _0x179b2d } from './Request-CHKnUlo5.js';
function e() {
    if (!arguments['length'])
        return [];
    var _0x535515 = arguments[0x0];
    return _0x179b2d(_0x535515) ? _0x535515 : [_0x535515];
}
export {
    e as c
};