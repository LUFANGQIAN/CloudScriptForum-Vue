const _0x487074 = (function () {
        let _0x25385a = !![];
        return function (_0x1bc4ca, _0x3edb5d) {
            const _0x4d8c5f = _0x25385a ? function () {
                if (_0x3edb5d) {
                    const _0x25e633 = _0x3edb5d['apply'](_0x1bc4ca, arguments);
                    return _0x3edb5d = null, _0x25e633;
                }
            } : function () {
            };
            return _0x25385a = ![], _0x4d8c5f;
        };
    }()), _0x72824a = _0x487074(this, function () {
        let _0xf4f5ea;
        try {
            const _0x47873f = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0xf4f5ea = _0x47873f();
        } catch (_0x4fd7a4) {
            _0xf4f5ea = window;
        }
        const _0x793c34 = _0xf4f5ea['console'] = _0xf4f5ea['console'] || {}, _0x26bc6d = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x7eb181 = 0x0; _0x7eb181 < _0x26bc6d['length']; _0x7eb181++) {
            const _0x1f01e0 = _0x487074['constructor']['prototype']['bind'](_0x487074), _0x27e0cd = _0x26bc6d[_0x7eb181], _0x53fb55 = _0x793c34[_0x27e0cd] || _0x1f01e0;
            _0x1f01e0['__proto__'] = _0x487074['bind'](_0x487074), _0x1f01e0['toString'] = _0x53fb55['toString']['bind'](_0x53fb55), _0x793c34[_0x27e0cd] = _0x1f01e0;
        }
    });
_0x72824a();
import { f as _0x59c687 } from './vnode-C3QoD07S.js';
import {
    a8 as _0x305097,
    X as _0xd0dfce,
    aK as _0x412794,
    aD as _0x504cc0,
    o as _0xdb579a,
    aN as _0x4a6922
} from './index-54DmW9hq.js';
const S = (_0x57f70b, _0x598d47, _0x569b8f) => _0x59c687(_0x57f70b['subTree'])['filter'](_0x5040f8 => {
        var _0x1de78f;
        return _0x4a6922(_0x5040f8) && ((_0x1de78f = _0x5040f8['type']) == null ? void 0x0 : _0x1de78f['name']) === _0x598d47 && !!_0x5040f8['component'];
    })['map'](_0x3aed36 => _0x3aed36['component']['uid'])['map'](_0x3ec3f9 => _0x569b8f[_0x3ec3f9])['filter'](_0x5c910e => !!_0x5c910e), B = (_0x1c9427, _0x51b575) => {
        const _0x482152 = _0x305097({}), _0x3d394e = _0x305097([]), _0x30c7e2 = new WeakMap(), _0x32f0fa = _0x228504 => {
                _0x482152['value'][_0x228504['uid']] = _0x228504, _0x504cc0(_0x482152), _0xdb579a(() => {
                    const _0xb27dbe = _0x228504['getVnode']()['el'], _0x2920b9 = _0xb27dbe['parentNode'];
                    if (!_0x30c7e2['has'](_0x2920b9)) {
                        _0x30c7e2['set'](_0x2920b9, []);
                        const _0x492501 = _0x2920b9['insertBefore']['bind'](_0x2920b9);
                        _0x2920b9['insertBefore'] = (_0x25ddd3, _0x4f46b8) => (_0x30c7e2['get'](_0x2920b9)['some'](_0x27aefd => _0x25ddd3 === _0x27aefd || _0x4f46b8 === _0x27aefd) && _0x504cc0(_0x482152), _0x492501(_0x25ddd3, _0x4f46b8));
                    }
                    _0x30c7e2['get'](_0x2920b9)['push'](_0xb27dbe);
                });
            }, _0xfe6888 = _0x4812f1 => {
                delete _0x482152['value'][_0x4812f1['uid']], _0x504cc0(_0x482152);
                const _0x2faf14 = _0x4812f1['getVnode']()['el'], _0x3a6dfe = _0x2faf14['parentNode'], _0x8bc463 = _0x30c7e2['get'](_0x3a6dfe), _0x345437 = _0x8bc463['indexOf'](_0x2faf14);
                _0x8bc463['splice'](_0x345437, 0x1);
            }, _0x25e1a0 = () => {
                _0x3d394e['value'] = S(_0x1c9427, _0x51b575, _0x482152['value']);
            }, _0x23e19c = _0xb67fae => _0xb67fae['render'](), _0xa2ca6a = _0xd0dfce({
                'setup'(_0x46d371, {slots: _0x348177}) {
                    return () => (_0x25e1a0(), _0x348177['default'] ? _0x412794(_0x23e19c, { 'render': _0x348177['default'] }) : null);
                }
            });
        return {
            'children': _0x3d394e,
            'addChild': _0x32f0fa,
            'removeChild': _0xfe6888,
            'ChildrenSorter': _0xa2ca6a
        };
    };
export {
    B as u
};