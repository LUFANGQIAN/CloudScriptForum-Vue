const _0x1a58f3 = (function () {
        let _0x2ae3ab = !![];
        return function (_0x1b6ed3, _0x351ce0) {
            const _0x254669 = _0x2ae3ab ? function () {
                if (_0x351ce0) {
                    const _0x145db6 = _0x351ce0['apply'](_0x1b6ed3, arguments);
                    return _0x351ce0 = null, _0x145db6;
                }
            } : function () {
            };
            return _0x2ae3ab = ![], _0x254669;
        };
    }()), _0x1d7285 = _0x1a58f3(this, function () {
        let _0x2326cc;
        try {
            const _0x162dbf = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x2326cc = _0x162dbf();
        } catch (_0x3343e2) {
            _0x2326cc = window;
        }
        const _0x28fa54 = _0x2326cc['console'] = _0x2326cc['console'] || {}, _0x521d1a = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x54b632 = 0x0; _0x54b632 < _0x521d1a['length']; _0x54b632++) {
            const _0x162502 = _0x1a58f3['constructor']['prototype']['bind'](_0x1a58f3), _0x6f8c2b = _0x521d1a[_0x54b632], _0x29ba5a = _0x28fa54[_0x6f8c2b] || _0x162502;
            _0x162502['__proto__'] = _0x1a58f3['bind'](_0x1a58f3), _0x162502['toString'] = _0x29ba5a['toString']['bind'](_0x29ba5a), _0x28fa54[_0x6f8c2b] = _0x162502;
        }
    });
_0x1d7285();
import {
    u as _0x55adfc,
    E as _0x328db4,
    a as _0x592af2,
    b as _0x5665ae,
    S as _0x20bbfb
} from './Request-CHKnUlo5.js';
import {
    E as _0x10154e,
    a as _0x201d20
} from './el-menu-item-KBCZyWt_.js';
import './el-tooltip-l0sNRNKZ.js';
import './el-scrollbar-BcrgDlEt.js';
import './el-button-D6wSrR74.js';
import {
    E as _0x4ce3d2,
    a as _0x413d8e,
    b as _0x41eb69
} from './el-dropdown-item-CXWV75Wk.js';
import { E as _0x2bba4f } from './el-divider-BC6KTyib.js';
import { E as _0x3263e0 } from './el-avatar-D7H8d9zq.js';
import { E as _0x39188e } from './el-input-D-8X7_j3.js';
import { E as _0x14ae2b } from './el-text-CbMl16cr.js';
import {
    _ as _0x457a9,
    s as _0x29d2de,
    r as _0x560e79,
    u as _0x181f5b,
    w as _0x2895ef,
    o as _0x307584,
    a as _0x43cd4c,
    c as _0x410e12,
    b as _0x32b62f,
    d as _0x359039,
    e as _0x3a5227,
    f as _0x4253ff,
    g as _0x175915,
    h as _0x47e21a,
    i as _0x19289a,
    j as _0x2acdd8,
    k as _0x5ed387,
    l as _0x103bdd,
    m as _0xd86638,
    n as _0xe94a,
    p as _0x108c70,
    t as _0x4a0be6,
    q as _0x1b92b5,
    v as _0x32f0b1,
    x as _0x2dd0d5,
    y as _0x325ec7,
    z as _0x13209f,
    A as _0x6b9266,
    B as _0x7e10f9,
    C as _0x5b5dfb,
    T as _0x558c3c,
    D as _0x39a5cb,
    F as _0x4ecdd0,
    E as _0x31e385
} from './index-54DmW9hq.js';
import {
    o as _0xc9a8a8,
    i as _0x47bf7b
} from './user-BDWxAMXB.js';
import {
    u as _0x3b3440,
    W as _0x4f1448
} from './WebSocketClient-CQU1CbB3.js';
import { g as _0x1a04f7 } from './privateMessage-Du2J5P4V.js';
import { g as _0x4742bc } from './notification-DP1N5YWr.js';
import './aria-DyaK1nXM.js';
import './index-DMxv2JmO.js';
import './index-CuE0nMtH.js';
import './vnode-C3QoD07S.js';
import './index-BLYrTdqd.js';
import './index-BOok6G7G.js';
import './focus-trap-Cbj9GFlW.js';
import './castArray-BGw1D6E-.js';
import './refs-mENLc3Ek.js';
import './event-BB_Ol6Sd.js';
import './index-ijNW1fhk.js';
const Pe = { 'class': 'right' }, Qe = {
        'key': 0x2,
        'class': 'user-info'
    }, Xe = { 'class': 'user-info-section' }, Ze = { 'class': 'user-name' }, et = { 'class': 'nickname' }, tt = { 'class': 'user-stats' }, ot = { 'class': 'stat-item' }, st = { 'class': 'stat-number' }, nt = { 'class': 'stat-item' }, at = { 'class': 'stat-number' }, lt = {
        '__name': 'Header',
        'setup'(_0x142ede) {
            const _0x5d1336 = _0x55adfc(), _0x294e5e = _0x3b3440(), {user: _0x445884} = _0x29d2de(_0x5d1336), _0x5e8a5d = _0x181f5b(), _0x2ba2e0 = _0x31e385(), _0x4db00c = _0x560e79('/'), _0x42d7f8 = _0x560e79(0x0);
            _0x5e8a5d['afterEach'](_0x1ba592 => {
                _0x1ba592['path']['startsWith']('/album') ? _0x4db00c['value'] = '/album' : _0x4db00c['value'] = _0x1ba592['path'];
            });
            const _0x10078b = _0x21a879 => {
                    _0x21a879 === '/creation' ? window['location']['href'] = '/creation' : _0x5e8a5d['push'](_0x21a879);
                }, _0x2bc309 = () => {
                    _0x5e8a5d['push']('/search');
                }, _0x24eff6 = () => {
                    _0x5e8a5d['push']('/message');
                }, _0x494692 = () => {
                    const _0x5bb53a = _0x5e8a5d['currentRoute']['value']['path'] === '/notification';
                    _0x5e8a5d['push']('/notification'), setTimeout(() => {
                        window['dispatchEvent'](new CustomEvent('refresh-notifications'));
                    }, _0x5bb53a ? 0x0 : 0x64);
                }, _0x8a3afa = () => {
                    _0x5e8a5d['push']('/login');
                }, _0x5e85eb = async () => {
                    if (_0x445884['value'])
                        try {
                            const _0x12aaf8 = await _0x1a04f7();
                            _0x294e5e['totalUnreadCount'] = _0x12aaf8['data']['data'] || 0x0;
                        } catch (_0x397e2a) {
                            console['error']('获取未读消息数失败:', _0x397e2a);
                        }
                }, _0x550f18 = async () => {
                    if (_0x445884['value'])
                        try {
                            const _0x5a3f78 = (await _0x4742bc())['data']['data'];
                            _0x42d7f8['value'] = _0x5a3f78['total'] || 0x0;
                        } catch (_0x2698bc) {
                            console['error']('获取未读通知数失败:', _0x2698bc);
                        }
                }, _0x100559 = _0x528ecf => {
                    _0x294e5e['updateConversation'](_0x528ecf['fromUserId'], {
                        'content': _0x528ecf['content'],
                        'createTime': _0x528ecf['createTime']
                    }, _0x528ecf['unreadCount'], {
                        'nickname': _0x528ecf['fromUserNickname'],
                        'avatar': _0x528ecf['fromUserAvatar']
                    });
                }, _0x42ceae = _0x2d4ca1 => {
                    _0x294e5e['updateConversationLastMessage'](_0x2d4ca1['fromUserId'], _0x2d4ca1['content'] || '撤回了一条消息');
                }, _0x4e78ea = _0x19b328 => {
                    _0x550f18();
                }, _0x288d2 = () => {
                    _0x445884['value'] && (_0x4f1448['isConnected']() || _0x4f1448['connect'](), _0x4f1448['off']('NEW_MESSAGE', _0x100559), _0x4f1448['off']('MESSAGE_REVOKED', _0x42ceae), _0x4f1448['off']('NEW_NOTIFICATION', _0x4e78ea), _0x4f1448['on']('NEW_MESSAGE', _0x100559), _0x4f1448['on']('MESSAGE_REVOKED', _0x42ceae), _0x4f1448['on']('NEW_NOTIFICATION', _0x4e78ea), _0x4f1448['off']('open', _0x5a31cd), _0x4f1448['on']('open', _0x5a31cd));
                }, _0x5a31cd = () => {
                    _0x4f1448['off']('NEW_MESSAGE', _0x100559), _0x4f1448['off']('MESSAGE_REVOKED', _0x42ceae), _0x4f1448['off']('NEW_NOTIFICATION', _0x4e78ea), _0x4f1448['on']('NEW_MESSAGE', _0x100559), _0x4f1448['on']('MESSAGE_REVOKED', _0x42ceae), _0x4f1448['on']('NEW_NOTIFICATION', _0x4e78ea);
                };
            ((() => {
                const _0x3dca88 = _0x2ba2e0['query']['user_name'], _0x510a69 = _0x2ba2e0['query']['access_token'], _0x9de7bb = _0x2ba2e0['query']['login_type'];
                _0x3dca88 && _0x510a69 && _0xc9a8a8({
                    'type': _0x9de7bb,
                    'username': _0x3dca88,
                    'password': _0x510a69
                })['then'](async _0x3dfbce => {
                    await _0x5e8a5d['replace']({ 'query': {} }), _0x5665ae['success']('登录成功'), _0x20bbfb(_0x3dfbce['data']['data']), _0x47bf7b()['then'](_0x26326f => {
                        _0x5d1336['user'] = _0x26326f['data']['data'];
                    });
                });
            })());
            const _0x39c3a9 = async () => {
                    const _0x19f7bf = await _0x47bf7b();
                    _0x445884['value'] = _0x19f7bf['data']['data'];
                }, _0x4c2d89 = () => {
                    _0x5d1336['clearUser']();
                }, _0x5c699e = () => {
                    var _0x2912b7;
                    (_0x2912b7 = _0x445884['value']) != null && _0x2912b7['id'] && _0x5e8a5d['push']('/user/' + _0x445884['value']['id']);
                }, _0x1ecf98 = () => {
                    _0x5e8a5d['push']('/setting');
                }, _0x355e39 = _0x560e79(!0x0), _0x55958e = _0x560e79(0x0), _0x456cb0 = () => {
                    const _0x39e705 = window['scrollY'];
                    _0x39e705 > _0x55958e['value'] && _0x39e705 > 0x64 ? _0x355e39['value'] = !0x1 : _0x39e705 < _0x55958e['value'] && (_0x355e39['value'] = !0x0), _0x55958e['value'] = _0x39e705;
                }, _0x171640 = _0x560e79(!0x1), _0x1067d9 = () => {
                    _0x171640['value'] = !_0x171640['value'];
                }, _0x380966 = _0x1e4ad9 => {
                    _0x171640['value'] = !0x1, _0x10078b(_0x1e4ad9);
                };
            _0x2895ef(() => _0x445884['value'], _0x12c7f1 => {
                _0x12c7f1 ? (_0x5e85eb(), _0x550f18(), _0x288d2()) : (_0x4f1448['close'](), _0x4f1448['off']('NEW_MESSAGE', _0x100559), _0x4f1448['off']('MESSAGE_REVOKED', _0x42ceae), _0x4f1448['off']('NEW_NOTIFICATION', _0x4e78ea), _0x4f1448['off']('open', _0x5a31cd), _0x42d7f8['value'] = 0x0);
            }, { 'immediate': !0x0 });
            const _0x2d4dd4 = () => {
                _0x550f18();
            };
            _0x307584(() => {
                window['addEventListener']('scroll', _0x456cb0), window['addEventListener']('notification-read', _0x2d4dd4), _0x445884['value'] && _0x39c3a9();
            }), _0x43cd4c(() => {
                window['removeEventListener']('scroll', _0x456cb0), window['removeEventListener']('notification-read', _0x2d4dd4), _0x4f1448['off']('NEW_MESSAGE', _0x100559), _0x4f1448['off']('MESSAGE_REVOKED', _0x42ceae), _0x4f1448['off']('NEW_NOTIFICATION', _0x4e78ea), _0x4f1448['off']('open', _0x5a31cd);
            });
            const _0x319124 = _0x560e79(''), _0x3daede = () => {
                }, _0x5f3cf3 = () => {
                };
            return (_0x40e97f, _0x3bded0) => {
                const _0x4c9fb9 = _0x47e21a, _0x2b29ae = _0x14ae2b, _0x30ec17 = _0x19289a('router-link'), _0x2cbc47 = _0x10154e, _0x202c88 = _0x39188e, _0x56d9b6 = _0x592af2, _0x5dc1f0 = _0x328db4, _0x2c509a = _0x3263e0, _0x259353 = _0x2bba4f, _0x323a54 = _0x41eb69, _0x888bd6 = _0x413d8e, _0x1b8c73 = _0x4ce3d2, _0x5c50fd = _0x201d20;
                return _0x32b62f(), _0x410e12(_0x4ecdd0, null, [
                    _0x359039(_0x5c50fd, {
                        'default-active': _0x4db00c['value'],
                        'router': '',
                        'class': _0x13209f([
                            'pc-menu',
                            { 'hidden': !_0x355e39['value'] }
                        ]),
                        'mode': 'horizontal',
                        'onSelect': _0x10078b,
                        'ellipsis': !0x1,
                        'text-color': '#000',
                        'active-text-color': '#f59e0b'
                    }, {
                        'default': _0x4253ff(() => [
                            _0x175915('div', {
                                'class': 'mobile-menu-button',
                                'onClick': _0x1067d9
                            }, [_0x359039(_0x4c9fb9, {
                                    'name': 'menu',
                                    'width': '50px',
                                    'height': '50px',
                                    'cursor': 'pointer'
                                })]),
                            _0x359039(_0x30ec17, {
                                'class': 'logo',
                                'to': '/'
                            }, {
                                'default': _0x4253ff(() => [_0x359039(_0x2b29ae, {
                                        'size': 'large',
                                        'class': 'logo-text'
                                    }, {
                                        'default': _0x4253ff(() => _0x3bded0[0x2] || (_0x3bded0[0x2] = [_0x2acdd8('CloudScrpit')])),
                                        '_': 0x1,
                                        '__': [0x2]
                                    })]),
                                '_': 0x1
                            }),
                            _0x359039(_0x2cbc47, {
                                'index': '/',
                                'class': 'menu-item'
                            }, {
                                'default': _0x4253ff(() => _0x3bded0[0x3] || (_0x3bded0[0x3] = [_0x175915('span', { 'class': 'menu-text' }, '主页', -0x1)])),
                                '_': 0x1,
                                '__': [0x3]
                            }),
                            _0x359039(_0x2cbc47, {
                                'index': '/article',
                                'class': 'menu-item'
                            }, {
                                'default': _0x4253ff(() => _0x3bded0[0x4] || (_0x3bded0[0x4] = [_0x175915('span', { 'class': 'menu-text' }, '热门', -0x1)])),
                                '_': 0x1,
                                '__': [0x4]
                            }),
                            _0x359039(_0x2cbc47, {
                                'index': '/link',
                                'class': 'menu-item'
                            }, {
                                'default': _0x4253ff(() => _0x3bded0[0x5] || (_0x3bded0[0x5] = [_0x175915('span', { 'class': 'menu-text' }, '友联', -0x1)])),
                                '_': 0x1,
                                '__': [0x5]
                            }),
                            _0x359039(_0x2cbc47, {
                                'index': '/about',
                                'class': 'menu-item'
                            }, {
                                'default': _0x4253ff(() => _0x3bded0[0x6] || (_0x3bded0[0x6] = [_0x175915('span', { 'class': 'menu-text' }, '关于', -0x1)])),
                                '_': 0x1,
                                '__': [0x6]
                            }),
                            _0x359039(_0x2cbc47, {
                                'index': '/creation',
                                'class': 'menu-item'
                            }, {
                                'default': _0x4253ff(() => _0x3bded0[0x7] || (_0x3bded0[0x7] = [_0x175915('span', { 'class': 'menu-text' }, '创作中心', -0x1)])),
                                '_': 0x1,
                                '__': [0x7]
                            }),
                            _0x175915('div', Pe, [
                                _0x175915('div', {
                                    'class': 'search',
                                    'onClick': _0x2bc309
                                }, [_0x359039(_0x202c88, {
                                        'modelValue': _0x319124['value'],
                                        'onUpdate:modelValue': _0x3bded0[0x0] || (_0x3bded0[0x0] = _0x39c319 => _0x319124['value'] = _0x39c319),
                                        'placeholder': '搜索...',
                                        'prefix-icon': 'Search',
                                        'clearable': '',
                                        'onKeyup': _0x103bdd(_0x2bc309, ['enter']),
                                        'onFocus': _0x3daede,
                                        'onBlur': _0x5f3cf3,
                                        'class': 'search-input'
                                    }, null, 0x8, ['modelValue'])]),
                                _0xd86638(_0x445884) ? (_0x32b62f(), _0x410e12('div', {
                                    'key': 0x0,
                                    'class': 'message-icon',
                                    'onClick': _0x24eff6
                                }, [_0x359039(_0x5dc1f0, {
                                        'value': _0xd86638(_0x294e5e)['totalUnreadCount'],
                                        'max': 0x63,
                                        'hidden': _0xd86638(_0x294e5e)['totalUnreadCount'] === 0x0
                                    }, {
                                        'default': _0x4253ff(() => [_0x359039(_0x56d9b6, {
                                                'size': '25px',
                                                'color': 'var(--el-text-color-primary)'
                                            }, {
                                                'default': _0x4253ff(() => [_0x359039(_0xd86638(_0xe94a))]),
                                                '_': 0x1
                                            })]),
                                        '_': 0x1
                                    }, 0x8, [
                                        'value',
                                        'hidden'
                                    ])])) : _0x5ed387('', !0x0),
                                _0xd86638(_0x445884) ? (_0x32b62f(), _0x410e12('div', {
                                    'key': 0x1,
                                    'class': 'notification-icon',
                                    'onClick': _0x494692
                                }, [_0x359039(_0x5dc1f0, {
                                        'value': _0x42d7f8['value'],
                                        'max': 0x63,
                                        'hidden': _0x42d7f8['value'] === 0x0
                                    }, {
                                        'default': _0x4253ff(() => [_0x359039(_0x56d9b6, {
                                                'size': '25px',
                                                'color': 'var(--el-text-color-primary)'
                                            }, {
                                                'default': _0x4253ff(() => [_0x359039(_0xd86638(_0x108c70))]),
                                                '_': 0x1
                                            })]),
                                        '_': 0x1
                                    }, 0x8, [
                                        'value',
                                        'hidden'
                                    ])])) : _0x5ed387('', !0x0),
                                _0xd86638(_0x445884) ? (_0x32b62f(), _0x410e12('div', Qe, [
                                    _0x359039(_0x2b29ae, {
                                        'size': 'large',
                                        'class': 'nickname',
                                        'onClick': _0x5c699e
                                    }, {
                                        'default': _0x4253ff(() => [_0x2acdd8(_0x4a0be6(_0xd86638(_0x445884)['nickname']), 0x1)]),
                                        '_': 0x1
                                    }),
                                    _0x359039(_0x1b8c73, { 'placement': 'bottom-end' }, {
                                        'dropdown': _0x4253ff(() => [_0x359039(_0x888bd6, { 'class': 'user-dropdown-menu' }, {
                                                'default': _0x4253ff(() => [
                                                    _0x175915('div', Xe, [
                                                        _0x175915('div', Ze, [_0x175915('span', et, _0x4a0be6(_0xd86638(_0x445884)['nickname']), 0x1)]),
                                                        _0x175915('div', tt, [
                                                            _0x175915('div', ot, [
                                                                _0x175915('span', st, _0x4a0be6(_0xd86638(_0x445884)['fansCount'] || 0x0), 0x1),
                                                                _0x3bded0[0x8] || (_0x3bded0[0x8] = _0x175915('span', { 'class': 'stat-label' }, '粉丝', -0x1))
                                                            ]),
                                                            _0x175915('div', nt, [
                                                                _0x175915('span', at, _0x4a0be6(_0xd86638(_0x445884)['followCount'] || 0x0), 0x1),
                                                                _0x3bded0[0x9] || (_0x3bded0[0x9] = _0x175915('span', { 'class': 'stat-label' }, '关注', -0x1))
                                                            ])
                                                        ])
                                                    ]),
                                                    _0x359039(_0x259353, { 'style': { 'margin': '12px\x200' } }),
                                                    _0x359039(_0x323a54, {
                                                        'onClick': _0x5c699e,
                                                        'class': 'action-item'
                                                    }, {
                                                        'default': _0x4253ff(() => [
                                                            _0x359039(_0x56d9b6, null, {
                                                                'default': _0x4253ff(() => [_0x359039(_0xd86638(_0x32f0b1))]),
                                                                '_': 0x1
                                                            }),
                                                            _0x3bded0[0xa] || (_0x3bded0[0xa] = _0x175915('span', null, '个人主页', -0x1))
                                                        ]),
                                                        '_': 0x1,
                                                        '__': [0xa]
                                                    }),
                                                    _0x359039(_0x323a54, {
                                                        'onClick': _0x1ecf98,
                                                        'class': 'action-item'
                                                    }, {
                                                        'default': _0x4253ff(() => [
                                                            _0x359039(_0x56d9b6, null, {
                                                                'default': _0x4253ff(() => [_0x359039(_0xd86638(_0x2dd0d5))]),
                                                                '_': 0x1
                                                            }),
                                                            _0x3bded0[0xb] || (_0x3bded0[0xb] = _0x175915('span', null, '个人设置', -0x1))
                                                        ]),
                                                        '_': 0x1,
                                                        '__': [0xb]
                                                    }),
                                                    _0x359039(_0x323a54, {
                                                        'onClick': _0x4c2d89,
                                                        'class': 'action-item'
                                                    }, {
                                                        'default': _0x4253ff(() => [
                                                            _0x359039(_0x56d9b6, null, {
                                                                'default': _0x4253ff(() => [_0x359039(_0xd86638(_0x325ec7))]),
                                                                '_': 0x1
                                                            }),
                                                            _0x3bded0[0xc] || (_0x3bded0[0xc] = _0x175915('span', null, '退出登录', -0x1))
                                                        ]),
                                                        '_': 0x1,
                                                        '__': [0xc]
                                                    })
                                                ]),
                                                '_': 0x1
                                            })]),
                                        'default': _0x4253ff(() => [_0xd86638(_0x445884)['avatar'] ? (_0x32b62f(), _0x3a5227(_0x2c509a, {
                                                'key': 0x0,
                                                'style': { 'cursor': 'pointer' },
                                                'size': 0x1f,
                                                'src': _0xd86638(_0x445884)['avatar']
                                            }, null, 0x8, ['src'])) : (_0x32b62f(), _0x3a5227(_0x2c509a, {
                                                'key': 0x1,
                                                'style': { 'cursor': 'pointer' },
                                                'size': 0x1f,
                                                'icon': _0xd86638(_0x1b92b5)
                                            }, null, 0x8, ['icon']))]),
                                        '_': 0x1
                                    })
                                ])) : (_0x32b62f(), _0x410e12('div', {
                                    'key': 0x3,
                                    'class': 'login',
                                    'onClick': _0x8a3afa
                                }, '登录'))
                            ])
                        ]),
                        '_': 0x1
                    }, 0x8, [
                        'default-active',
                        'class'
                    ]),
                    (_0x32b62f(), _0x3a5227(_0x39a5cb, { 'to': 'body' }, [_0x359039(_0x558c3c, { 'name': 'slide-fade' }, {
                            'default': _0x4253ff(() => [_0x6b9266(_0x175915('div', {
                                    'class': 'mobile-menu-overlay',
                                    'onClick': _0x380966
                                }, [_0x359039(_0x5c50fd, {
                                        'class': 'mobile-menu',
                                        'router': '',
                                        'onClick': _0x3bded0[0x1] || (_0x3bded0[0x1] = _0x5b5dfb(() => {
                                        }, ['stop'])),
                                        'onSelect': _0x380966
                                    }, {
                                        'default': _0x4253ff(() => [
                                            _0x359039(_0x2cbc47, {
                                                'index': '/',
                                                'class': 'menu-item'
                                            }, {
                                                'default': _0x4253ff(() => _0x3bded0[0xd] || (_0x3bded0[0xd] = [_0x175915('span', { 'class': 'menu-text' }, '主页', -0x1)])),
                                                '_': 0x1,
                                                '__': [0xd]
                                            }),
                                            _0x359039(_0x2cbc47, {
                                                'index': '/article',
                                                'class': 'menu-item'
                                            }, {
                                                'default': _0x4253ff(() => _0x3bded0[0xe] || (_0x3bded0[0xe] = [_0x175915('span', { 'class': 'menu-text' }, '发现', -0x1)])),
                                                '_': 0x1,
                                                '__': [0xe]
                                            }),
                                            _0x359039(_0x2cbc47, {
                                                'index': '/album',
                                                'class': 'menu-item'
                                            }, {
                                                'default': _0x4253ff(() => _0x3bded0[0xf] || (_0x3bded0[0xf] = [_0x175915('span', { 'class': 'menu-text' }, '社区', -0x1)])),
                                                '_': 0x1,
                                                '__': [0xf]
                                            }),
                                            _0x359039(_0x2cbc47, {
                                                'index': '/link',
                                                'class': 'menu-item'
                                            }, {
                                                'default': _0x4253ff(() => _0x3bded0[0x10] || (_0x3bded0[0x10] = [_0x175915('span', { 'class': 'menu-text' }, '帮助', -0x1)])),
                                                '_': 0x1,
                                                '__': [0x10]
                                            }),
                                            _0x359039(_0x2cbc47, {
                                                'index': '/creation',
                                                'class': 'menu-item'
                                            }, {
                                                'default': _0x4253ff(() => _0x3bded0[0x11] || (_0x3bded0[0x11] = [_0x175915('span', { 'class': 'menu-text' }, '创作中心', -0x1)])),
                                                '_': 0x1,
                                                '__': [0x11]
                                            })
                                        ]),
                                        '_': 0x1
                                    })], 0x200), [[
                                        _0x7e10f9,
                                        _0x171640['value']
                                    ]])]),
                            '_': 0x1
                        })]))
                ], 0x40);
            };
        }
    }, it = _0x457a9(lt, [[
            '__scopeId',
            'data-v-dafba5bb'
        ]]), rt = {
        '__name': 'index',
        'setup'(_0x35ee7d) {
            return (_0x2b7b10, _0x5338b0) => {
                const _0x31b23d = _0x19289a('router-view');
                return _0x32b62f(), _0x410e12(_0x4ecdd0, null, [
                    _0x359039(it),
                    _0x359039(_0x31b23d, { 'class': 'router-view' })
                ], 0x40);
            };
        }
    }, Rt = _0x457a9(rt, [[
            '__scopeId',
            'data-v-825507a8'
        ]]);
export {
    Rt as default
};