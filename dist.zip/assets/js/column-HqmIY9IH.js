const _0x1432ed = (function () {
        let _0x12b653 = !![];
        return function (_0x3249cc, _0x1eaaa0) {
            const _0x14b507 = _0x12b653 ? function () {
                if (_0x1eaaa0) {
                    const _0x3a9f21 = _0x1eaaa0['apply'](_0x3249cc, arguments);
                    return _0x1eaaa0 = null, _0x3a9f21;
                }
            } : function () {
            };
            return _0x12b653 = ![], _0x14b507;
        };
    }()), _0x1892df = _0x1432ed(this, function () {
        const _0x23e833 = function () {
                let _0x72de2a;
                try {
                    _0x72de2a = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x585ebd) {
                    _0x72de2a = window;
                }
                return _0x72de2a;
            }, _0x227f3e = _0x23e833(), _0x4fe0ac = _0x227f3e['console'] = _0x227f3e['console'] || {}, _0x237cc6 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x2eed63 = 0x0; _0x2eed63 < _0x237cc6['length']; _0x2eed63++) {
            const _0x463217 = _0x1432ed['constructor']['prototype']['bind'](_0x1432ed), _0x18178f = _0x237cc6[_0x2eed63], _0x4acc21 = _0x4fe0ac[_0x18178f] || _0x463217;
            _0x463217['__proto__'] = _0x1432ed['bind'](_0x1432ed), _0x463217['toString'] = _0x4acc21['toString']['bind'](_0x4acc21), _0x4fe0ac[_0x18178f] = _0x463217;
        }
    });
_0x1892df();
import { r as _0x3a339c } from './Request-CHKnUlo5.js';
const l = () => _0x3a339c({
        'url': '/column/list',
        'method': 'get'
    }), n = _0x188ca0 => _0x3a339c({
        'url': '/column/add',
        'method': 'post',
        'data': _0x188ca0
    }), m = (_0x3f9f61, _0x4ba61c, _0x4d5459) => _0x3a339c({
        'url': '/column/manage/list',
        'method': 'post',
        'params': {
            'pageNum': _0x3f9f61,
            'pageSize': _0x4ba61c
        },
        'data': _0x4d5459
    }), s = _0x38b349 => _0x3a339c({
        'url': '/column/update',
        'method': 'put',
        'data': _0x38b349
    }), a = _0x3df560 => _0x3a339c({
        'url': '/column/' + _0x3df560,
        'method': 'delete'
    }), c = _0x527333 => _0x3a339c({
        'url': '/column/detail/' + _0x527333,
        'method': 'get'
    }), d = (_0x11b121, _0x4145d2) => _0x3a339c({
        'url': '/column/' + _0x11b121 + '/article/sort',
        'method': 'put',
        'data': _0x4145d2
    }), i = (_0x565953, _0xb93796) => _0x3a339c({
        'url': '/column/' + _0x565953 + '/article/' + _0xb93796,
        'method': 'delete'
    }), p = (_0x43de21, _0x39a911, _0x4667ad) => _0x3a339c({
        'url': '/column/list/' + _0x4667ad,
        'method': 'get',
        'params': {
            'pageNum': _0x43de21,
            'pageSize': _0x39a911
        }
    });
export {
    c as a,
    m as b,
    n as c,
    a as d,
    d as e,
    l as f,
    p as g,
    i as r,
    s as u
};