var _0x4ad984 = (function () {
        var _0x46cb0e = !![];
        return function (_0x260979, _0x50eea6) {
            var _0x468236 = _0x46cb0e ? function () {
                if (_0x50eea6) {
                    var _0xe714a1 = _0x50eea6['apply'](_0x260979, arguments);
                    return _0x50eea6 = null, _0xe714a1;
                }
            } : function () {
            };
            return _0x46cb0e = ![], _0x468236;
        };
    }()), _0x1f9b74 = _0x4ad984(this, function () {
        var _0x488f42;
        try {
            var _0x5e2249 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x488f42 = _0x5e2249();
        } catch (_0x28d49b) {
            _0x488f42 = window;
        }
        var _0x2880b4 = _0x488f42['console'] = _0x488f42['console'] || {}, _0x548cdc = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (var _0x44837a = 0x0; _0x44837a < _0x548cdc['length']; _0x44837a++) {
            var _0x57d195 = _0x4ad984['constructor']['prototype']['bind'](_0x4ad984), _0x458be3 = _0x548cdc[_0x44837a], _0x16cad9 = _0x2880b4[_0x458be3] || _0x57d195;
            _0x57d195['__proto__'] = _0x4ad984['bind'](_0x4ad984), _0x57d195['toString'] = _0x16cad9['toString']['bind'](_0x16cad9), _0x2880b4[_0x458be3] = _0x57d195;
        }
    });
_0x1f9b74();
import { r as _0x42a0c1 } from './Request-CHKnUlo5.js';
function s(_0x2d34bf) {
    return _0x42a0c1({
        'url': '/follow/toggle/' + _0x2d34bf,
        'method': 'post'
    });
}
function n(_0xe0c986, _0x51fc1c) {
    return _0x42a0c1({
        'url': '/follow/isFollowing',
        'method': 'get',
        'params': {
            'followerId': _0xe0c986,
            'followedId': _0x51fc1c
        }
    });
}
function a(_0x15c268, _0x36bbf7 = 0x1, _0x1b1226 = 0xa) {
    return _0x42a0c1({
        'url': '/follow/followList/' + _0x15c268,
        'method': 'get',
        'params': {
            'pageNum': _0x36bbf7,
            'pageSize': _0x1b1226
        }
    });
}
function i(_0x1206e3, _0x4540c4 = 0x1, _0x1e0803 = 0xa) {
    return _0x42a0c1({
        'url': '/follow/fansList/' + _0x1206e3,
        'method': 'get',
        'params': {
            'pageNum': _0x4540c4,
            'pageSize': _0x1e0803
        }
    });
}
export {
    i as a,
    a as g,
    n as i,
    s as t
};