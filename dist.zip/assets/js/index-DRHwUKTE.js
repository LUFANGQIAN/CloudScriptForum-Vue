const _0x1b989e = (function () {
        let _0x1f87b8 = !![];
        return function (_0x5c4862, _0x39e42f) {
            const _0x19cf7e = _0x1f87b8 ? function () {
                if (_0x39e42f) {
                    const _0x15d2fb = _0x39e42f['apply'](_0x5c4862, arguments);
                    return _0x39e42f = null, _0x15d2fb;
                }
            } : function () {
            };
            return _0x1f87b8 = ![], _0x19cf7e;
        };
    }()), _0x45964f = _0x1b989e(this, function () {
        let _0x95f862;
        try {
            const _0x26a1d6 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x95f862 = _0x26a1d6();
        } catch (_0x221efc) {
            _0x95f862 = window;
        }
        const _0x39faf7 = _0x95f862['console'] = _0x95f862['console'] || {}, _0x40f140 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x369c19 = 0x0; _0x369c19 < _0x40f140['length']; _0x369c19++) {
            const _0x4c1647 = _0x1b989e['constructor']['prototype']['bind'](_0x1b989e), _0x114d06 = _0x40f140[_0x369c19], _0x32b59b = _0x39faf7[_0x114d06] || _0x4c1647;
            _0x4c1647['__proto__'] = _0x1b989e['bind'](_0x1b989e), _0x4c1647['toString'] = _0x32b59b['toString']['bind'](_0x32b59b), _0x39faf7[_0x114d06] = _0x4c1647;
        }
    });
_0x45964f();
import {
    _ as _0x3379cc,
    e,
    f as _0x400348,
    i as _0x531745,
    b as _0x34710d,
    d as _0x4d004a,
    T as _0x1b318e,
    ak as _0x4cee5d
} from './index-54DmW9hq.js';
const l = {};
function d(_0x41ecc6, _0x47dc77) {
    const _0x190c7b = _0x531745('router-view');
    return _0x34710d(), e(_0x190c7b, null, {
        'default': _0x400348(({Component: _0x3df851}) => [_0x4d004a(_0x1b318e, {
                'name': 'scale',
                'mode': 'out-in'
            }, {
                'default': _0x400348(() => [(_0x34710d(), e(_0x4cee5d(_0x3df851)))]),
                '_': 0x2
            }, 0x400)]),
        '_': 0x1
    });
}
const p = _0x3379cc(l, [[
        'render',
        d
    ]]);
export {
    p as default
};