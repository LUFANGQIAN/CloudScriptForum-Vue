var _0x5e8097 = (function () {
        var _0x246b21 = !![];
        return function (_0x2bfd0e, _0x1d1309) {
            var _0x8d209d = _0x246b21 ? function () {
                if (_0x1d1309) {
                    var _0xaf69b1 = _0x1d1309['apply'](_0x2bfd0e, arguments);
                    return _0x1d1309 = null, _0xaf69b1;
                }
            } : function () {
            };
            return _0x246b21 = ![], _0x8d209d;
        };
    }()), _0x2f210e = _0x5e8097(this, function () {
        var _0x2d0dde = function () {
                var _0x4d50b9;
                try {
                    _0x4d50b9 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x51b483) {
                    _0x4d50b9 = window;
                }
                return _0x4d50b9;
            }, _0xf3eceb = _0x2d0dde(), _0x3946b7 = _0xf3eceb['console'] = _0xf3eceb['console'] || {}, _0x2b183b = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (var _0x169bd1 = 0x0; _0x169bd1 < _0x2b183b['length']; _0x169bd1++) {
            var _0x47fb9e = _0x5e8097['constructor']['prototype']['bind'](_0x5e8097), _0x79b9b = _0x2b183b[_0x169bd1], _0x1c532b = _0x3946b7[_0x79b9b] || _0x47fb9e;
            _0x47fb9e['__proto__'] = _0x5e8097['bind'](_0x5e8097), _0x47fb9e['toString'] = _0x1c532b['toString']['bind'](_0x1c532b), _0x3946b7[_0x79b9b] = _0x47fb9e;
        }
    });
_0x2f210e();
import { r as _0x552bea } from './Request-CHKnUlo5.js';
function r() {
    return _0x552bea({
        'url': '/conversation/list',
        'method': 'get'
    });
}
function n(_0x1b0ba1) {
    return _0x552bea({
        'url': '/conversation/' + _0x1b0ba1,
        'method': 'delete'
    });
}
export {
    n as d,
    r as g
};