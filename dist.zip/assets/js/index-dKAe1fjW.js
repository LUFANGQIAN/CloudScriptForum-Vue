const _0x15afc3 = (function () {
        let _0x5b330e = !![];
        return function (_0x12aa93, _0xcb6b70) {
            const _0x1f2359 = _0x5b330e ? function () {
                if (_0xcb6b70) {
                    const _0x4fba6a = _0xcb6b70['apply'](_0x12aa93, arguments);
                    return _0xcb6b70 = null, _0x4fba6a;
                }
            } : function () {
            };
            return _0x5b330e = ![], _0x1f2359;
        };
    }()), _0x3f6ac8 = _0x15afc3(this, function () {
        let _0x4b5b3d;
        try {
            const _0xea2952 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x4b5b3d = _0xea2952();
        } catch (_0x6dd19e) {
            _0x4b5b3d = window;
        }
        const _0x5b0e52 = _0x4b5b3d['console'] = _0x4b5b3d['console'] || {}, _0x3a784d = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x157956 = 0x0; _0x157956 < _0x3a784d['length']; _0x157956++) {
            const _0x6f071c = _0x15afc3['constructor']['prototype']['bind'](_0x15afc3), _0x4d3322 = _0x3a784d[_0x157956], _0x5ac19f = _0x5b0e52[_0x4d3322] || _0x6f071c;
            _0x6f071c['__proto__'] = _0x15afc3['bind'](_0x15afc3), _0x6f071c['toString'] = _0x5ac19f['toString']['bind'](_0x5ac19f), _0x5b0e52[_0x4d3322] = _0x6f071c;
        }
    });
_0x3f6ac8();
import {
    _ as _0x4e6c2a,
    r as _0x658a94,
    o as _0xae5033,
    c as _0x1f43e5,
    g as _0x5c7b1d,
    d as _0x477b2d,
    f as _0x5c0e89,
    F as _0x385b2f,
    G as _0x5f53c2,
    j as _0x3a3ee3,
    i as _0x590d70,
    ah as _0x143069,
    t as _0x4c76b6,
    u as _0x2028ab,
    b as _0x26421e,
    m as _0x34f2a5,
    O as _0x1db59e,
    P as _0x1cc4ee,
    h as _0x25d0e2,
    M as _0x54a296,
    R as _0x36c0b6,
    ai as _0x2a2734
} from './index-54DmW9hq.js';
import {
    a as _0x3b18da,
    b as _0x118aa5
} from './Request-CHKnUlo5.js';
import { E as _0x253470 } from './el-image-viewer-DAjDHmiI.js';
import { E as _0x24679a } from './el-empty-o9RgIX3C.js';
import {
    E as _0x19dc93,
    a as _0x520fec
} from './el-skeleton-item-BG_lS1DD.js';
import { g as _0x3672d7 } from './article-IrYQ22on.js';
import './focus-trap-Cbj9GFlW.js';
import './aria-DyaK1nXM.js';
import './index-BLYrTdqd.js';
import './toNumber-DGNxa_rg.js';
import './index-ijNW1fhk.js';
import './scroll-DDB7nuLj.js';
const J = { 'class': 'home-container' }, K = { 'class': 'container' }, Q = { 'class': 'content-grid' }, W = { 'class': 'latest-articles' }, X = { 'class': 'articles-wrapper' }, tt = {
        'key': 0x0,
        'class': 'loading-container'
    }, st = { 'class': 'article-skeleton' }, et = { 'class': 'skeleton-content' }, ot = { 'class': 'skeleton-meta' }, at = {
        'key': 0x1,
        'class': 'empty-state'
    }, lt = {
        'key': 0x2,
        'class': 'article-list'
    }, nt = ['onClick'], it = { 'class': 'image-placeholder' }, rt = { 'class': 'image-error' }, ct = { 'class': 'article-content' }, dt = { 'class': 'article-meta' }, _t = { 'class': 'date' }, ut = { 'class': 'article-description' }, pt = { 'class': 'article-stats' }, vt = { 'class': 'like-count' }, mt = { 'class': 'read-count' }, ft = { 'class': 'collect-count' }, ht = { 'class': 'footer' }, gt = { 'class': 'container' }, kt = { 'class': 'footer-content' }, xt = { 'class': 'footer-links' }, yt = { 'class': 'footer-column' }, wt = { 'class': 'column-title' }, bt = { 'class': 'links-list' }, Ct = { 'class': 'footer-bottom' }, Et = { 'class': 'footer-bottom-content' }, St = { 'class': 'footer-left' }, At = { 'class': 'copyright' }, Vt = {
        '__name': 'index',
        'setup'(_0x27d023) {
            const _0xb3bf30 = _0x2028ab(), _0x260921 = _0x658a94([]), _0x18dd59 = _0x658a94(!0x1), _0x2522d7 = _0x658a94(new Date()['getFullYear']()), _0x3fd794 = _0x658a94(null), _0x1f555c = async (_0x204ad2 = !0x1) => {
                    if (!(!_0x204ad2 || _0x260921['value']['length'] > 0x0))
                        try {
                            _0x18dd59['value'] = !0x0;
                            const _0x5a5e64 = await _0x3672d7(0x1, 0xc);
                            _0x260921['value'] = _0x5a5e64['data']['data']['data'] || [];
                        } catch (_0x16d690) {
                            _0x118aa5['error']('获取文章列表失败'), console['error']('获取文章列表失败:', _0x16d690);
                        } finally {
                            _0x18dd59['value'] = !0x1;
                        }
                }, _0xf1f83e = _0x524b45 => _0x524b45 ? new Date(_0x524b45)['toLocaleDateString']('zh-CN', {
                    'year': 'numeric',
                    'month': '2-digit',
                    'day': '2-digit'
                }) : '', _0x41731d = _0x393d51 => '/user/' + _0x393d51['userId'] + '/article/' + _0x393d51['id'], _0x77de29 = _0x48e196 => {
                    const _0x32e7b1 = _0x41731d(_0x48e196);
                    _0xb3bf30['push'](_0x32e7b1);
                }, _0x5be349 = () => {
                    _0x3fd794['value'] && _0x3fd794['value']['scrollIntoView']({ 'behavior': 'smooth' });
                };
            return _0xae5033(async () => {
                await _0x1f555c(!0x0);
            }), (_0x12b91b, _0x556c89) => {
                const _0x3f8ccc = _0x520fec, _0x659476 = _0x19dc93, _0x5e50ce = _0x24679a, _0x352d6c = _0x3b18da, _0x38f04a = _0x253470, _0x279cf6 = _0x590d70('router-link'), _0xe684e3 = _0x25d0e2;
                return _0x26421e(), _0x1f43e5('div', J, [
                    _0x5c7b1d('section', { 'class': 'fullscreen-hero' }, [
                        _0x556c89[0x1] || (_0x556c89[0x1] = _0x5c7b1d('div', { 'class': 'hero-background' }, null, -0x1)),
                        _0x556c89[0x2] || (_0x556c89[0x2] = _0x5c7b1d('div', { 'class': 'hero-content' }, [
                            _0x5c7b1d('h1', { 'class': 'hero-title' }, 'CloudScrpit'),
                            _0x5c7b1d('p', { 'class': 'hero-subtitle' }, '分享技术、经验和见解')
                        ], -0x1)),
                        _0x5c7b1d('div', {
                            'class': 'scroll-indicator',
                            'onClick': _0x5be349
                        }, _0x556c89[0x0] || (_0x556c89[0x0] = [
                            _0x5c7b1d('div', { 'class': 'mouse' }, [_0x5c7b1d('div', { 'class': 'wheel' })], -0x1),
                            _0x5c7b1d('div', { 'class': 'arrow' }, [
                                _0x5c7b1d('span'),
                                _0x5c7b1d('span'),
                                _0x5c7b1d('span')
                            ], -0x1)
                        ]))
                    ]),
                    _0x5c7b1d('main', {
                        'class': 'main-content',
                        'ref_key': 'contentSection',
                        'ref': _0x3fd794
                    }, [_0x5c7b1d('div', K, [_0x5c7b1d('div', Q, [_0x5c7b1d('section', W, [
                                    _0x556c89[0x4] || (_0x556c89[0x4] = _0x5c7b1d('h2', null, '最新文章', -0x1)),
                                    _0x5c7b1d('div', X, [_0x18dd59['value'] ? (_0x26421e(), _0x1f43e5('div', tt, [_0x477b2d(_0x659476, {
                                                'animated': '',
                                                'count': 0x6
                                            }, {
                                                'template': _0x5c0e89(() => [_0x5c7b1d('div', st, [
                                                        _0x477b2d(_0x3f8ccc, {
                                                            'variant': 'image',
                                                            'style': {
                                                                'width': '100%',
                                                                'height': '200px',
                                                                'border-radius': '8px'
                                                            }
                                                        }),
                                                        _0x5c7b1d('div', et, [
                                                            _0x5c7b1d('div', ot, [
                                                                _0x477b2d(_0x3f8ccc, {
                                                                    'variant': 'text',
                                                                    'style': {
                                                                        'width': '80px',
                                                                        'height': '20px'
                                                                    }
                                                                }),
                                                                _0x477b2d(_0x3f8ccc, {
                                                                    'variant': 'text',
                                                                    'style': {
                                                                        'width': '100px',
                                                                        'height': '20px'
                                                                    }
                                                                })
                                                            ]),
                                                            _0x477b2d(_0x3f8ccc, {
                                                                'variant': 'h3',
                                                                'style': {
                                                                    'width': '80%',
                                                                    'height': '24px',
                                                                    'margin': '10px\x200'
                                                                }
                                                            }),
                                                            _0x477b2d(_0x3f8ccc, {
                                                                'variant': 'text',
                                                                'style': {
                                                                    'width': '100%',
                                                                    'height': '16px'
                                                                }
                                                            }),
                                                            _0x477b2d(_0x3f8ccc, {
                                                                'variant': 'text',
                                                                'style': {
                                                                    'width': '90%',
                                                                    'height': '16px'
                                                                }
                                                            }),
                                                            _0x477b2d(_0x3f8ccc, {
                                                                'variant': 'text',
                                                                'style': {
                                                                    'width': '70%',
                                                                    'height': '16px'
                                                                }
                                                            })
                                                        ])
                                                    ])]),
                                                '_': 0x1
                                            })])) : _0x260921['value']['length'] === 0x0 ? (_0x26421e(), _0x1f43e5('div', at, [_0x477b2d(_0x5e50ce, { 'description': '暂无文章' })])) : (_0x26421e(), _0x1f43e5('div', lt, [(_0x26421e(!0x0), _0x1f43e5(_0x385b2f, null, _0x5f53c2(_0x260921['value'], _0x5c5eb5 => (_0x26421e(), _0x1f43e5('article', {
                                                'key': _0x5c5eb5['id'],
                                                'class': 'article-card'
                                            }, [
                                                _0x5c7b1d('div', {
                                                    'class': 'article-image',
                                                    'onClick': _0x55a733 => _0x77de29(_0x5c5eb5)
                                                }, [_0x477b2d(_0x38f04a, {
                                                        'src': _0x5c5eb5['coverUrl'],
                                                        'class': 'article-cover',
                                                        'fit': 'cover'
                                                    }, {
                                                        'placeholder': _0x5c0e89(() => [_0x5c7b1d('div', it, [_0x477b2d(_0x352d6c, { 'class': 'is-loading' }, {
                                                                    'default': _0x5c0e89(() => [_0x477b2d(_0x34f2a5(_0x1cc4ee))]),
                                                                    '_': 0x1
                                                                })])]),
                                                        'error': _0x5c0e89(() => [_0x5c7b1d('div', rt, [_0x477b2d(_0x352d6c, null, {
                                                                    'default': _0x5c0e89(() => [_0x477b2d(_0x34f2a5(_0x1db59e))]),
                                                                    '_': 0x1
                                                                })])]),
                                                        '_': 0x2
                                                    }, 0x408, ['src'])], 0x8, nt),
                                                _0x5c7b1d('div', ct, [
                                                    _0x5c7b1d('div', dt, [_0x5c7b1d('span', _t, _0x4c76b6(_0xf1f83e(_0x5c5eb5['createTime'])), 0x1)]),
                                                    _0x5c7b1d('h3', null, [_0x477b2d(_0x279cf6, {
                                                            'to': _0x41731d(_0x5c5eb5),
                                                            'class': 'article-title-link'
                                                        }, {
                                                            'default': _0x5c0e89(() => [_0x3a3ee3(_0x4c76b6(_0x5c5eb5['title']), 0x1)]),
                                                            '_': 0x2
                                                        }, 0x408, ['to'])]),
                                                    _0x5c7b1d('p', ut, _0x4c76b6(_0x5c5eb5['description'] || '暂无描述'), 0x1),
                                                    _0x5c7b1d('div', pt, [
                                                        _0x5c7b1d('span', vt, [
                                                            _0x477b2d(_0xe684e3, {
                                                                'name': 'like',
                                                                'width': '13px',
                                                                'height': '13px',
                                                                'margin-right': '1px',
                                                                'color': _0x5c5eb5['isLiked'] ? '#ffffff' : '#666666'
                                                            }, null, 0x8, ['color']),
                                                            _0x3a3ee3('\x20' + _0x4c76b6(_0x5c5eb5['likeCount'] || 0x0), 0x1)
                                                        ]),
                                                        _0x5c7b1d('span', mt, [
                                                            _0x477b2d(_0x352d6c, null, {
                                                                'default': _0x5c0e89(() => [_0x477b2d(_0x34f2a5(_0x54a296))]),
                                                                '_': 0x1
                                                            }),
                                                            _0x3a3ee3('\x20' + _0x4c76b6(_0x5c5eb5['readCount'] || 0x0), 0x1)
                                                        ]),
                                                        _0x5c7b1d('span', ft, [
                                                            _0x477b2d(_0x352d6c, null, {
                                                                'default': _0x5c0e89(() => [_0x477b2d(_0x34f2a5(_0x36c0b6))]),
                                                                '_': 0x1
                                                            }),
                                                            _0x3a3ee3('\x20' + _0x4c76b6(_0x5c5eb5['collectCount'] || 0x0), 0x1)
                                                        ]),
                                                        _0x477b2d(_0x279cf6, {
                                                            'to': _0x41731d(_0x5c5eb5),
                                                            'class': 'read-more'
                                                        }, {
                                                            'default': _0x5c0e89(() => _0x556c89[0x3] || (_0x556c89[0x3] = [_0x3a3ee3('阅读更多')])),
                                                            '_': 0x2,
                                                            '__': [0x3]
                                                        }, 0x408, ['to'])
                                                    ])
                                                ])
                                            ]))), 0x80))]))])
                                ])])])], 0x200),
                    _0x5c7b1d('footer', ht, [
                        _0x556c89[0xf] || (_0x556c89[0xf] = _0x5c7b1d('div', { 'class': 'footer-wave' }, [_0x5c7b1d('svg', {
                                'viewBox': '0\x200\x201200\x20120',
                                'preserveAspectRatio': 'none'
                            }, [_0x5c7b1d('path', { 'd': 'M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z' })])], -0x1)),
                        _0x5c7b1d('div', gt, [
                            _0x5c7b1d('div', kt, [
                                _0x556c89[0xa] || (_0x556c89[0xa] = _0x5c7b1d('div', { 'class': 'footer-brand' }, [
                                    _0x5c7b1d('h3', { 'class': 'brand-title' }, [
                                        _0x5c7b1d('span', { 'class': 'brand-icon' }, '✨'),
                                        _0x3a3ee3('\x20CloudScript\x20')
                                    ]),
                                    _0x5c7b1d('p', { 'class': 'brand-description' }, [
                                        _0x3a3ee3('分享技术、经验和见解'),
                                        _0x5c7b1d('br'),
                                        _0x3a3ee3('用代码改变世界')
                                    ])
                                ], -0x1)),
                                _0x5c7b1d('div', xt, [_0x5c7b1d('div', yt, [
                                        _0x5c7b1d('h4', wt, [
                                            _0x477b2d(_0x352d6c, null, {
                                                'default': _0x5c0e89(() => [_0x477b2d(_0x34f2a5(_0x2a2734))]),
                                                '_': 0x1
                                            }),
                                            _0x556c89[0x5] || (_0x556c89[0x5] = _0x3a3ee3('\x20快速导航\x20'))
                                        ]),
                                        _0x5c7b1d('ul', bt, [
                                            _0x5c7b1d('li', null, [_0x477b2d(_0x279cf6, { 'to': '/' }, {
                                                    'default': _0x5c0e89(() => _0x556c89[0x6] || (_0x556c89[0x6] = [_0x3a3ee3('首页')])),
                                                    '_': 0x1,
                                                    '__': [0x6]
                                                })]),
                                            _0x5c7b1d('li', null, [_0x477b2d(_0x279cf6, { 'to': '/article' }, {
                                                    'default': _0x5c0e89(() => _0x556c89[0x7] || (_0x556c89[0x7] = [_0x3a3ee3('文章')])),
                                                    '_': 0x1,
                                                    '__': [0x7]
                                                })]),
                                            _0x5c7b1d('li', null, [_0x477b2d(_0x279cf6, { 'to': '/album' }, {
                                                    'default': _0x5c0e89(() => _0x556c89[0x8] || (_0x556c89[0x8] = [_0x3a3ee3('相册')])),
                                                    '_': 0x1,
                                                    '__': [0x8]
                                                })]),
                                            _0x5c7b1d('li', null, [_0x477b2d(_0x279cf6, { 'to': '/link' }, {
                                                    'default': _0x5c0e89(() => _0x556c89[0x9] || (_0x556c89[0x9] = [_0x3a3ee3('友链')])),
                                                    '_': 0x1,
                                                    '__': [0x9]
                                                })])
                                        ])
                                    ])])
                            ]),
                            _0x5c7b1d('div', Ct, [
                                _0x556c89[0xe] || (_0x556c89[0xe] = _0x5c7b1d('div', { 'class': 'footer-divider' }, null, -0x1)),
                                _0x5c7b1d('div', Et, [
                                    _0x5c7b1d('div', St, [_0x5c7b1d('p', At, [
                                            _0x3a3ee3('©\x20' + _0x4c76b6(_0x2522d7['value']) + '\x20', 0x1),
                                            _0x556c89[0xb] || (_0x556c89[0xb] = _0x5c7b1d('strong', null, 'CloudScript', -0x1)),
                                            _0x556c89[0xc] || (_0x556c89[0xc] = _0x3a3ee3('.\x20All\x20Rights\x20Reserved.'))
                                        ])]),
                                    _0x556c89[0xd] || (_0x556c89[0xd] = _0x143069('<div\x20class=\x22footer-meta\x22\x20data-v-2432aa19><span\x20data-v-2432aa19>Made\x20with\x20❤️\x20by\x20CloudScript</span><span\x20class=\x22separator\x22\x20data-v-2432aa19>|</span><a\x20href=\x22#\x22\x20data-v-2432aa19>隐私政策</a><span\x20class=\x22separator\x22\x20data-v-2432aa19>|</span><a\x20href=\x22#\x22\x20data-v-2432aa19>使用条款</a></div>', 0x1))
                                ])
                            ])
                        ])
                    ])
                ]);
            };
        }
    }, Ot = _0x4e6c2a(Vt, [[
            '__scopeId',
            'data-v-2432aa19'
        ]]);
export {
    Ot as default
};