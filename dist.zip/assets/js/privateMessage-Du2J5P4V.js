var _0x2a564b = (function () {
        var _0x3d6212 = !![];
        return function (_0xb9434d, _0x304fac) {
            var _0x1c9b8e = _0x3d6212 ? function () {
                if (_0x304fac) {
                    var _0x323e47 = _0x304fac['apply'](_0xb9434d, arguments);
                    return _0x304fac = null, _0x323e47;
                }
            } : function () {
            };
            return _0x3d6212 = ![], _0x1c9b8e;
        };
    }()), _0xf2d117 = _0x2a564b(this, function () {
        var _0x53f8b8;
        try {
            var _0x10c7d9 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x53f8b8 = _0x10c7d9();
        } catch (_0x2507fe) {
            _0x53f8b8 = window;
        }
        var _0x2e9ab5 = _0x53f8b8['console'] = _0x53f8b8['console'] || {}, _0x177241 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (var _0x10701e = 0x0; _0x10701e < _0x177241['length']; _0x10701e++) {
            var _0x2cefb0 = _0x2a564b['constructor']['prototype']['bind'](_0x2a564b), _0x5ceb81 = _0x177241[_0x10701e], _0x3a2e67 = _0x2e9ab5[_0x5ceb81] || _0x2cefb0;
            _0x2cefb0['__proto__'] = _0x2a564b['bind'](_0x2a564b), _0x2cefb0['toString'] = _0x3a2e67['toString']['bind'](_0x3a2e67), _0x2e9ab5[_0x5ceb81] = _0x2cefb0;
        }
    });
_0xf2d117();
import { r as _0x445026 } from './Request-CHKnUlo5.js';
function s(_0x34e996, _0x26b479, _0x913007) {
    return _0x445026({
        'url': '/message/history',
        'method': 'get',
        'params': {
            'targetUserId': _0x34e996,
            'pageNum': _0x26b479,
            'pageSize': _0x913007
        }
    });
}
function n() {
    return _0x445026({
        'url': '/message/unread/count',
        'method': 'get'
    });
}
export {
    s as a,
    n as g
};