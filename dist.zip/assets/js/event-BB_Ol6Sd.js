const _0x521435 = (function () {
        let _0xb8fdd0 = !![];
        return function (_0x5e702a, _0x44427e) {
            const _0x1642d4 = _0xb8fdd0 ? function () {
                if (_0x44427e) {
                    const _0x4324b8 = _0x44427e['apply'](_0x5e702a, arguments);
                    return _0x44427e = null, _0x4324b8;
                }
            } : function () {
            };
            return _0xb8fdd0 = ![], _0x1642d4;
        };
    }()), _0x97f45a = _0x521435(this, function () {
        let _0x2a519a;
        try {
            const _0x20805f = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x2a519a = _0x20805f();
        } catch (_0x18cda8) {
            _0x2a519a = window;
        }
        const _0x16e14f = _0x2a519a['console'] = _0x2a519a['console'] || {}, _0xb20bd9 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x355294 = 0x0; _0x355294 < _0xb20bd9['length']; _0x355294++) {
            const _0x5da815 = _0x521435['constructor']['prototype']['bind'](_0x521435), _0x5127cd = _0xb20bd9[_0x355294], _0x4f582a = _0x16e14f[_0x5127cd] || _0x5da815;
            _0x5da815['__proto__'] = _0x521435['bind'](_0x521435), _0x5da815['toString'] = _0x4f582a['toString']['bind'](_0x4f582a), _0x16e14f[_0x5127cd] = _0x5da815;
        }
    });
_0x97f45a();
const E = 'update:modelValue', a = 'change', s = 'input';
export {
    a as C,
    s as I,
    E as U
};