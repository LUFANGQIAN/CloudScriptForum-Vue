const _0x494e22 = (function () {
        let _0x439c49 = !![];
        return function (_0x3e2e82, _0xae027e) {
            const _0x2b6519 = _0x439c49 ? function () {
                if (_0xae027e) {
                    const _0x4daae8 = _0xae027e['apply'](_0x3e2e82, arguments);
                    return _0xae027e = null, _0x4daae8;
                }
            } : function () {
            };
            return _0x439c49 = ![], _0x2b6519;
        };
    }()), _0x585505 = _0x494e22(this, function () {
        let _0x569daa;
        try {
            const _0x4ecfc3 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x569daa = _0x4ecfc3();
        } catch (_0x2b6578) {
            _0x569daa = window;
        }
        const _0x4285bb = _0x569daa['console'] = _0x569daa['console'] || {}, _0x1ab0ac = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x5c52f3 = 0x0; _0x5c52f3 < _0x1ab0ac['length']; _0x5c52f3++) {
            const _0x152181 = _0x494e22['constructor']['prototype']['bind'](_0x494e22), _0x52e949 = _0x1ab0ac[_0x5c52f3], _0x31d4c0 = _0x4285bb[_0x52e949] || _0x152181;
            _0x152181['__proto__'] = _0x494e22['bind'](_0x494e22), _0x152181['toString'] = _0x31d4c0['toString']['bind'](_0x31d4c0), _0x4285bb[_0x52e949] = _0x152181;
        }
    });
_0x585505();
import { a as _0x4278ee } from './Request-CHKnUlo5.js';
import { E as _0x155372 } from './el-card-BzXeyFZ5.js';
import { E as _0x2ac0da } from './el-empty-o9RgIX3C.js';
import { E as _0x359de7 } from './el-image-viewer-DAjDHmiI.js';
import {
    _ as _0x3ecf25,
    r as _0x174370,
    o as _0x58b306,
    c as _0x3a7ddb,
    d as _0x3040e2,
    f as _0x22fab1,
    u as _0xba7acf,
    i as _0x449516,
    b as _0x4d6b32,
    e as _0x3d55f4,
    k as _0x10db45,
    g as _0x3febec,
    aj as _0xfed5f0,
    F as _0x69250,
    G as _0x59f1c4,
    t as _0x2491b4,
    j as _0x2f1fa6
} from './index-54DmW9hq.js';
import { E as _0xdb9286 } from './el-button-D6wSrR74.js';
import { E as _0xc10612 } from './el-text-CbMl16cr.js';
import { l as _0x51a0f7 } from './album-BHCMrxkD.js';
import './aria-DyaK1nXM.js';
import './focus-trap-Cbj9GFlW.js';
import './index-BLYrTdqd.js';
import './toNumber-DGNxa_rg.js';
import './index-ijNW1fhk.js';
import './scroll-DDB7nuLj.js';
const G = { 'class': 'album-container' }, R = { 'class': 'card-header' }, $ = { 'class': 'album-grid' }, H = ['onClick'], J = { 'class': 'error' }, K = { 'class': 'album-info' }, O = { 'class': 'album-name' }, Q = { 'class': 'album-userName' }, W = {
        '__name': 'AlbumSquare',
        'setup'(_0x1f83c5) {
            const _0x9d6578 = _0xba7acf(), _0x5aedfa = _0x174370(!0x1), _0x36217b = _0x174370([]), _0x5ac8e2 = async () => {
                    _0x5aedfa['value'] = !0x0;
                    try {
                        const _0x231f8e = await _0x51a0f7();
                        _0x36217b['value'] = _0x231f8e['data']['data']['sort']((_0x697450, _0x258d94) => _0x697450['id'] - _0x258d94['id']);
                    } catch (_0x9ae6b8) {
                        console['error']('获取相册列表失败:', _0x9ae6b8);
                    } finally {
                        _0x5aedfa['value'] = !0x1;
                    }
                }, _0x2413fa = _0x45756c => {
                    _0x9d6578['push']({
                        'name': 'AlbumDetail',
                        'params': { 'albumId': _0x45756c }
                    });
                }, _0x539471 = () => {
                    _0x9d6578['push']({ 'name': 'MyAlbum' });
                };
            return _0x58b306(() => {
                _0x5ac8e2();
            }), (_0x277b69, _0x2ca9cb) => {
                const _0x55854a = _0xc10612, _0x243288 = _0x449516('User'), _0x5461c0 = _0x4278ee, _0x34d5df = _0xdb9286, _0xaa8209 = _0xfed5f0, _0x44970c = _0x449516('Picture'), _0x2c69be = _0x359de7, _0x22e7bc = _0x2ac0da, _0x3b47de = _0x155372;
                return _0x4d6b32(), _0x3a7ddb('div', G, [_0x3040e2(_0x3b47de, {
                        'shadow': 'hover',
                        'class': 'main-card'
                    }, {
                        'header': _0x22fab1(() => [_0x3febec('div', R, [
                                _0x3040e2(_0x55854a, {
                                    'size': 'large',
                                    'class': 'album-title'
                                }, {
                                    'default': _0x22fab1(() => _0x2ca9cb[0x0] || (_0x2ca9cb[0x0] = [_0x2f1fa6('相册广场')])),
                                    '_': 0x1,
                                    '__': [0x0]
                                }),
                                _0x3040e2(_0x34d5df, {
                                    'type': 'primary',
                                    'onClick': _0x539471,
                                    'class': 'my-album-btn'
                                }, {
                                    'default': _0x22fab1(() => [
                                        _0x3040e2(_0x5461c0, { 'style': { 'margin-right': '2px' } }, {
                                            'default': _0x22fab1(() => [_0x3040e2(_0x243288)]),
                                            '_': 0x1
                                        }),
                                        _0x2ca9cb[0x1] || (_0x2ca9cb[0x1] = _0x2f1fa6('我的相册\x20'))
                                    ]),
                                    '_': 0x1,
                                    '__': [0x1]
                                })
                            ])]),
                        'default': _0x22fab1(() => [
                            _0x5aedfa['value'] ? (_0x4d6b32(), _0x3d55f4(_0xaa8209, { 'key': 0x0 })) : _0x10db45('', !0x0),
                            _0x3febec('div', $, [(_0x4d6b32(!0x0), _0x3a7ddb(_0x69250, null, _0x59f1c4(_0x36217b['value'], _0x37084f => (_0x4d6b32(), _0x3a7ddb('div', {
                                    'key': _0x37084f['id'],
                                    'class': 'album-card'
                                }, [_0x3febec('div', {
                                        'class': 'album-image-container',
                                        'onClick': _0x512264 => _0x2413fa(_0x37084f['id'])
                                    }, [
                                        _0x3040e2(_0x2c69be, {
                                            'src': _0x37084f['coverUrl'] || '',
                                            'class': 'album-image',
                                            'fit': 'cover',
                                            'lazy': '',
                                            'loading': 'lazy'
                                        }, {
                                            'placeholder': _0x22fab1(() => _0x2ca9cb[0x2] || (_0x2ca9cb[0x2] = [_0x3febec('div', { 'class': 'loading-text' }, '加载中...', -0x1)])),
                                            'error': _0x22fab1(() => [_0x3febec('div', J, [_0x3040e2(_0x5461c0, null, {
                                                        'default': _0x22fab1(() => [_0x3040e2(_0x44970c)]),
                                                        '_': 0x1
                                                    })])]),
                                            '_': 0x2
                                        }, 0x408, ['src']),
                                        _0x3febec('div', K, [
                                            _0x3febec('h3', O, _0x2491b4(_0x37084f['name']), 0x1),
                                            _0x3febec('h4', Q, _0x2491b4(_0x37084f['userName']), 0x1)
                                        ])
                                    ], 0x8, H)]))), 0x80))]),
                            _0x36217b['value']['length'] === 0x0 && !_0x5aedfa['value'] ? (_0x4d6b32(), _0x3d55f4(_0x22e7bc, {
                                'key': 0x1,
                                'image-size': 0xc8,
                                'description': '暂无相册'
                            })) : _0x10db45('', !0x0)
                        ]),
                        '_': 0x1
                    })]);
            };
        }
    }, de = _0x3ecf25(W, [[
            '__scopeId',
            'data-v-b5cc3561'
        ]]);
export {
    de as default
};