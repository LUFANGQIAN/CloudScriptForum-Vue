const _0x5ac0a4 = (function () {
        let _0x9270d8 = !![];
        return function (_0x2c81fe, _0x5c6eff) {
            const _0x5c7df3 = _0x9270d8 ? function () {
                if (_0x5c6eff) {
                    const _0x313127 = _0x5c6eff['apply'](_0x2c81fe, arguments);
                    return _0x5c6eff = null, _0x313127;
                }
            } : function () {
            };
            return _0x9270d8 = ![], _0x5c7df3;
        };
    }()), _0x2f2b39 = _0x5ac0a4(this, function () {
        const _0xba92e = function () {
                let _0x249783;
                try {
                    _0x249783 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');')();
                } catch (_0x169cac) {
                    _0x249783 = window;
                }
                return _0x249783;
            }, _0x4dad6d = _0xba92e(), _0x447b4d = _0x4dad6d['console'] = _0x4dad6d['console'] || {}, _0x38b827 = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x588e32 = 0x0; _0x588e32 < _0x38b827['length']; _0x588e32++) {
            const _0x213035 = _0x5ac0a4['constructor']['prototype']['bind'](_0x5ac0a4), _0x19c563 = _0x38b827[_0x588e32], _0x1c0573 = _0x447b4d[_0x19c563] || _0x213035;
            _0x213035['__proto__'] = _0x5ac0a4['bind'](_0x5ac0a4), _0x213035['toString'] = _0x1c0573['toString']['bind'](_0x1c0573), _0x447b4d[_0x19c563] = _0x213035;
        }
    });
_0x2f2b39();
import {
    u as _0x3b17b5,
    a as _0x217250,
    b as _0xf2d4e9
} from './Request-CHKnUlo5.js';
import { v as _0x2dda68 } from './el-loading-BYktkv7A.js';
import { E as _0x3d394f } from './el-input-D-8X7_j3.js';
import { E as _0x2b5d63 } from './el-empty-o9RgIX3C.js';
import { E as _0x2a3028 } from './el-image-viewer-DAjDHmiI.js';
import { E as _0x4e9879 } from './el-avatar-D7H8d9zq.js';
import { E as _0x541ea3 } from './el-button-D6wSrR74.js';
import {
    _ as _0x537265,
    r as _0x2b99a8,
    Y as _0x435c80,
    E as _0x7ff98e,
    o as _0x42a2fe,
    Q as _0x56a497,
    c as _0x1d638a,
    g as _0x1ecb2f,
    A as _0x4391d5,
    k,
    d as _0x4cae74,
    m as _0x160b94,
    ay as _0x2f46b8,
    t as _0x310419,
    e as _0x5c133c,
    F as _0x31e299,
    G as _0x5713f1,
    $ as _0x34b02a,
    f as _0x2ab615,
    l as _0x266e3f,
    C as _0x4014e4,
    az as _0x577855,
    O as _0x3cb96e,
    B as _0x1be939,
    ar as _0x39c579,
    u as _0x181b9b,
    a4 as _0x26e221,
    b as _0x424e5e,
    z as _0x36f2e1,
    au as _0x128643,
    ag as _0x4afe8b,
    j as _0x2eac59
} from './index-54DmW9hq.js';
import { a as _0x42735b } from './privateMessage-Du2J5P4V.js';
import { g as _0x38824b } from './user-BDWxAMXB.js';
import { g as _0x1640ea } from './conversation-BnzxcDLp.js';
import { c as _0x1ac006 } from './photo-U6egaMYg.js';
import {
    u as _0xa3a0a5,
    W as _0x280996
} from './WebSocketClient-CQU1CbB3.js';
import { g as _0x581711 } from './formatTime-B8qE7LcY.js';
import './index-DMxv2JmO.js';
import './event-BB_Ol6Sd.js';
import './index-ijNW1fhk.js';
import './aria-DyaK1nXM.js';
import './focus-trap-Cbj9GFlW.js';
import './index-BLYrTdqd.js';
import './toNumber-DGNxa_rg.js';
import './scroll-DDB7nuLj.js';
const es = [
        '😀',
        '😁',
        '😂',
        '🤣',
        '😃',
        '😄',
        '😅',
        '😆',
        '😉',
        '😊',
        '😋',
        '😎',
        '😍',
        '😘',
        '🥰',
        '😗',
        '😙',
        '😚',
        '🙂',
        '🤗',
        '🤩',
        '🤔',
        '🤨',
        '😐',
        '😑',
        '😶',
        '🙄',
        '😏',
        '😣',
        '😥',
        '😮',
        '🤐',
        '😯',
        '😪',
        '😫',
        '😴',
        '😌',
        '😛',
        '😜',
        '😝',
        '🤤',
        '😒',
        '😓',
        '😔',
        '😕',
        '🙃',
        '🤑',
        '😲',
        '🙁',
        '😖',
        '😞',
        '😟',
        '😤',
        '😢',
        '😭',
        '😦',
        '😧',
        '😨',
        '😩',
        '🤯',
        '😬',
        '😰',
        '😱',
        '🥵',
        '🥶',
        '😳',
        '🤪',
        '😵',
        '😡',
        '😠',
        '🤬',
        '😷',
        '🤒',
        '🤕',
        '🤢',
        '🤮',
        '🤧',
        '😇',
        '🤠',
        '🤡',
        '🥳',
        '🥴',
        '🥺',
        '🤥',
        '🤫',
        '🤭',
        '🧐',
        '🤓',
        '😈',
        '👿',
        '👻',
        '💀',
        '☠️',
        '👽',
        '👾',
        '🤖',
        '💩',
        '😺',
        '😸',
        '😹',
        '😻',
        '😼',
        '😽',
        '🙀',
        '😿',
        '😾',
        '👋',
        '🤚',
        '🖐️',
        '✋',
        '🖖',
        '👌',
        '🤏',
        '✌️',
        '🤞',
        '🤟',
        '🤘',
        '🤙',
        '👈',
        '👉',
        '👆',
        '🖕',
        '👇',
        '☝️',
        '👍',
        '👎',
        '✊',
        '👊',
        '🤛',
        '🤜',
        '👏',
        '🙌',
        '👐',
        '🤲',
        '🤝',
        '🙏',
        '💪',
        '🦾',
        '🦿',
        '🦵',
        '🦶',
        '👂',
        '🦻',
        '👃',
        '🧠',
        '🦷',
        '🦴',
        '👀',
        '👁️',
        '👅',
        '👄',
        '💋',
        '❤️',
        '🧡',
        '💛',
        '💚',
        '💙',
        '💜',
        '🖤',
        '🤍',
        '🤎',
        '💔',
        '❣️',
        '💕',
        '💞',
        '💓',
        '💗',
        '💖',
        '💘',
        '💝',
        '💟',
        '☮️',
        '✝️',
        '☪️',
        '🕉️',
        '☸️',
        '✡️',
        '🔯',
        '🕎',
        '☯️',
        '☦️',
        '🛐',
        '⛎',
        '♈',
        '♉',
        '♊',
        '♋',
        '♌',
        '♍',
        '♎',
        '♏',
        '♐',
        '♑',
        '♒',
        '♓',
        '🆔',
        '⚛️',
        '🉑',
        '☢️',
        '☣️',
        '📴',
        '📳',
        '🈶',
        '🈚',
        '🈸',
        '🈺',
        '🈷️',
        '✴️',
        '🆚',
        '💮',
        '🉐',
        '㊙️',
        '㊗️',
        '🈴',
        '🈵',
        '🈹',
        '🈲',
        '🅰️',
        '🅱️',
        '🆎',
        '🆑',
        '🅾️',
        '🆘',
        '❌',
        '⭕',
        '🛑',
        '⛔',
        '📛',
        '🚫',
        '💯',
        '💢',
        '♨️',
        '🚷',
        '🚯',
        '🚳',
        '🚱',
        '🔞',
        '📵',
        '🚭',
        '❗',
        '❕',
        '❓',
        '❔',
        '‼️',
        '⁉️',
        '🔅',
        '🔆',
        '〽️',
        '⚠️',
        '🚸',
        '🔱',
        '⚜️',
        '🔰',
        '♻️',
        '✅',
        '🈯',
        '💹',
        '❇️',
        '✳️',
        '❎',
        '🌐',
        '💠',
        'Ⓜ️',
        '🌀',
        '💤',
        '🏧',
        '🚾',
        '♿',
        '🅿️',
        '🈳',
        '🈂️',
        '🛂',
        '🛃',
        '🛄',
        '🛅',
        '🚹',
        '🚺',
        '🚼',
        '🚻',
        '🚮',
        '🎦',
        '📶',
        '🈁',
        '🔣',
        'ℹ️',
        '🔤',
        '🔡',
        '🔠',
        '🆖',
        '🆗',
        '🆙',
        '🆒',
        '🆕',
        '🆓',
        '0️⃣',
        '1️⃣',
        '2️⃣',
        '3️⃣',
        '4️⃣',
        '5️⃣',
        '6️⃣',
        '7️⃣',
        '8️⃣',
        '9️⃣',
        '🔟',
        '🔢',
        '#️⃣',
        '*️⃣',
        '⏏️',
        '▶️',
        '⏸️',
        '⏯️',
        '⏹️',
        '⏺️',
        '⏭️',
        '⏮️',
        '⏩',
        '⏪',
        '⏫',
        '⏬',
        '◀️',
        '🔼',
        '🔽',
        '➡️',
        '⬅️',
        '⬆️',
        '⬇️',
        '↗️',
        '↘️',
        '↙️',
        '↖️',
        '↕️',
        '↔️',
        '↪️',
        '↩️',
        '⤴️',
        '⤵️',
        '🔀',
        '🔁',
        '🔂',
        '🔄',
        '🔃',
        '🎵',
        '🎶',
        '➕',
        '➖',
        '➗',
        '✖️',
        '♾️',
        '💲',
        '💱',
        '™️',
        '©️',
        '®️',
        '👁️‍🗨️',
        '🔚',
        '🔙',
        '🔛',
        '🔝',
        '🔜',
        '〰️',
        '➰',
        '➿',
        '✔️',
        '☑️',
        '🔘',
        '🔴',
        '🟠',
        '🟡',
        '🟢',
        '🔵',
        '🟣',
        '⚫',
        '⚪',
        '🟤',
        '🔺',
        '🔻',
        '🔸',
        '🔹',
        '🔶',
        '🔷',
        '🔳',
        '🔲',
        '▪️',
        '▫️',
        '◾',
        '◽',
        '◼️',
        '◻️',
        '🟥',
        '🟧',
        '🟨',
        '🟩',
        '🟦',
        '🟪',
        '⬛',
        '⬜',
        '🟫',
        '🔈',
        '🔇',
        '🔉',
        '🔊',
        '🔔',
        '🔕',
        '📣',
        '📢',
        '💬',
        '💭',
        '🗯️',
        '♠️',
        '♣️',
        '♥️',
        '♦️',
        '🃏',
        '🎴',
        '🀄',
        '🕐',
        '🕑',
        '🕒',
        '🕓',
        '🕔',
        '🕕',
        '🕖',
        '🕗',
        '🕘',
        '🕙',
        '🕚',
        '🕛'
    ], ss = { 'class': 'chat-window-page' }, ts = { 'class': 'container' }, as = { 'class': 'chat-window-container' }, os = { 'class': 'chat-header' }, ns = {
        'key': 0x0,
        'class': 'user-info'
    }, rs = {
        'key': 0x0,
        'class': 'online-indicator'
    }, ls = { 'class': 'user-details' }, is = { 'class': 'username' }, cs = {
        'key': 0x0,
        'class': 'online-status-text'
    }, us = [
        'onContextmenu',
        'onTouchstart'
    ], ds = { 'class': 'message-content' }, vs = { 'class': 'message-header' }, ms = { 'class': 'message-nickname' }, fs = { 'class': 'message-time' }, ps = { 'class': 'message-body' }, gs = {
        'key': 0x0,
        'class': 'text-message'
    }, _s = { 'class': 'image-error' }, hs = {
        'key': 0x0,
        'class': 'read-status'
    }, ks = {
        'key': 0x0,
        'class': 'read-text'
    }, ys = {
        'key': 0x1,
        'class': 'unread-text'
    }, Cs = {
        'key': 0x0,
        'class': 'revoke-notification'
    }, Es = { 'class': 'message-input-area' }, Us = { 'class': 'input-actions' }, Ss = { 'class': 'input-actions-left' }, Ts = { 'class': 'emoji-picker' }, Ms = { 'class': 'emoji-header' }, xs = { 'class': 'emoji-list' }, Is = ['onClick'], ws = {
        '__name': 'ChatWindow',
        'setup'(_0x568190) {
            const _0x3050ff = _0x7ff98e(), _0x41957a = _0x181b9b(), _0x24d560 = _0xa3a0a5(), _0xf9dc2c = _0x3b17b5(), _0xdbdb20 = _0x2b99a8(!0x1), _0x1fbef6 = _0x2b99a8(''), _0x2999e0 = _0x2b99a8(null), _0x30e088 = _0x2b99a8(null), _0x52b98b = _0x2b99a8(null), _0xe7a0b = _0x2b99a8(!0x1), _0x1ee0ad = _0x2b99a8(!0x1), _0x5c0df6 = _0x2b99a8(null), _0x4c8052 = _0x435c80(() => parseInt(_0x3050ff['params']['userId'])), _0x268edb = _0x435c80(() => {
                    var _0x51723b;
                    return (_0x51723b = _0xf9dc2c['user']) == null ? void 0x0 : _0x51723b['id'];
                }), _0x1b94bd = _0x2b99a8(!0x1), _0x3a8ff7 = _0x2b99a8(!0x1), _0x695fd = _0x2b99a8({
                    'x': 0x0,
                    'y': 0x0
                }), _0x5a7f50 = _0x2b99a8(null), _0x124e1b = _0x2b99a8(null), _0x504073 = _0x2b99a8(!0x1), _0x5931be = _0x2b99a8(''), _0x4b548d = _0x2b99a8(null), _0x3e50d2 = async () => {
                    try {
                        const _0xfee61 = await _0x38824b(_0x4c8052['value']);
                        _0x2999e0['value'] = _0xfee61['data']['data'];
                    } catch (_0x2bb60e) {
                        console['error']('获取用户信息失败:', _0x2bb60e);
                    }
                }, _0x28042b = async () => {
                    var _0x284126;
                    try {
                        _0xdbdb20['value'] = !0x0;
                        const _0x4fdda0 = ((_0x284126 = (await _0x42735b(_0x4c8052['value'], 0x1, 0x32))['data']['data']) == null ? void 0x0 : _0x284126['data']) || [];
                        _0x24d560['setCurrentChatMessages'](_0x4fdda0['reverse']()), _0xb559e4(), _0x4fdda0['length'] > 0x0 && _0x280996['markAsRead'](_0x4c8052['value']);
                    } catch (_0xbaa1bb) {
                        console['error']('获取聊天记录失败:', _0xbaa1bb);
                    } finally {
                        _0xdbdb20['value'] = !0x1;
                    }
                }, _0x526901 = () => {
                    var _0x3dea83, _0x4f03f5, _0x35c64c, _0x490f01;
                    if (!_0x1fbef6['value']['trim']())
                        return;
                    const _0x4b30e6 = _0x1fbef6['value'], _0x22b802 = {
                            'id': Date['now'](),
                            'fromUserId': _0x268edb['value'],
                            'toUserId': _0x4c8052['value'],
                            'content': _0x4b30e6,
                            'messageType': 0x1,
                            'createTime': new Date(),
                            'isRead': 0x0,
                            'isRevoked': 0x0,
                            'fromUserNickname': (_0x3dea83 = _0xf9dc2c['user']) == null ? void 0x0 : _0x3dea83['nickname'],
                            'fromUserAvatar': (_0x4f03f5 = _0xf9dc2c['user']) == null ? void 0x0 : _0x4f03f5['avatar'],
                            'toUserNickname': (_0x35c64c = _0x2999e0['value']) == null ? void 0x0 : _0x35c64c['nickname'],
                            'toUserAvatar': (_0x490f01 = _0x2999e0['value']) == null ? void 0x0 : _0x490f01['avatar']
                        };
                    _0x24d560['addMessageToCurrentChat'](_0x22b802), _0xb559e4(), _0x280996['sendTextMessage'](_0x4c8052['value'], _0x4b30e6), _0x1fbef6['value'] = '';
                }, _0x5b1def = () => {
                    if (!_0x5c0df6['value']) {
                        const _0x2a9ff7 = document['createElement']('input');
                        _0x2a9ff7['type'] = 'file', _0x2a9ff7['accept'] = 'image/*', _0x2a9ff7['onchange'] = _0x41074c, _0x5c0df6['value'] = _0x2a9ff7;
                    }
                    _0x5c0df6['value']['click']();
                }, _0x41074c = async _0x3cfa25 => {
                    var _0xe2f279, _0x242907, _0x476fc4, _0x5d7b88, _0x26933a;
                    const _0x4e41d5 = (_0xe2f279 = _0x3cfa25['target']['files']) == null ? void 0x0 : _0xe2f279[0x0];
                    if (!_0x4e41d5)
                        return;
                    if (!_0x4e41d5['type']['startsWith']('image/')) {
                        _0xf2d4e9['error']('只能上传图片文件');
                        return;
                    }
                    const _0x15ef83 = 0xa * 0x400 * 0x400;
                    if (_0x4e41d5['size'] > _0x15ef83) {
                        _0xf2d4e9['error']('图片大小不能超过10MB');
                        return;
                    }
                    try {
                        _0x1ee0ad['value'] = !0x0;
                        const _0x4cc523 = (await _0x1ac006(_0x4e41d5))['data']['data'], _0x375170 = {
                                'id': Date['now'](),
                                'fromUserId': _0x268edb['value'],
                                'toUserId': _0x4c8052['value'],
                                'content': '[图片]',
                                'messageType': 0x2,
                                'imageUrl': _0x4cc523,
                                'createTime': new Date(),
                                'isRead': 0x0,
                                'isRevoked': 0x0,
                                'fromUserNickname': (_0x242907 = _0xf9dc2c['user']) == null ? void 0x0 : _0x242907['nickname'],
                                'fromUserAvatar': (_0x476fc4 = _0xf9dc2c['user']) == null ? void 0x0 : _0x476fc4['avatar'],
                                'toUserNickname': (_0x5d7b88 = _0x2999e0['value']) == null ? void 0x0 : _0x5d7b88['nickname'],
                                'toUserAvatar': (_0x26933a = _0x2999e0['value']) == null ? void 0x0 : _0x26933a['avatar']
                            };
                        _0x24d560['addMessageToCurrentChat'](_0x375170), _0xb559e4(), _0x280996['sendImageMessage'](_0x4c8052['value'], _0x4cc523), _0xf2d4e9['success']('图片发送成功');
                    } catch (_0x680f41) {
                        _0xf2d4e9['error']('图片上传失败'), console['error']('上传图片失败:', _0x680f41);
                    } finally {
                        _0x1ee0ad['value'] = !0x1, _0x5c0df6['value'] && (_0x5c0df6['value']['value'] = '');
                    }
                }, _0x5f8665 = () => {
                    _0xe7a0b['value'] = !_0xe7a0b['value'];
                }, _0x1900b0 = () => {
                    _0xe7a0b['value'] = !0x1;
                }, _0x9e6fbf = _0x3f0477 => {
                    var _0x9c6e8a, _0xcb7d13;
                    const _0x3c659d = (_0xcb7d13 = (_0x9c6e8a = _0x52b98b['value']) == null ? void 0x0 : _0x9c6e8a['$el']) == null ? void 0x0 : _0xcb7d13['querySelector']('textarea');
                    if (_0x3c659d) {
                        const _0x370be6 = _0x3c659d['selectionStart'], _0x423275 = _0x3c659d['selectionEnd'], _0x166a6b = _0x1fbef6['value']['substring'](0x0, _0x370be6), _0x1bf29b = _0x1fbef6['value']['substring'](_0x423275);
                        _0x1fbef6['value'] = _0x166a6b + _0x3f0477 + _0x1bf29b, _0x26e221(() => {
                            const _0x2e2e65 = _0x370be6 + _0x3f0477['length'];
                            _0x3c659d['setSelectionRange'](_0x2e2e65, _0x2e2e65), _0x3c659d['focus']();
                        });
                    } else
                        _0x1fbef6['value'] += _0x3f0477;
                }, _0xb559e4 = () => {
                    _0x26e221(() => {
                        _0x30e088['value'] && (_0x30e088['value']['scrollTop'] = _0x30e088['value']['scrollHeight']);
                    });
                }, _0x1b1e23 = () => {
                    _0x41957a['push']('/message');
                }, _0x24c645 = _0x4b2b17 => {
                    _0x41957a['push']('/user/' + _0x4b2b17);
                }, _0x110cad = _0x4f51a1 => {
                    if (_0x4f51a1['fromUserId'] !== _0x268edb['value'] || _0x4f51a1['isRevoked'] === 0x1)
                        return !0x1;
                    const _0x38718a = new Date()['getTime'](), _0x2beeaa = new Date(_0x4f51a1['createTime'])['getTime']();
                    return (_0x38718a - _0x2beeaa) / 0x3e8 / 0x3c <= 0x2;
                }, _0x1d1445 = (_0x20f791, _0x6531ef) => {
                    _0x6531ef['messageType'] !== 0x1 && !_0x110cad(_0x6531ef) || (_0x3a8ff7['value'] = !0x0, _0x695fd['value'] = {
                        'x': _0x20f791['clientX'],
                        'y': _0x20f791['clientY']
                    }, _0x5a7f50['value'] = _0x6531ef);
                }, _0x3557bb = (_0x3dc17e, _0x145ffc) => {
                    _0x145ffc['messageType'] !== 0x1 && !_0x110cad(_0x145ffc) || (_0x504073['value'] = !0x1, _0x124e1b['value'] = setTimeout(() => {
                        _0x504073['value'] = !0x0;
                        const _0x3c6e90 = _0x3dc17e['touches'][0x0];
                        _0x3a8ff7['value'] = !0x0, _0x695fd['value'] = {
                            'x': _0x3c6e90['clientX'],
                            'y': _0x3c6e90['clientY']
                        }, _0x5a7f50['value'] = _0x145ffc, navigator['vibrate'] && navigator['vibrate'](0x32);
                    }, 0x1f4));
                }, _0x2b5b68 = () => {
                    _0x124e1b['value'] && (clearTimeout(_0x124e1b['value']), _0x124e1b['value'] = null);
                }, _0x3b6e82 = () => {
                    _0x124e1b['value'] && (clearTimeout(_0x124e1b['value']), _0x124e1b['value'] = null);
                }, _0x4100ec = async () => {
                    if (!(!_0x5a7f50['value'] || _0x5a7f50['value']['messageType'] !== 0x1)) {
                        try {
                            if (navigator['clipboard'] && navigator['clipboard']['writeText'])
                                await navigator['clipboard']['writeText'](_0x5a7f50['value']['content']), _0xf2d4e9['success']('消息已复制到剪贴板');
                            else {
                                const _0x2cd9eb = document['createElement']('textarea');
                                _0x2cd9eb['value'] = _0x5a7f50['value']['content'], _0x2cd9eb['style']['position'] = 'fixed', _0x2cd9eb['style']['left'] = '-999999px', _0x2cd9eb['style']['top'] = '-999999px', document['body']['appendChild'](_0x2cd9eb), _0x2cd9eb['focus'](), _0x2cd9eb['select']();
                                try {
                                    document['execCommand']('copy'), _0xf2d4e9['success']('消息已复制到剪贴板');
                                } catch (_0x354f3e) {
                                    console['error']('复制失败:', _0x354f3e), _0xf2d4e9['error']('复制失败，请手动复制');
                                }
                                document['body']['removeChild'](_0x2cd9eb);
                            }
                        } catch (_0x55e19c) {
                            console['error']('复制消息失败:', _0x55e19c), _0xf2d4e9['error']('复制失败，请手动复制');
                        }
                        _0x3a8ff7['value'] = !0x1, _0x5a7f50['value'] = null;
                    }
                }, _0x3c9e84 = async () => {
                    _0x5a7f50['value'] && (_0x280996['revokeMessage'](_0x5a7f50['value']['id']), _0x3a8ff7['value'] = !0x1, _0x5a7f50['value'] = null);
                }, _0x1fa9c4 = _0x450bee => {
                    _0x5931be['value'] = _0x450bee, _0x4b548d['value'] && clearTimeout(_0x4b548d['value']), _0x4b548d['value'] = setTimeout(() => {
                        _0x5931be['value'] = '', _0x4b548d['value'] = null;
                    }, 0x2710), _0xb559e4();
                }, _0x3c631f = _0x4b0e43 => {
                    if (_0x3a8ff7['value'] = !0x1, _0x5a7f50['value'] = null, _0x4b0e43 && _0xe7a0b['value']) {
                        const _0x482d1e = _0x4b0e43['target'], _0x5b9fab = document['querySelector']('.emoji-picker'), _0x5e851c = document['querySelector']('.input-actions\x20.el-button');
                        _0x5b9fab && !_0x5b9fab['contains'](_0x482d1e) && _0x5e851c && !_0x5e851c['contains'](_0x482d1e) && _0x1900b0();
                    }
                }, _0x550f51 = _0x2f8b8e => {
                    var _0x2d0ffb, _0x3f746a, _0x452021, _0x4c0b5d;
                    if (_0x2f8b8e['fromUserId'] === _0x4c8052['value'] || _0x2f8b8e['toUserId'] === _0x4c8052['value']) {
                        const _0x467135 = {
                            ..._0x2f8b8e,
                            'id': _0x2f8b8e['messageId'] || _0x2f8b8e['id'],
                            'fromUserNickname': _0x2f8b8e['fromUserNickname'] || ((_0x2d0ffb = _0x2999e0['value']) == null ? void 0x0 : _0x2d0ffb['nickname']),
                            'fromUserAvatar': _0x2f8b8e['fromUserAvatar'] || ((_0x3f746a = _0x2999e0['value']) == null ? void 0x0 : _0x3f746a['avatar']),
                            'toUserNickname': _0x2f8b8e['toUserNickname'] || ((_0x452021 = _0xf9dc2c['user']) == null ? void 0x0 : _0x452021['nickname']),
                            'toUserAvatar': _0x2f8b8e['toUserAvatar'] || ((_0x4c0b5d = _0xf9dc2c['user']) == null ? void 0x0 : _0x4c0b5d['avatar'])
                        };
                        _0x24d560['addMessageToCurrentChat'](_0x467135), _0xb559e4(), _0x2f8b8e['fromUserId'] === _0x4c8052['value'] && (_0x24d560['clearConversationUnread'](_0x4c8052['value']), _0x280996['markAsRead'](_0x4c8052['value']));
                    }
                }, _0x3fff1e = _0x42c27e => {
                    const _0x585111 = _0x24d560['currentChatMessages'], _0x2e395d = _0x585111[_0x585111['length'] - 0x1];
                    _0x2e395d && _0x2e395d['id'] > Date['now']() - 0x1388 && (_0x2e395d['id'] = _0x42c27e['messageId']);
                }, _0x100bd3 = _0x3bdd42 => {
                    _0x3bdd42['fromUserId'] === _0x4c8052['value'] && _0x24d560['currentChatMessages']['forEach'](_0x1a6b52 => {
                        _0x1a6b52['fromUserId'] === _0x268edb['value'] && _0x1a6b52['toUserId'] === _0x4c8052['value'] && (_0x1a6b52['isRead'] = 0x1);
                    });
                }, _0x95d2bd = _0x431c7f => {
                    _0x431c7f['userId'] === _0x4c8052['value'] && (_0x1b94bd['value'] = _0x431c7f['isOnline'], _0x24d560['updateUserOnlineStatus'](_0x431c7f['userId'], _0x431c7f['isOnline']));
                }, _0x42fa99 = _0x2b9c61 => {
                    const _0x5daf91 = _0x24d560['currentChatMessages']['findIndex'](_0x263f00 => _0x263f00['id'] === _0x2b9c61['messageId']);
                    if (_0x5daf91 > -0x1) {
                        const _0x263d12 = _0x5daf91 === _0x24d560['currentChatMessages']['length'] - 0x1;
                        _0x24d560['currentChatMessages']['splice'](_0x5daf91, 0x1), _0x263d12 && _0x24d560['updateConversationLastMessage'](_0x4c8052['value'], '你撤回了一条消息');
                    }
                    _0x1fa9c4('你撤回了一条消息'), _0xf2d4e9['success']('消息已撤回');
                }, _0xad2464 = _0x26cfe1 => {
                    _0xf2d4e9['error'](_0x26cfe1['message'] || '撤回消息失败'), console['error']('撤回消息失败:', _0x26cfe1['message']);
                }, _0x55b515 = _0x39bfec => {
                    const _0x65863a = _0x24d560['currentChatMessages']['findIndex'](_0x4f7892 => _0x4f7892['id'] === _0x39bfec['messageId']);
                    if (_0x65863a > -0x1) {
                        const _0x37fb48 = _0x24d560['currentChatMessages'][_0x65863a], _0xc9ec8b = _0x65863a === _0x24d560['currentChatMessages']['length'] - 0x1;
                        if (_0x24d560['currentChatMessages']['splice'](_0x65863a, 0x1), _0x37fb48['fromUserId'] === _0x4c8052['value']) {
                            const _0x4c6828 = (_0x37fb48['fromUserNickname'] || '对方') + '撤回了一条消息';
                            _0x1fa9c4(_0x4c6828), _0xc9ec8b && _0x24d560['updateConversationLastMessage'](_0x4c8052['value'], _0x4c6828);
                        } else
                            _0xc9ec8b && _0x24d560['updateConversationLastMessage'](_0x4c8052['value'], '你撤回了一条消息');
                    }
                };
            return _0x42a2fe(async () => {
                if (_0x24d560['setCurrentChatUser'](_0x4c8052['value']), _0x3e50d2(), _0x28042b(), _0x24d560['conversationList']['length'] === 0x0)
                    try {
                        const _0xc9ef3c = await _0x1640ea();
                        _0x24d560['setConversationList'](_0xc9ef3c['data']['data']);
                        const _0xeddb65 = _0x24d560['conversationList']['find'](_0x16d885 => _0x16d885['targetUserId'] === _0x4c8052['value']);
                        _0xeddb65 && (_0x1b94bd['value'] = _0xeddb65['isOnline'] || !0x1);
                    } catch (_0x403807) {
                        console['error']('获取会话列表失败:', _0x403807);
                    }
                else {
                    const _0x17e95b = _0x24d560['conversationList']['find'](_0x3f8ca2 => _0x3f8ca2['targetUserId'] === _0x4c8052['value']);
                    _0x17e95b && (_0x1b94bd['value'] = _0x17e95b['isOnline'] || !0x1);
                }
                _0x280996['on']('NEW_MESSAGE', _0x550f51), _0x280996['on']('SEND_SUCCESS', _0x3fff1e), _0x280996['on']('MESSAGE_READ', _0x100bd3), _0x280996['on']('USER_ONLINE_STATUS', _0x95d2bd), _0x280996['on']('REVOKE_SUCCESS', _0x42fa99), _0x280996['on']('REVOKE_FAILED', _0xad2464), _0x280996['on']('MESSAGE_REVOKED', _0x55b515), document['addEventListener']('click', _0x3c631f);
            }), _0x56a497(() => {
                _0x280996['off']('NEW_MESSAGE', _0x550f51), _0x280996['off']('SEND_SUCCESS', _0x3fff1e), _0x280996['off']('MESSAGE_READ', _0x100bd3), _0x280996['off']('USER_ONLINE_STATUS', _0x95d2bd), _0x280996['off']('REVOKE_SUCCESS', _0x42fa99), _0x280996['off']('REVOKE_FAILED', _0xad2464), _0x280996['off']('MESSAGE_REVOKED', _0x55b515), _0x24d560['setCurrentChatUser'](null), document['removeEventListener']('click', _0x3c631f), _0x124e1b['value'] && clearTimeout(_0x124e1b['value']), _0x4b548d['value'] && clearTimeout(_0x4b548d['value']);
            }), (_0x2be00b, _0x426ebf) => {
                const _0x29dae6 = _0x541ea3, _0x286e7d = _0x4e9879, _0x459487 = _0x217250, _0x5097f4 = _0x2a3028, _0x5463ac = _0x2b5d63, _0x93e2cc = _0x3d394f, _0x299124 = _0x2dda68;
                return _0x424e5e(), _0x1d638a('div', ss, [_0x1ecb2f('div', ts, [_0x1ecb2f('div', as, [
                            _0x1ecb2f('div', os, [
                                _0x4cae74(_0x29dae6, {
                                    'icon': _0x160b94(_0x2f46b8),
                                    'circle': '',
                                    'onClick': _0x1b1e23
                                }, null, 0x8, ['icon']),
                                _0x2999e0['value'] ? (_0x424e5e(), _0x1d638a('div', ns, [
                                    _0x1ecb2f('div', {
                                        'class': 'avatar-wrapper',
                                        'onClick': _0x426ebf[0x0] || (_0x426ebf[0x0] = _0x2a9f17 => _0x24c645(_0x2999e0['value']['id']))
                                    }, [
                                        _0x4cae74(_0x286e7d, {
                                            'size': 0x28,
                                            'src': _0x2999e0['value']['avatar']
                                        }, null, 0x8, ['src']),
                                        _0x1b94bd['value'] ? (_0x424e5e(), _0x1d638a('span', rs)) : k('', !0x0)
                                    ]),
                                    _0x1ecb2f('div', ls, [
                                        _0x1ecb2f('span', is, _0x310419(_0x2999e0['value']['nickname']), 0x1),
                                        _0x1b94bd['value'] ? (_0x424e5e(), _0x1d638a('span', cs, '在线')) : k('', !0x0)
                                    ])
                                ])) : k('', !0x0)
                            ]),
                            _0x4391d5((_0x424e5e(), _0x1d638a('div', {
                                'class': 'message-list',
                                'ref_key': 'messageContainer',
                                'ref': _0x30e088
                            }, [
                                (_0x424e5e(!0x0), _0x1d638a(_0x31e299, null, _0x5713f1(_0x160b94(_0x24d560)['currentChatMessages'], _0x20ba07 => (_0x424e5e(), _0x1d638a('div', {
                                    'key': _0x20ba07['id'],
                                    'class': _0x36f2e1([
                                        'message-item',
                                        { 'is-mine': _0x20ba07['fromUserId'] === _0x268edb['value'] }
                                    ]),
                                    'onContextmenu': _0x4014e4(_0x3cdfdf => _0x1d1445(_0x3cdfdf, _0x20ba07), ['prevent']),
                                    'onTouchstart': _0x2b78c7 => _0x3557bb(_0x2b78c7, _0x20ba07),
                                    'onTouchend': _0x2b5b68,
                                    'onTouchmove': _0x3b6e82
                                }, [
                                    _0x4cae74(_0x286e7d, {
                                        'size': 0x28,
                                        'src': _0x20ba07['fromUserAvatar'],
                                        'class': 'message-avatar',
                                        'onClick': _0x56b9e6 => _0x24c645(_0x20ba07['fromUserId'])
                                    }, null, 0x8, [
                                        'src',
                                        'onClick'
                                    ]),
                                    _0x1ecb2f('div', ds, [
                                        _0x1ecb2f('div', vs, [
                                            _0x1ecb2f('span', ms, _0x310419(_0x20ba07['fromUserNickname']), 0x1),
                                            _0x1ecb2f('span', fs, _0x310419(_0x160b94(_0x581711)(_0x20ba07['createTime'])), 0x1)
                                        ]),
                                        _0x1ecb2f('div', ps, [_0x20ba07['messageType'] === 0x1 ? (_0x424e5e(), _0x1d638a('div', gs, _0x310419(_0x20ba07['content']), 0x1)) : _0x20ba07['messageType'] === 0x2 ? (_0x424e5e(), _0x5c133c(_0x5097f4, {
                                                'key': 0x1,
                                                'src': _0x20ba07['imageUrl'],
                                                'class': 'image-message',
                                                'fit': 'cover',
                                                'preview-src-list': [_0x20ba07['imageUrl']],
                                                'initial-index': 0x0,
                                                'preview-teleported': ''
                                            }, {
                                                'placeholder': _0x2ab615(() => _0x426ebf[0x2] || (_0x426ebf[0x2] = [_0x1ecb2f('div', { 'class': 'image-loading' }, '加载中...', -0x1)])),
                                                'error': _0x2ab615(() => [_0x1ecb2f('div', _s, [
                                                        _0x4cae74(_0x459487, null, {
                                                            'default': _0x2ab615(() => [_0x4cae74(_0x160b94(_0x3cb96e))]),
                                                            '_': 0x1
                                                        }),
                                                        _0x426ebf[0x3] || (_0x426ebf[0x3] = _0x1ecb2f('span', null, '加载失败', -0x1))
                                                    ])]),
                                                '_': 0x2
                                            }, 0x408, [
                                                'src',
                                                'preview-src-list'
                                            ])) : k('', !0x0)]),
                                        _0x20ba07['fromUserId'] === _0x268edb['value'] ? (_0x424e5e(), _0x1d638a('div', hs, [_0x20ba07['isRead'] === 0x1 ? (_0x424e5e(), _0x1d638a('span', ks, '已读')) : (_0x424e5e(), _0x1d638a('span', ys, '未读'))])) : k('', !0x0)
                                    ])
                                ], 0x2a, us))), 0x80)),
                                _0x5931be['value'] ? (_0x424e5e(), _0x1d638a('div', Cs, [_0x1ecb2f('span', null, _0x310419(_0x5931be['value']), 0x1)])) : k('', !0x0),
                                _0x160b94(_0x24d560)['currentChatMessages']['length'] === 0x0 && !_0xdbdb20['value'] ? (_0x424e5e(), _0x5c133c(_0x5463ac, {
                                    'key': 0x1,
                                    'description': '暂无消息'
                                })) : k('', !0x0)
                            ])), [[
                                    _0x299124,
                                    _0xdbdb20['value']
                                ]]),
                            _0x3a8ff7['value'] ? (_0x424e5e(), _0x1d638a('div', {
                                'key': 0x0,
                                'class': 'context-menu',
                                'style': _0x34b02a({
                                    'left': _0x695fd['value']['x'] + 'px',
                                    'top': _0x695fd['value']['y'] + 'px'
                                })
                            }, [
                                _0x5a7f50['value'] && _0x5a7f50['value']['messageType'] === 0x1 ? (_0x424e5e(), _0x1d638a('div', {
                                    'key': 0x0,
                                    'class': 'context-menu-item',
                                    'onClick': _0x4100ec
                                }, [
                                    _0x4cae74(_0x459487, null, {
                                        'default': _0x2ab615(() => [_0x4cae74(_0x160b94(_0x128643))]),
                                        '_': 0x1
                                    }),
                                    _0x426ebf[0x4] || (_0x426ebf[0x4] = _0x1ecb2f('span', null, '复制', -0x1))
                                ])) : k('', !0x0),
                                _0x110cad(_0x5a7f50['value']) ? (_0x424e5e(), _0x1d638a('div', {
                                    'key': 0x1,
                                    'class': 'context-menu-item',
                                    'onClick': _0x3c9e84
                                }, [
                                    _0x4cae74(_0x459487, null, {
                                        'default': _0x2ab615(() => [_0x4cae74(_0x160b94(_0x4afe8b))]),
                                        '_': 0x1
                                    }),
                                    _0x426ebf[0x5] || (_0x426ebf[0x5] = _0x1ecb2f('span', null, '撤回消息', -0x1))
                                ])) : k('', !0x0)
                            ], 0x4)) : k('', !0x0),
                            _0x1ecb2f('div', Es, [
                                _0x4cae74(_0x93e2cc, {
                                    'ref_key': 'messageInput',
                                    'ref': _0x52b98b,
                                    'modelValue': _0x1fbef6['value'],
                                    'onUpdate:modelValue': _0x426ebf[0x1] || (_0x426ebf[0x1] = _0x6ba806 => _0x1fbef6['value'] = _0x6ba806),
                                    'type': 'textarea',
                                    'rows': 0x3,
                                    'placeholder': '请输入消息...',
                                    'onKeydown': _0x266e3f(_0x4014e4(_0x526901, ['ctrl']), ['enter']),
                                    'resize': 'none'
                                }, null, 0x8, [
                                    'modelValue',
                                    'onKeydown'
                                ]),
                                _0x1ecb2f('div', Us, [
                                    _0x1ecb2f('div', Ss, [
                                        _0x4cae74(_0x29dae6, {
                                            'icon': _0x160b94(_0x577855),
                                            'onClick': _0x5f8665
                                        }, {
                                            'default': _0x2ab615(() => _0x426ebf[0x6] || (_0x426ebf[0x6] = [_0x2eac59('表情')])),
                                            '_': 0x1,
                                            '__': [0x6]
                                        }, 0x8, ['icon']),
                                        _0x4cae74(_0x29dae6, {
                                            'icon': _0x160b94(_0x3cb96e),
                                            'onClick': _0x5b1def,
                                            'loading': _0x1ee0ad['value']
                                        }, {
                                            'default': _0x2ab615(() => _0x426ebf[0x7] || (_0x426ebf[0x7] = [_0x2eac59('图片')])),
                                            '_': 0x1,
                                            '__': [0x7]
                                        }, 0x8, [
                                            'icon',
                                            'loading'
                                        ])
                                    ]),
                                    _0x4cae74(_0x29dae6, {
                                        'type': 'primary',
                                        'onClick': _0x526901
                                    }, {
                                        'default': _0x2ab615(() => _0x426ebf[0x8] || (_0x426ebf[0x8] = [_0x2eac59('发送\x20(Ctrl+Enter)')])),
                                        '_': 0x1,
                                        '__': [0x8]
                                    })
                                ]),
                                _0x4391d5(_0x1ecb2f('div', Ts, [
                                    _0x1ecb2f('div', Ms, [
                                        _0x426ebf[0x9] || (_0x426ebf[0x9] = _0x1ecb2f('span', { 'class': 'emoji-title' }, '选择表情', -0x1)),
                                        _0x4cae74(_0x29dae6, {
                                            'text': '',
                                            'icon': _0x160b94(_0x39c579),
                                            'onClick': _0x1900b0
                                        }, null, 0x8, ['icon'])
                                    ]),
                                    _0x1ecb2f('div', xs, [(_0x424e5e(!0x0), _0x1d638a(_0x31e299, null, _0x5713f1(_0x160b94(es), (_0x425159, _0x19acc4) => (_0x424e5e(), _0x1d638a('div', {
                                            'key': _0x19acc4,
                                            'class': 'emoji-item',
                                            'onClick': _0x7de58c => _0x9e6fbf(_0x425159)
                                        }, _0x310419(_0x425159), 0x9, Is))), 0x80))])
                                ], 0x200), [[
                                        _0x1be939,
                                        _0xe7a0b['value']
                                    ]])
                            ])
                        ])])]);
            };
        }
    }, st = _0x537265(ws, [[
            '__scopeId',
            'data-v-f8ae4ca3'
        ]]);
export {
    st as default
};