const _0x2919ac = (function () {
        let _0xd2bff1 = !![];
        return function (_0x1c85a2, _0x576ef1) {
            const _0x3be93d = _0xd2bff1 ? function () {
                if (_0x576ef1) {
                    const _0x2381de = _0x576ef1['apply'](_0x1c85a2, arguments);
                    return _0x576ef1 = null, _0x2381de;
                }
            } : function () {
            };
            return _0xd2bff1 = ![], _0x3be93d;
        };
    }()), _0x2668b5 = _0x2919ac(this, function () {
        let _0x42357d;
        try {
            const _0x2ecbc5 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x42357d = _0x2ecbc5();
        } catch (_0x5a4a09) {
            _0x42357d = window;
        }
        const _0x40d385 = _0x42357d['console'] = _0x42357d['console'] || {}, _0x29426a = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x267ea1 = 0x0; _0x267ea1 < _0x29426a['length']; _0x267ea1++) {
            const _0xb7e6c8 = _0x2919ac['constructor']['prototype']['bind'](_0x2919ac), _0x88180a = _0x29426a[_0x267ea1], _0x947fc0 = _0x40d385[_0x88180a] || _0xb7e6c8;
            _0xb7e6c8['__proto__'] = _0x2919ac['bind'](_0x2919ac), _0xb7e6c8['toString'] = _0x947fc0['toString']['bind'](_0x947fc0), _0x40d385[_0x88180a] = _0xb7e6c8;
        }
    });
_0x2668b5();
import {
    h as _0xb0735f,
    i as _0x4b3caf,
    c as _0x14be99,
    d as _0x156341,
    j as _0x242277,
    _ as _0x243827,
    e as _0x33f77b,
    k as _0x411827,
    a as _0x3daed3,
    w as _0x36dce2,
    u as _0x36b8f2,
    b as _0xb9c4ad
} from './Request-CHKnUlo5.js';
import {
    a as _0x4c14d1,
    E as _0xf29fcf
} from './el-form-item-CE_gZaOe.js';
import { E as _0x4601c0 } from './el-input-D-8X7_j3.js';
import { E as _0x5354e0 } from './el-dialog-BYTqBsxC.js';
import './el-overlay-D3x7h4La.js';
import { E as _0x532f36 } from './el-progress-B4GATlkk.js';
import { E as _0x3ec930 } from './el-card-BzXeyFZ5.js';
import { E as _0x4c3aeb } from './el-empty-o9RgIX3C.js';
import { E as _0x94eddc } from './el-image-viewer-DAjDHmiI.js';
import { E as _0x4683d4 } from './el-checkbox-BJJ8EuQN.js';
import {
    V as _0x4a25e5,
    X as _0x132f7c,
    Y as _0x3d6fe1,
    r as _0x39c53d,
    w as _0x5d23a6,
    o as _0x29bd36,
    c as _0xe6c382,
    b as _0x2628af,
    g as _0x439656,
    k as _0x131db9,
    l as _0x466aff,
    m as _0x217eb4,
    z as _0x33018b,
    e as _0x3fb169,
    f as _0x24279a,
    ak as _0x2982d6,
    t as _0x3401ef,
    a2 as _0x5eebec,
    d as _0x5cf902,
    P as _0x516c9c,
    $ as _0x147459,
    C as _0x1a6896,
    a4 as _0x8de43e,
    al as _0x4edc4f,
    _ as _0x3e4286,
    E as _0x336e2b,
    s as _0x210ab6,
    u as _0x240ee0,
    i as _0x115486,
    aj as _0x4241b2,
    F as _0x145d65,
    G as _0x2dfdca,
    j as _0x163bcf,
    A as _0x3a1940,
    B as _0x507375
} from './index-54DmW9hq.js';
import {
    a as _0xc69fad,
    b as _0x56c1be,
    c as _0x5a7fac,
    u as _0x34ae83,
    E as _0x9363df
} from './el-button-D6wSrR74.js';
import {
    E as _0x499952,
    a as _0x555efd,
    b as _0x1aba78
} from './el-dropdown-item-CXWV75Wk.js';
import './el-scrollbar-BcrgDlEt.js';
import { E as _0x3fa598 } from './el-text-CbMl16cr.js';
import {
    g as _0x1b3c23,
    b as _0x345afb,
    d as _0xa214ab,
    u as _0x4603af,
    e as _0x1c8406
} from './album-BHCMrxkD.js';
import {
    b as _0x383492,
    u as _0x53e4d2
} from './photo-U6egaMYg.js';
import { c as _0x1384c6 } from './PhotoUtils-D97xGs8w.js';
import {
    i as _0x1045ca,
    E as _0x2151ab
} from './index-DbtH6USO.js';
import {
    u as _0x1825e8,
    t as _0x553cd1,
    d as _0xd0e569
} from './index-DMxv2JmO.js';
import {
    I as _0x55a1c0,
    C as _0x3f4870,
    U as _0x16b3b2
} from './event-BB_Ol6Sd.js';
import './castArray-BGw1D6E-.js';
import './aria-DyaK1nXM.js';
import './_baseClone-DoJvIJg4.js';
import './index-ijNW1fhk.js';
import './focus-trap-Cbj9GFlW.js';
import './index-BLYrTdqd.js';
import './refs-mENLc3Ek.js';
import './vnode-C3QoD07S.js';
import './scroll-DDB7nuLj.js';
import './toNumber-DGNxa_rg.js';
import './index-BOok6G7G.js';
const na = _0x14be99({
        'modelValue': {
            'type': [
                Boolean,
                String,
                Number
            ],
            'default': !0x1
        },
        'disabled': Boolean,
        'loading': Boolean,
        'size': {
            'type': String,
            'validator': _0x1045ca
        },
        'width': {
            'type': [
                String,
                Number
            ],
            'default': ''
        },
        'inlinePrompt': Boolean,
        'inactiveActionIcon': { 'type': _0x242277 },
        'activeActionIcon': { 'type': _0x242277 },
        'activeIcon': { 'type': _0x242277 },
        'inactiveIcon': { 'type': _0x242277 },
        'activeText': {
            'type': String,
            'default': ''
        },
        'inactiveText': {
            'type': String,
            'default': ''
        },
        'activeValue': {
            'type': [
                Boolean,
                String,
                Number
            ],
            'default': !0x0
        },
        'inactiveValue': {
            'type': [
                Boolean,
                String,
                Number
            ],
            'default': !0x1
        },
        'name': {
            'type': String,
            'default': ''
        },
        'validateEvent': {
            'type': Boolean,
            'default': !0x0
        },
        'beforeChange': { 'type': _0x156341(Function) },
        'id': String,
        'tabindex': {
            'type': [
                String,
                Number
            ]
        },
        ..._0x1825e8(['ariaLabel'])
    }), ia = {
        [_0x16b3b2]: _0x9da34e => _0xb0735f(_0x9da34e) || _0x4a25e5(_0x9da34e) || _0x4b3caf(_0x9da34e),
        [_0x3f4870]: _0x2256b2 => _0xb0735f(_0x2256b2) || _0x4a25e5(_0x2256b2) || _0x4b3caf(_0x2256b2),
        [_0x55a1c0]: _0x2453a5 => _0xb0735f(_0x2453a5) || _0x4a25e5(_0x2453a5) || _0x4b3caf(_0x2453a5)
    }, Te = 'ElSwitch', ra = _0x132f7c({ 'name': Te }), ua = _0x132f7c({
        ...ra,
        'props': na,
        'emits': ia,
        'setup'(_0x5576aa, {
            expose: _0x125ebb,
            emit: _0x5efe13
        }) {
            const _0x41d10b = _0x5576aa, {formItem: _0x4eb891} = _0xc69fad(), _0x3f0140 = _0x56c1be(), _0x90e9ed = _0x33f77b('switch'), {inputId: _0x38797f} = _0x5a7fac(_0x41d10b, { 'formItemContext': _0x4eb891 }), _0x379d07 = _0x34ae83(_0x3d6fe1(() => _0x41d10b['loading'])), _0x347553 = _0x39c53d(_0x41d10b['modelValue'] !== !0x1), _0x203d4f = _0x39c53d(), _0x27d96d = _0x39c53d(), _0x401c1d = _0x3d6fe1(() => [
                    _0x90e9ed['b'](),
                    _0x90e9ed['m'](_0x3f0140['value']),
                    _0x90e9ed['is']('disabled', _0x379d07['value']),
                    _0x90e9ed['is']('checked', _0x266250['value'])
                ]), _0x1aa55f = _0x3d6fe1(() => [
                    _0x90e9ed['e']('label'),
                    _0x90e9ed['em']('label', 'left'),
                    _0x90e9ed['is']('active', !_0x266250['value'])
                ]), _0x11472b = _0x3d6fe1(() => [
                    _0x90e9ed['e']('label'),
                    _0x90e9ed['em']('label', 'right'),
                    _0x90e9ed['is']('active', _0x266250['value'])
                ]), _0x2d2778 = _0x3d6fe1(() => ({ 'width': _0x411827(_0x41d10b['width']) }));
            _0x5d23a6(() => _0x41d10b['modelValue'], () => {
                _0x347553['value'] = !0x0;
            });
            const _0x1bce1e = _0x3d6fe1(() => _0x347553['value'] ? _0x41d10b['modelValue'] : !0x1), _0x266250 = _0x3d6fe1(() => _0x1bce1e['value'] === _0x41d10b['activeValue']);
            [
                _0x41d10b['activeValue'],
                _0x41d10b['inactiveValue']
            ]['includes'](_0x1bce1e['value']) || (_0x5efe13(_0x16b3b2, _0x41d10b['inactiveValue']), _0x5efe13(_0x3f4870, _0x41d10b['inactiveValue']), _0x5efe13(_0x55a1c0, _0x41d10b['inactiveValue'])), _0x5d23a6(_0x266250, _0x5c4514 => {
                var _0x3e396a;
                _0x203d4f['value']['checked'] = _0x5c4514, _0x41d10b['validateEvent'] && ((_0x3e396a = _0x4eb891 == null ? void 0x0 : _0x4eb891['validate']) == null || _0x3e396a['call'](_0x4eb891, 'change')['catch'](_0x1b72a3 => _0xd0e569()));
            });
            const _0x1a2b8d = () => {
                    const _0xacfd96 = _0x266250['value'] ? _0x41d10b['inactiveValue'] : _0x41d10b['activeValue'];
                    _0x5efe13(_0x16b3b2, _0xacfd96), _0x5efe13(_0x3f4870, _0xacfd96), _0x5efe13(_0x55a1c0, _0xacfd96), _0x8de43e(() => {
                        _0x203d4f['value']['checked'] = _0x266250['value'];
                    });
                }, _0x13e495 = () => {
                    if (_0x379d07['value'])
                        return;
                    const {beforeChange: _0x51c222} = _0x41d10b;
                    if (!_0x51c222) {
                        _0x1a2b8d();
                        return;
                    }
                    const _0x1092c8 = _0x51c222();
                    [
                        _0x4edc4f(_0x1092c8),
                        _0xb0735f(_0x1092c8)
                    ]['includes'](!0x0) || _0x553cd1(Te, 'beforeChange\x20must\x20return\x20type\x20`Promise<boolean>`\x20or\x20`boolean`'), _0x4edc4f(_0x1092c8) ? _0x1092c8['then'](_0xb0b1df => {
                        _0xb0b1df && _0x1a2b8d();
                    })['catch'](_0x10f092 => {
                    }) : _0x1092c8 && _0x1a2b8d();
                }, _0x2d2773 = () => {
                    var _0x3388ea, _0x2faed1;
                    (_0x2faed1 = (_0x3388ea = _0x203d4f['value']) == null ? void 0x0 : _0x3388ea['focus']) == null || _0x2faed1['call'](_0x3388ea);
                };
            return _0x29bd36(() => {
                _0x203d4f['value']['checked'] = _0x266250['value'];
            }), _0x125ebb({
                'focus': _0x2d2773,
                'checked': _0x266250
            }), (_0x84316c, _0x181cd8) => (_0x2628af(), _0xe6c382('div', {
                'class': _0x33018b(_0x217eb4(_0x401c1d)),
                'onClick': _0x1a6896(_0x13e495, ['prevent'])
            }, [
                _0x439656('input', {
                    'id': _0x217eb4(_0x38797f),
                    'ref_key': 'input',
                    'ref': _0x203d4f,
                    'class': _0x33018b(_0x217eb4(_0x90e9ed)['e']('input')),
                    'type': 'checkbox',
                    'role': 'switch',
                    'aria-checked': _0x217eb4(_0x266250),
                    'aria-disabled': _0x217eb4(_0x379d07),
                    'aria-label': _0x84316c['ariaLabel'],
                    'name': _0x84316c['name'],
                    'true-value': _0x84316c['activeValue'],
                    'false-value': _0x84316c['inactiveValue'],
                    'disabled': _0x217eb4(_0x379d07),
                    'tabindex': _0x84316c['tabindex'],
                    'onChange': _0x1a2b8d,
                    'onKeydown': _0x466aff(_0x13e495, ['enter'])
                }, null, 0x2a, [
                    'id',
                    'aria-checked',
                    'aria-disabled',
                    'aria-label',
                    'name',
                    'true-value',
                    'false-value',
                    'disabled',
                    'tabindex',
                    'onKeydown'
                ]),
                !_0x84316c['inlinePrompt'] && (_0x84316c['inactiveIcon'] || _0x84316c['inactiveText']) ? (_0x2628af(), _0xe6c382('span', {
                    'key': 0x0,
                    'class': _0x33018b(_0x217eb4(_0x1aa55f))
                }, [
                    _0x84316c['inactiveIcon'] ? (_0x2628af(), _0x3fb169(_0x217eb4(_0x3daed3), { 'key': 0x0 }, {
                        'default': _0x24279a(() => [(_0x2628af(), _0x3fb169(_0x2982d6(_0x84316c['inactiveIcon'])))]),
                        '_': 0x1
                    })) : _0x131db9('v-if', !0x0),
                    !_0x84316c['inactiveIcon'] && _0x84316c['inactiveText'] ? (_0x2628af(), _0xe6c382('span', {
                        'key': 0x1,
                        'aria-hidden': _0x217eb4(_0x266250)
                    }, _0x3401ef(_0x84316c['inactiveText']), 0x9, ['aria-hidden'])) : _0x131db9('v-if', !0x0)
                ], 0x2)) : _0x131db9('v-if', !0x0),
                _0x439656('span', {
                    'ref_key': 'core',
                    'ref': _0x27d96d,
                    'class': _0x33018b(_0x217eb4(_0x90e9ed)['e']('core')),
                    'style': _0x147459(_0x217eb4(_0x2d2778))
                }, [
                    _0x84316c['inlinePrompt'] ? (_0x2628af(), _0xe6c382('div', {
                        'key': 0x0,
                        'class': _0x33018b(_0x217eb4(_0x90e9ed)['e']('inner'))
                    }, [_0x84316c['activeIcon'] || _0x84316c['inactiveIcon'] ? (_0x2628af(), _0x3fb169(_0x217eb4(_0x3daed3), {
                            'key': 0x0,
                            'class': _0x33018b(_0x217eb4(_0x90e9ed)['is']('icon'))
                        }, {
                            'default': _0x24279a(() => [(_0x2628af(), _0x3fb169(_0x2982d6(_0x217eb4(_0x266250) ? _0x84316c['activeIcon'] : _0x84316c['inactiveIcon'])))]),
                            '_': 0x1
                        }, 0x8, ['class'])) : _0x84316c['activeText'] || _0x84316c['inactiveText'] ? (_0x2628af(), _0xe6c382('span', {
                            'key': 0x1,
                            'class': _0x33018b(_0x217eb4(_0x90e9ed)['is']('text')),
                            'aria-hidden': !_0x217eb4(_0x266250)
                        }, _0x3401ef(_0x217eb4(_0x266250) ? _0x84316c['activeText'] : _0x84316c['inactiveText']), 0xb, ['aria-hidden'])) : _0x131db9('v-if', !0x0)], 0x2)) : _0x131db9('v-if', !0x0),
                    _0x439656('div', { 'class': _0x33018b(_0x217eb4(_0x90e9ed)['e']('action')) }, [_0x84316c['loading'] ? (_0x2628af(), _0x3fb169(_0x217eb4(_0x3daed3), {
                            'key': 0x0,
                            'class': _0x33018b(_0x217eb4(_0x90e9ed)['is']('loading'))
                        }, {
                            'default': _0x24279a(() => [_0x5cf902(_0x217eb4(_0x516c9c))]),
                            '_': 0x1
                        }, 0x8, ['class'])) : _0x217eb4(_0x266250) ? _0x5eebec(_0x84316c['$slots'], 'active-action', { 'key': 0x1 }, () => [_0x84316c['activeActionIcon'] ? (_0x2628af(), _0x3fb169(_0x217eb4(_0x3daed3), { 'key': 0x0 }, {
                                'default': _0x24279a(() => [(_0x2628af(), _0x3fb169(_0x2982d6(_0x84316c['activeActionIcon'])))]),
                                '_': 0x1
                            })) : _0x131db9('v-if', !0x0)]) : _0x217eb4(_0x266250) ? _0x131db9('v-if', !0x0) : _0x5eebec(_0x84316c['$slots'], 'inactive-action', { 'key': 0x2 }, () => [_0x84316c['inactiveActionIcon'] ? (_0x2628af(), _0x3fb169(_0x217eb4(_0x3daed3), { 'key': 0x0 }, {
                                'default': _0x24279a(() => [(_0x2628af(), _0x3fb169(_0x2982d6(_0x84316c['inactiveActionIcon'])))]),
                                '_': 0x1
                            })) : _0x131db9('v-if', !0x0)])], 0x2)
                ], 0x6),
                !_0x84316c['inlinePrompt'] && (_0x84316c['activeIcon'] || _0x84316c['activeText']) ? (_0x2628af(), _0xe6c382('span', {
                    'key': 0x1,
                    'class': _0x33018b(_0x217eb4(_0x11472b))
                }, [
                    _0x84316c['activeIcon'] ? (_0x2628af(), _0x3fb169(_0x217eb4(_0x3daed3), { 'key': 0x0 }, {
                        'default': _0x24279a(() => [(_0x2628af(), _0x3fb169(_0x2982d6(_0x84316c['activeIcon'])))]),
                        '_': 0x1
                    })) : _0x131db9('v-if', !0x0),
                    !_0x84316c['activeIcon'] && _0x84316c['activeText'] ? (_0x2628af(), _0xe6c382('span', {
                        'key': 0x1,
                        'aria-hidden': !_0x217eb4(_0x266250)
                    }, _0x3401ef(_0x84316c['activeText']), 0x9, ['aria-hidden'])) : _0x131db9('v-if', !0x0)
                ], 0x2)) : _0x131db9('v-if', !0x0)
            ], 0xa, ['onClick']));
        }
    });
var ca = _0x243827(ua, [[
        '__file',
        'switch.vue'
    ]]);
const da = _0x36dce2(ca), va = { 'class': 'header-title' }, ma = { 'class': 'album-name-container' }, pa = {
        'key': 0x0,
        'class': 'user-name-container'
    }, fa = {
        'key': 0x0,
        'class': 'header-actions'
    }, ha = {
        'key': 0x1,
        'class': 'header-select'
    }, ga = { 'class': 'photo-container' }, _a = { 'class': 'date-header' }, ya = { 'class': 'photo-grid' }, wa = ['onClick'], ba = { 'class': 'error' }, ka = { 'key': 0x1 }, Ca = { 'class': 'preview-container' }, Ea = { 'class': 'error' }, Ia = { 'class': 'dialog-footer' }, Sa = { 'class': 'dialog-footer' }, Va = { 'class': 'cover-selection-container' }, Ua = ['onClick'], Pa = {
        '__name': 'AlbumDetail',
        'setup'(_0x23e281) {
            const {URL: _0x44d820} = window, _0x5f4e1a = _0x336e2b(), _0x49a23b = _0x240ee0(), _0x3f2aa8 = _0x39c53d(!0x1), _0x4d2989 = Number(_0x5f4e1a['params']['albumId']), _0x19a59f = _0x39c53d({
                    'id': _0x4d2989,
                    'name': '',
                    'coverUrl': '',
                    'showStatus': 0x0,
                    'createTime': '',
                    'userId': '',
                    'userName': ''
                }), _0xc06d81 = _0x36b8f2(), {user: _0x4dc149} = _0x210ab6(_0xc06d81), _0x30f8bb = _0x39c53d([]), _0x4b030c = async () => {
                    _0x3f2aa8['value'] = !0x0;
                    try {
                        const _0x14ada9 = await _0x1b3c23(_0x19a59f['value']['id']);
                        _0x30f8bb['value'] = _0x14ada9['data']['data']['photos'] || [], _0x19a59f['value']['showStatus'] = _0x14ada9['data']['data']['showStatus'] || 0x0, _0x19a59f['value']['name'] = _0x14ada9['data']['data']['name'] || '', _0x19a59f['value']['coverUrl'] = _0x14ada9['data']['data']['coverUrl'] || '', _0x19a59f['value']['userName'] = _0x14ada9['data']['data']['userName'] || '', _0x19a59f['value']['userId'] = _0x14ada9['data']['data']['userId'] || '', _0x1187b4();
                    } catch {
                        _0xb9c4ad['error']('获取相册图片失败');
                    } finally {
                        _0x3f2aa8['value'] = !0x1;
                    }
                };
            _0x29bd36(() => {
                _0x4b030c();
            });
            const _0x4cd968 = _0x3d6fe1(() => _0x19a59f['value']['showStatus'] === 0x0), _0x5b1672 = _0x3d6fe1(() => {
                    if (!_0x4dc149['value'])
                        return !0x1;
                    const _0x21c0fe = _0x4dc149['value']['id'], _0x5b3c9a = _0x19a59f['value']['userId'];
                    return _0x21c0fe && _0x5b3c9a && _0x21c0fe === _0x5b3c9a;
                }), _0x4a5db8 = _0x39c53d({}), _0x1187b4 = () => {
                    const _0x217b9e = {};
                    [..._0x30f8bb['value']]['sort']((_0x545880, _0x57037c) => new Date(_0x57037c['createTime']) - new Date(_0x545880['createTime']))['forEach'](_0x4ec3f1 => {
                        const _0x1f03f3 = _0x4ec3f1['createTime']['split']('\x20')[0x0];
                        _0x217b9e[_0x1f03f3] || (_0x217b9e[_0x1f03f3] = []), _0x217b9e[_0x1f03f3]['push'](_0x4ec3f1);
                    }), _0x4a5db8['value'] = _0x217b9e;
                }, _0x4009fe = _0x15eeeb => {
                    const _0x35d942 = _0x2dee12()[_0x15eeeb], _0xdbb5dc = _0x35d942['slice'](_0x35d942['lastIndexOf']('.')), _0x3e317e = Date['now']() + _0xdbb5dc;
                    fetch(_0x35d942)['then'](_0x1e5889 => _0x1e5889['blob']())['then'](_0x3b815d => {
                        const _0x37dc6e = _0x44d820['createObjectURL'](new Blob([_0x3b815d])), _0xf1f7ca = document['createElement']('a');
                        _0xf1f7ca['href'] = _0x37dc6e, _0xf1f7ca['download'] = _0x3e317e, document['body']['appendChild'](_0xf1f7ca), _0xf1f7ca['click'](), _0x44d820['revokeObjectURL'](_0x37dc6e), _0xf1f7ca['remove']();
                    });
                }, _0x5f45e9 = _0x39c53d(!0x1), _0x924206 = _0x39c53d(!0x1), _0x46b87c = _0x39c53d([]), _0x4f1633 = _0x39c53d({}), _0x4d7a87 = () => {
                    if (_0x5f45e9['value'] = !_0x5f45e9['value'], !_0x5f45e9['value'])
                        _0x46b87c['value'] = [], _0x924206['value'] = !0x1, _0x4f1633['value'] = {};
                    else {
                        for (const _0x21de20 in _0x4a5db8['value'])
                            _0x4f1633['value'][_0x21de20] = !0x1;
                    }
                }, _0x1b0815 = _0x167bf3 => {
                    const _0x23fbbd = _0x4a5db8['value'][_0x167bf3];
                    _0x4f1633['value'][_0x167bf3] ? _0x23fbbd['forEach'](_0x203b9e => {
                        _0x46b87c['value']['includes'](_0x203b9e['id']) || _0x46b87c['value']['push'](_0x203b9e['id']);
                    }) : _0x46b87c['value'] = _0x46b87c['value']['filter'](_0x218f55 => !_0x23fbbd['some'](_0x48c4a5 => _0x48c4a5['id'] === _0x218f55)), _0x3f186d();
                }, _0x21faac = () => {
                    if (_0x924206['value'] = !_0x924206['value'], _0x924206['value']) {
                        _0x46b87c['value'] = [];
                        for (const _0x780d3f in _0x4a5db8['value'])
                            _0x4a5db8['value'][_0x780d3f]['forEach'](_0x314aeb => {
                                _0x46b87c['value']['push'](_0x314aeb['id']);
                            }), _0x4f1633['value'][_0x780d3f] = !0x0;
                    } else {
                        _0x46b87c['value'] = [];
                        for (const _0xfb2bef in _0x4a5db8['value'])
                            _0x4f1633['value'][_0xfb2bef] = !0x1;
                    }
                }, _0x3f186d = () => {
                    let _0x1637f0 = !0x0;
                    for (const _0x5e5c59 in _0x4a5db8['value']) {
                        const _0x3fc4ae = _0x4a5db8['value'][_0x5e5c59]['every'](_0x2526c4 => _0x46b87c['value']['includes'](_0x2526c4['id']));
                        _0x3fc4ae || (_0x1637f0 = !0x1), _0x4f1633['value'][_0x5e5c59] = _0x3fc4ae;
                    }
                    _0x924206['value'] = _0x1637f0;
                }, _0x130d9b = _0xe8d6a2 => {
                    if (!_0x5f45e9['value'])
                        return;
                    const _0x37fac4 = _0x46b87c['value']['indexOf'](_0xe8d6a2['id']);
                    _0x37fac4 === -0x1 ? _0x46b87c['value']['push'](_0xe8d6a2['id']) : _0x46b87c['value']['splice'](_0x37fac4, 0x1);
                }, _0x5ed859 = () => {
                    if (_0x46b87c['value']['length'] === 0x0) {
                        _0xb9c4ad['warning']('请先选择要删除的图片');
                        return;
                    }
                    _0x2151ab['confirm']('确定要删除这\x20' + _0x46b87c['value']['length'] + '\x20张图片吗？此操作不可恢复', '删除图片', {
                        'confirmButtonText': '确定',
                        'cancelButtonText': '取消',
                        'type': 'warning'
                    })['then'](async () => {
                        try {
                            await _0x383492(_0x46b87c['value']), _0xb9c4ad['success']('删除成功'), _0x46b87c['value'] = [], _0x4b030c();
                        } catch {
                            _0xb9c4ad['error']('删除失败');
                        }
                    })['catch'](() => {
                        _0xb9c4ad['info']('已取消删除');
                    });
                }, _0x17dea9 = _0x39c53d(!0x1), _0xe07902 = _0x39c53d([]), _0x33ee0b = () => {
                    _0xe07902['value'] = [], _0x17dea9['value'] = !0x0;
                }, _0x45482e = (_0x1c0784, _0x1bcf90) => {
                    _0xe07902['value'] = _0x1bcf90;
                }, _0x5db39b = _0x39c53d(!0x1), _0x482cbb = async () => {
                    if (_0xe07902['value']['length'] === 0x0) {
                        _0xb9c4ad['warning']('请选择要上传的图片');
                        return;
                    }
                    _0x5db39b['value'] = !0x0;
                    try {
                        const _0x23384c = [];
                        for (const _0x4c5367 of _0xe07902['value']) {
                            const _0x3d7a7f = await _0x1384c6(_0x4c5367['raw']);
                            _0x23384c['push'](_0x3d7a7f);
                        }
                        const _0x1cbed2 = _0x23384c['map'](_0x369d6d => _0x53e4d2(_0x369d6d, _0x19a59f['value']['id']));
                        await Promise['all'](_0x1cbed2), _0xb9c4ad['success']('图片上传成功'), _0x17dea9['value'] = !0x1, setTimeout(() => {
                            _0x4b030c();
                        }, 0x7d0);
                    } catch {
                        _0xb9c4ad['error']('上传图片失败');
                    } finally {
                        _0x5db39b['value'] = !0x1;
                    }
                }, _0xa33fb0 = _0x39c53d(!0x1), _0x1e466d = _0x39c53d(!0x1), _0x58bb43 = () => {
                    _0xa33fb0['value'] = !0x0;
                }, _0x5e953b = async () => {
                    if (!_0x19a59f['value']['name']) {
                        _0xb9c4ad['warning']('请输入相册名称');
                        return;
                    }
                    _0x1e466d['value'] = !0x0;
                    try {
                        await _0x4603af(_0x19a59f['value']), _0xb9c4ad['success']('编辑相册成功'), _0xa33fb0['value'] = !0x1, _0x1b3c23(_0x19a59f['value']['id']);
                    } catch {
                        _0xb9c4ad['error']('编辑相册失败');
                    } finally {
                        _0x1e466d['value'] = !0x1;
                    }
                }, _0x1c25fd = () => {
                    _0x2151ab['confirm']('确定要删除这个相册吗？此操作不可恢复', '删除相册', {
                        'confirmButtonText': '确定',
                        'cancelButtonText': '取消',
                        'type': 'warning'
                    })['then'](async () => {
                        try {
                            await _0xa214ab(_0x19a59f['value']['id']), _0xb9c4ad['success']('删除相册成功'), _0x49a23b['push']('/album');
                        } catch {
                            _0xb9c4ad['error']('删除相册失败');
                        }
                    })['catch'](() => {
                        _0xb9c4ad['info']('已取消删除');
                    });
                }, _0x40dcdb = async () => {
                    try {
                        const _0x22bad9 = _0x19a59f['value']['showStatus'] === 0x0 ? 0x1 : 0x0, _0x1125b9 = {
                                'id': _0x19a59f['value']['id'],
                                'showStatus': _0x22bad9
                            };
                        await _0x345afb(_0x1125b9), _0x19a59f['value']['showStatus'] = _0x22bad9, _0xb9c4ad['success']('修改相册状态成功');
                    } catch (_0x529a81) {
                        console['error']('修改相册状态失败:', _0x529a81), _0xb9c4ad['error']('修改相册状态失败');
                    }
                }, _0x3b614c = _0x39c53d(!0x1), _0x432d7b = _0x39c53d(''), _0x214225 = _0x39c53d([]), _0x2e9bfa = async () => {
                    try {
                        const _0x3ca9a2 = await _0x1b3c23(_0x4d2989);
                        if (!(_0x3ca9a2 != null && _0x3ca9a2['data'])) {
                            _0xb9c4ad['error']('获取相册详情失败');
                            return;
                        }
                        const _0x155174 = _0x3ca9a2['data']['data']['photos'];
                        if (!_0x155174 || _0x155174['length'] === 0x0) {
                            _0xb9c4ad['warning']('该相册暂无图片，请先上传图片');
                            return;
                        }
                        _0x214225['value'] = [..._0x155174]['reverse'](), _0x432d7b['value'] = '', _0x3b614c['value'] = !0x0;
                    } catch {
                        _0xb9c4ad['error']('更换封面失败');
                    }
                }, _0xe59f75 = async () => {
                    if (!_0x432d7b['value']) {
                        _0xb9c4ad['warning']('请选择一张图片作为封面');
                        return;
                    }
                    try {
                        const _0x4e94fa = {
                            'id': _0x4d2989,
                            'coverUrl': _0x432d7b['value']
                        };
                        await _0x1c8406(_0x4e94fa), _0xb9c4ad['success']('更换封面成功'), _0x1b3c23(_0x4d2989), _0x19a59f['value']['coverUrl'] = _0x432d7b['value'], _0x3b614c['value'] = !0x1;
                    } catch {
                        _0xb9c4ad['error']('更换封面失败');
                    }
                }, _0x5039d3 = () => {
                    _0x49a23b['go'](-0x1);
                }, _0x2dee12 = () => {
                    const _0xf3dd18 = [];
                    for (const _0x32fae1 in _0x4a5db8['value'])
                        _0x4a5db8['value'][_0x32fae1]['forEach'](_0x1aabd3 => {
                            _0xf3dd18['push'](_0x1aabd3['url']);
                        });
                    return _0xf3dd18;
                }, _0x35c624 = _0x256819 => {
                    const _0x203c31 = [];
                    for (const _0x1a7274 in _0x4a5db8['value']) {
                        const _0x2e5503 = _0x4a5db8['value'][_0x1a7274];
                        _0x203c31['push'](..._0x2e5503);
                    }
                    return _0x203c31['findIndex'](_0x5f5e80 => _0x5f5e80['id'] === _0x256819['id']);
                }, _0x1c48c7 = _0x428b0b => {
                    switch (_0x428b0b) {
                    case 0x0:
                        return '待审核';
                    case 0x1:
                        return;
                    case 0x2:
                        return '审核未通过';
                    default:
                        return '未知状态';
                    }
                }, _0x1f68bf = _0x3318c4 => {
                    switch (_0x3318c4) {
                    case 0x0:
                        return 'status-pending';
                    case 0x1:
                        return 'status-approved';
                    case 0x2:
                        return 'status-rejected';
                    default:
                        return 'status-unknown';
                    }
                };
            return (_0x17d931, _0xb3be81) => {
                const _0x1148cb = _0x115486('ArrowLeftBold'), _0x38de5f = _0x3daed3, _0x41d4c9 = _0x9363df, _0x3219c6 = _0x3fa598, _0x5c26cb = _0x115486('UploadFilled'), _0x35f505 = _0x115486('Edit'), _0x47d6b0 = da, _0x4f18f2 = _0x115486('Delete'), _0x504fad = _0x1aba78, _0x90b639 = _0x555efd, _0x6bcb90 = _0x499952, _0x6d037f = _0x4241b2, _0x5e6705 = _0x4683d4, _0xb87dc4 = _0x115486('Back'), _0x4d0837 = _0x115486('Right'), _0x1f1775 = _0x115486('ZoomOut'), _0x324ae1 = _0x115486('ZoomIn'), _0x334584 = _0x115486('Download'), _0x421e8e = _0x115486('Picture'), _0x32aa6b = _0x94eddc, _0x5f0c50 = _0x115486('Check'), _0x513bd3 = _0x4c3aeb, _0x531773 = _0x3ec930, _0x4fe21f = _0x532f36, _0x1f11b1 = _0x5354e0, _0x5d7012 = _0x4601c0, _0x1a95f1 = _0xf29fcf, _0x3d4a10 = _0x4c14d1;
                return _0x2628af(), _0xe6c382('div', null, [
                    _0x5cf902(_0x531773, {
                        'class': 'card',
                        'shadow': 'hover'
                    }, {
                        'header': _0x24279a(() => [
                            _0x439656('div', va, [
                                _0x5cf902(_0x41d4c9, {
                                    'class': 'my-album-btn',
                                    'onClick': _0x5039d3
                                }, {
                                    'default': _0x24279a(() => [_0x5cf902(_0x38de5f, null, {
                                            'default': _0x24279a(() => [_0x5cf902(_0x1148cb)]),
                                            '_': 0x1
                                        })]),
                                    '_': 0x1
                                }),
                                _0x439656('div', ma, [_0x5cf902(_0x3219c6, {
                                        'class': 'title',
                                        'type': 'primary',
                                        'size': 'large'
                                    }, {
                                        'default': _0x24279a(() => [_0x163bcf(_0x3401ef(_0x19a59f['value']['name']), 0x1)]),
                                        '_': 0x1
                                    })]),
                                _0x19a59f['value']['userName'] ? (_0x2628af(), _0xe6c382('div', pa, [_0x5cf902(_0x3219c6, {
                                        'class': 'user-name',
                                        'type': 'secondary'
                                    }, {
                                        'default': _0x24279a(() => [
                                            _0xb3be81[0xa] || (_0xb3be81[0xa] = _0x439656('span', { 'class': 'at-symbol' }, '@', -0x1)),
                                            _0x163bcf(_0x3401ef(_0x19a59f['value']['userName']), 0x1)
                                        ]),
                                        '_': 0x1,
                                        '__': [0xa]
                                    })])) : _0x131db9('', !0x0)
                            ]),
                            _0x5b1672['value'] ? (_0x2628af(), _0xe6c382('div', fa, [
                                _0x5cf902(_0x41d4c9, {
                                    'class': 'upload-photo-btn',
                                    'type': 'primary',
                                    'onClick': _0x33ee0b
                                }, {
                                    'default': _0x24279a(() => [
                                        _0x5cf902(_0x38de5f, { 'style': { 'margin-right': '2px' } }, {
                                            'default': _0x24279a(() => [_0x5cf902(_0x5c26cb)]),
                                            '_': 0x1
                                        }),
                                        _0xb3be81[0xb] || (_0xb3be81[0xb] = _0x163bcf('上传图片\x20'))
                                    ]),
                                    '_': 0x1,
                                    '__': [0xb]
                                }),
                                _0x5cf902(_0x41d4c9, {
                                    'class': 'edit-album-btn',
                                    'type': 'warning',
                                    'onClick': _0x58bb43
                                }, {
                                    'default': _0x24279a(() => [
                                        _0x5cf902(_0x38de5f, { 'style': { 'margin-right': '2px' } }, {
                                            'default': _0x24279a(() => [_0x5cf902(_0x35f505)]),
                                            '_': 0x1
                                        }),
                                        _0xb3be81[0xc] || (_0xb3be81[0xc] = _0x163bcf('编辑相册\x20'))
                                    ]),
                                    '_': 0x1,
                                    '__': [0xc]
                                }),
                                _0x5cf902(_0x47d6b0, {
                                    'class': 'show-status-switch',
                                    'modelValue': _0x4cd968['value'],
                                    'onUpdate:modelValue': _0xb3be81[0x0] || (_0xb3be81[0x0] = _0x3beff4 => _0x4cd968['value'] = _0x3beff4),
                                    'onClick': _0x40dcdb,
                                    'active-text': '公开',
                                    'style': {
                                        '--el-switch-on-color': '#13ce66',
                                        '--el-switch-off-color': '#ff4949'
                                    },
                                    'inactive-text': '私密',
                                    'size': 'large',
                                    'inline-prompt': ''
                                }, null, 0x8, ['modelValue'])
                            ])) : _0x131db9('', !0x0),
                            _0x5b1672['value'] ? (_0x2628af(), _0xe6c382('div', ha, [
                                _0x5f45e9['value'] ? (_0x2628af(), _0x3fb169(_0x41d4c9, {
                                    'key': 0x0,
                                    'class': 'select-all-btn',
                                    'style': { 'margin-right': '5px' },
                                    'type': 'success',
                                    'onClick': _0x21faac
                                }, {
                                    'default': _0x24279a(() => [_0x163bcf(_0x3401ef(_0x924206['value'] ? '取消全选' : '全选'), 0x1)]),
                                    '_': 0x1
                                })) : _0x131db9('', !0x0),
                                _0x5cf902(_0x41d4c9, {
                                    'class': 'select-btn',
                                    'style': { 'margin-right': '5px' },
                                    'type': 'info',
                                    'onClick': _0x4d7a87
                                }, {
                                    'default': _0x24279a(() => [_0x163bcf(_0x3401ef(_0x5f45e9['value'] ? '取消选择' : '选择图片'), 0x1)]),
                                    '_': 0x1
                                }),
                                _0x3a1940(_0x5cf902(_0x41d4c9, {
                                    'class': 'delete-btn',
                                    'style': { 'margin-right': '5px' },
                                    'type': 'danger',
                                    'onClick': _0x5ed859
                                }, {
                                    'default': _0x24279a(() => [
                                        _0x5cf902(_0x38de5f, null, {
                                            'default': _0x24279a(() => [_0x5cf902(_0x4f18f2)]),
                                            '_': 0x1
                                        }),
                                        _0x163bcf('删除\x20(' + _0x3401ef(_0x46b87c['value']['length']) + ')\x20', 0x1)
                                    ]),
                                    '_': 0x1
                                }, 0x200), [[
                                        _0x507375,
                                        _0x46b87c['value']['length'] > 0x0
                                    ]]),
                                _0x5cf902(_0x6bcb90, { 'trigger': 'hover' }, {
                                    'dropdown': _0x24279a(() => [_0x5cf902(_0x90b639, null, {
                                            'default': _0x24279a(() => [_0x5cf902(_0x504fad, {
                                                    'onClick': _0x1c25fd,
                                                    'type': 'danger'
                                                }, {
                                                    'default': _0x24279a(() => _0xb3be81[0xd] || (_0xb3be81[0xd] = [_0x163bcf('删除相册')])),
                                                    '_': 0x1,
                                                    '__': [0xd]
                                                })]),
                                            '_': 0x1
                                        })]),
                                    'default': _0x24279a(() => [_0x5cf902(_0x41d4c9, {
                                            'type': 'default',
                                            'icon': 'More'
                                        })]),
                                    '_': 0x1
                                })
                            ])) : _0x131db9('', !0x0)
                        ]),
                        'default': _0x24279a(() => [_0x439656('div', ga, [
                                _0x3f2aa8['value'] ? (_0x2628af(), _0x3fb169(_0x6d037f, { 'key': 0x0 })) : _0x131db9('', !0x0),
                                (_0x2628af(!0x0), _0xe6c382(_0x145d65, null, _0x2dfdca(_0x4a5db8['value'], (_0x5c0f05, _0x43e786) => (_0x2628af(), _0xe6c382('div', {
                                    'key': _0x43e786,
                                    'class': 'date-section'
                                }, [
                                    _0x439656('div', _a, [
                                        _0x439656('h3', null, _0x3401ef(_0x43e786), 0x1),
                                        _0x5f45e9['value'] ? (_0x2628af(), _0x3fb169(_0x5e6705, {
                                            'key': 0x0,
                                            'modelValue': _0x4f1633['value'][_0x43e786],
                                            'onUpdate:modelValue': _0x3c4615 => _0x4f1633['value'][_0x43e786] = _0x3c4615,
                                            'onChange': _0x17a8b0 => _0x1b0815(_0x43e786),
                                            'size': 'large'
                                        }, null, 0x8, [
                                            'modelValue',
                                            'onUpdate:modelValue',
                                            'onChange'
                                        ])) : _0x131db9('', !0x0)
                                    ]),
                                    _0x439656('div', ya, [(_0x2628af(!0x0), _0xe6c382(_0x145d65, null, _0x2dfdca(_0x5c0f05, (_0x409852, _0x4b6aa3) => (_0x2628af(), _0xe6c382('div', {
                                            'key': _0x409852['id'],
                                            'class': _0x33018b([
                                                'photo-item',
                                                { 'selected': _0x46b87c['value']['includes'](_0x409852['id']) }
                                            ]),
                                            'onClick': _0x1a78a4 => _0x130d9b(_0x409852)
                                        }, [
                                            _0x409852['url'] ? (_0x2628af(), _0x3fb169(_0x32aa6b, {
                                                'key': 0x0,
                                                'src': _0x409852['url'] || '',
                                                'class': 'photo',
                                                'fit': 'cover',
                                                'preview-src-list': _0x5f45e9['value'] ? [] : _0x2dee12(),
                                                'preview-teleported': !_0x5f45e9['value'],
                                                'initial-index': _0x35c624(_0x409852),
                                                'show-progress': '',
                                                'close-on-press-escape': '',
                                                'lazy': '',
                                                'loading': 'lazy'
                                            }, {
                                                'toolbar': _0x24279a(({
                                                    actions: _0xd539f1,
                                                    prev: _0xbac337,
                                                    next: _0x43278b,
                                                    activeIndex: _0x4f2b0e
                                                }) => [
                                                    _0x5cf902(_0x38de5f, { 'onClick': _0xbac337 }, {
                                                        'default': _0x24279a(() => [_0x5cf902(_0xb87dc4)]),
                                                        '_': 0x2
                                                    }, 0x408, ['onClick']),
                                                    _0x5cf902(_0x38de5f, { 'onClick': _0x43278b }, {
                                                        'default': _0x24279a(() => [_0x5cf902(_0x4d0837)]),
                                                        '_': 0x2
                                                    }, 0x408, ['onClick']),
                                                    _0x5cf902(_0x38de5f, { 'onClick': _0x13e11c => _0xd539f1('zoomOut') }, {
                                                        'default': _0x24279a(() => [_0x5cf902(_0x1f1775)]),
                                                        '_': 0x2
                                                    }, 0x408, ['onClick']),
                                                    _0x5cf902(_0x38de5f, {
                                                        'onClick': _0x1c3345 => _0xd539f1('zoomIn', {
                                                            'enableTransition': !0x1,
                                                            'zoomRate': 0x2
                                                        })
                                                    }, {
                                                        'default': _0x24279a(() => [_0x5cf902(_0x324ae1)]),
                                                        '_': 0x2
                                                    }, 0x408, ['onClick']),
                                                    _0x5cf902(_0x38de5f, { 'onClick': _0x4afb69 => _0x4009fe(_0x4f2b0e) }, {
                                                        'default': _0x24279a(() => [_0x5cf902(_0x334584)]),
                                                        '_': 0x2
                                                    }, 0x408, ['onClick'])
                                                ]),
                                                'placeholder': _0x24279a(() => _0xb3be81[0xe] || (_0xb3be81[0xe] = [_0x439656('div', { 'class': 'loading-text' }, '加载中...', -0x1)])),
                                                'error': _0x24279a(() => [_0x439656('div', ba, [_0x5cf902(_0x38de5f, null, {
                                                            'default': _0x24279a(() => [_0x5cf902(_0x421e8e)]),
                                                            '_': 0x1
                                                        })])]),
                                                '_': 0x2
                                            }, 0x408, [
                                                'src',
                                                'preview-src-list',
                                                'preview-teleported',
                                                'initial-index'
                                            ])) : _0x131db9('', !0x0),
                                            _0x439656('div', {
                                                'class': _0x33018b([
                                                    'examine-status',
                                                    _0x1f68bf(_0x409852['examineStatus'])
                                                ])
                                            }, _0x3401ef(_0x1c48c7(_0x409852['examineStatus'])), 0x3),
                                            _0x5f45e9['value'] ? (_0x2628af(), _0xe6c382('div', ka, [_0x46b87c['value']['includes'](_0x409852['id']) ? (_0x2628af(), _0x3fb169(_0x38de5f, {
                                                    'key': 0x0,
                                                    'class': 'selected-icon'
                                                }, {
                                                    'default': _0x24279a(() => [_0x5cf902(_0x5f0c50)]),
                                                    '_': 0x1
                                                })) : _0x131db9('', !0x0)])) : _0x131db9('', !0x0)
                                        ], 0xa, wa))), 0x80))])
                                ]))), 0x80)),
                                Object['keys'](_0x4a5db8['value'])['length'] === 0x0 && !_0x3f2aa8['value'] ? (_0x2628af(), _0x3fb169(_0x513bd3, {
                                    'key': 0x1,
                                    'image-size': 0xc8,
                                    'description': '暂无图片'
                                })) : _0x131db9('', !0x0)
                            ])]),
                        '_': 0x1
                    }),
                    _0x5cf902(_0x1f11b1, {
                        'class': 'upload-dialog',
                        'modelValue': _0x17dea9['value'],
                        'onUpdate:modelValue': _0xb3be81[0x3] || (_0xb3be81[0x3] = _0x58a006 => _0x17dea9['value'] = _0x58a006),
                        'title': '上传图片'
                    }, {
                        'footer': _0x24279a(() => [_0x439656('span', Ia, [
                                _0x5cf902(_0x41d4c9, { 'onClick': _0xb3be81[0x2] || (_0xb3be81[0x2] = _0x2e7234 => _0x17dea9['value'] = !0x1) }, {
                                    'default': _0x24279a(() => _0xb3be81[0x11] || (_0xb3be81[0x11] = [_0x163bcf('取消')])),
                                    '_': 0x1,
                                    '__': [0x11]
                                }),
                                _0x5cf902(_0x41d4c9, {
                                    'type': 'primary',
                                    'onClick': _0x482cbb,
                                    'loading': _0x5db39b['value']
                                }, {
                                    'default': _0x24279a(() => _0xb3be81[0x12] || (_0xb3be81[0x12] = [_0x163bcf('开始上传')])),
                                    '_': 0x1,
                                    '__': [0x12]
                                }, 0x8, ['loading'])
                            ])]),
                        'default': _0x24279a(() => [
                            _0x5cf902(_0x4fe21f, {
                                'action': '#',
                                'auto-upload': !0x1,
                                'file-list': _0xe07902['value'],
                                'onUpdate:fileList': _0xb3be81[0x1] || (_0xb3be81[0x1] = _0xe5048e => _0xe07902['value'] = _0xe5048e),
                                'on-change': _0x45482e,
                                'accept': '.jpg,.gif,.png,.jpeg,.webp',
                                'multiple': ''
                            }, {
                                'tip': _0x24279a(() => _0xb3be81[0x10] || (_0xb3be81[0x10] = [_0x439656('div', { 'class': 'el-upload__tip' }, 'jpg/png/gif/jpeg/webp\x20格式，单个文件不超过5MB', -0x1)])),
                                'default': _0x24279a(() => [_0x5cf902(_0x41d4c9, { 'type': 'primary' }, {
                                        'default': _0x24279a(() => _0xb3be81[0xf] || (_0xb3be81[0xf] = [_0x163bcf('选择图片')])),
                                        '_': 0x1,
                                        '__': [0xf]
                                    })]),
                                '_': 0x1
                            }, 0x8, ['file-list']),
                            _0x439656('div', Ca, [(_0x2628af(!0x0), _0xe6c382(_0x145d65, null, _0x2dfdca(_0xe07902['value'], (_0x1c93e8, _0x33c69f) => (_0x2628af(), _0xe6c382('div', {
                                    'key': _0x33c69f,
                                    'class': 'preview-item'
                                }, [_0x5cf902(_0x32aa6b, {
                                        'src': _0x1c93e8['url'] || (_0x1c93e8['raw'] ? _0x217eb4(_0x44d820)['createObjectURL'](_0x1c93e8['raw']) : ''),
                                        'class': 'preview-image',
                                        'fit': 'cover',
                                        'preview-src-list': [_0x1c93e8['url'] || (_0x1c93e8['raw'] ? _0x217eb4(_0x44d820)['createObjectURL'](_0x1c93e8['raw']) : '')]
                                    }, {
                                        'error': _0x24279a(() => [_0x439656('div', Ea, [_0x5cf902(_0x38de5f, null, {
                                                    'default': _0x24279a(() => [_0x5cf902(_0x421e8e)]),
                                                    '_': 0x1
                                                })])]),
                                        '_': 0x2
                                    }, 0x408, [
                                        'src',
                                        'preview-src-list'
                                    ])]))), 0x80))])
                        ]),
                        '_': 0x1
                    }, 0x8, ['modelValue']),
                    _0x5cf902(_0x1f11b1, {
                        'modelValue': _0xa33fb0['value'],
                        'onUpdate:modelValue': _0xb3be81[0x7] || (_0xb3be81[0x7] = _0x2c8908 => _0xa33fb0['value'] = _0x2c8908),
                        'title': '编辑相册',
                        'width': '500px'
                    }, {
                        'footer': _0x24279a(() => [_0x439656('span', Sa, [
                                _0x5cf902(_0x41d4c9, { 'onClick': _0xb3be81[0x6] || (_0xb3be81[0x6] = _0x2ef5d6 => _0xa33fb0['value'] = !0x1) }, {
                                    'default': _0x24279a(() => _0xb3be81[0x14] || (_0xb3be81[0x14] = [_0x163bcf('取消')])),
                                    '_': 0x1,
                                    '__': [0x14]
                                }),
                                _0x5cf902(_0x41d4c9, {
                                    'type': 'primary',
                                    'onClick': _0x5e953b
                                }, {
                                    'default': _0x24279a(() => _0xb3be81[0x15] || (_0xb3be81[0x15] = [_0x163bcf('确定')])),
                                    '_': 0x1,
                                    '__': [0x15]
                                })
                            ])]),
                        'default': _0x24279a(() => [_0x5cf902(_0x3d4a10, {
                                'model': _0x19a59f['value'],
                                'label-width': '80px'
                            }, {
                                'default': _0x24279a(() => [
                                    _0x5cf902(_0x1a95f1, { 'label': '相册名称' }, {
                                        'default': _0x24279a(() => [_0x5cf902(_0x5d7012, {
                                                'modelValue': _0x19a59f['value']['name'],
                                                'onUpdate:modelValue': _0xb3be81[0x4] || (_0xb3be81[0x4] = _0x5d3397 => _0x19a59f['value']['name'] = _0x5d3397)
                                            }, null, 0x8, ['modelValue'])]),
                                        '_': 0x1
                                    }),
                                    _0x19a59f['value']['coverUrl'] ? (_0x2628af(), _0x3fb169(_0x1a95f1, {
                                        'key': 0x0,
                                        'label': '相册封面'
                                    }, {
                                        'default': _0x24279a(() => [_0x439656('div', {
                                                'class': 'cover-container',
                                                'onClick': _0xb3be81[0x5] || (_0xb3be81[0x5] = _0x5c7777 => _0x2e9bfa(_0x19a59f['value']['id']))
                                            }, [
                                                _0x5cf902(_0x32aa6b, {
                                                    'src': _0x19a59f['value']['coverUrl'],
                                                    'style': {
                                                        'width': '100px',
                                                        'height': '100px',
                                                        'border-radius': '8px'
                                                    },
                                                    'fit': 'cover'
                                                }, null, 0x8, ['src']),
                                                _0xb3be81[0x13] || (_0xb3be81[0x13] = _0x439656('div', { 'class': 'cover-overlay' }, [_0x439656('span', { 'class': 'cover-text' }, '点击更换封面')], -0x1))
                                            ])]),
                                        '_': 0x1
                                    })) : _0x131db9('', !0x0)
                                ]),
                                '_': 0x1
                            }, 0x8, ['model'])]),
                        '_': 0x1
                    }, 0x8, ['modelValue']),
                    _0x5cf902(_0x1f11b1, {
                        'modelValue': _0x3b614c['value'],
                        'onUpdate:modelValue': _0xb3be81[0x9] || (_0xb3be81[0x9] = _0x1c852e => _0x3b614c['value'] = _0x1c852e),
                        'title': '选择封面图片',
                        'width': '690px',
                        'style': { 'padding': '20px' }
                    }, {
                        'footer': _0x24279a(() => [
                            _0x5cf902(_0x41d4c9, { 'onClick': _0xb3be81[0x8] || (_0xb3be81[0x8] = _0xad4b53 => _0x3b614c['value'] = !0x1) }, {
                                'default': _0x24279a(() => _0xb3be81[0x16] || (_0xb3be81[0x16] = [_0x163bcf('取消')])),
                                '_': 0x1,
                                '__': [0x16]
                            }),
                            _0x5cf902(_0x41d4c9, {
                                'type': 'primary',
                                'onClick': _0xe59f75
                            }, {
                                'default': _0x24279a(() => _0xb3be81[0x17] || (_0xb3be81[0x17] = [_0x163bcf('确定')])),
                                '_': 0x1,
                                '__': [0x17]
                            })
                        ]),
                        'default': _0x24279a(() => [_0x439656('div', Va, [(_0x2628af(!0x0), _0xe6c382(_0x145d65, null, _0x2dfdca(_0x214225['value'], (_0x539b0f, _0x13a9fc) => (_0x2628af(), _0xe6c382('div', {
                                    'key': _0x13a9fc,
                                    'class': 'cover-image-container',
                                    'onClick': _0x117e18 => _0x432d7b['value'] = _0x539b0f['url']
                                }, [_0x5cf902(_0x32aa6b, {
                                        'src': _0x539b0f['url'],
                                        'style': {
                                            'width': '100%',
                                            'height': '100%'
                                        },
                                        'fit': 'cover',
                                        'class': _0x33018b({ 'selected': _0x432d7b['value'] === _0x539b0f['url'] })
                                    }, null, 0x8, [
                                        'src',
                                        'class'
                                    ])], 0x8, Ua))), 0x80))])]),
                        '_': 0x1
                    }, 0x8, ['modelValue'])
                ]);
            };
        }
    }, ul = _0x3e4286(Pa, [[
            '__scopeId',
            'data-v-3728f7a7'
        ]]);
export {
    ul as default
};