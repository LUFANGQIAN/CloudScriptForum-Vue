const _0x724048 = (function () {
        let _0x3d72d2 = !![];
        return function (_0x5c0faa, _0x4c9026) {
            const _0x2b9d62 = _0x3d72d2 ? function () {
                if (_0x4c9026) {
                    const _0x45a51d = _0x4c9026['apply'](_0x5c0faa, arguments);
                    return _0x4c9026 = null, _0x45a51d;
                }
            } : function () {
            };
            return _0x3d72d2 = ![], _0x2b9d62;
        };
    }()), _0x5be08f = _0x724048(this, function () {
        let _0x4bc0f0;
        try {
            const _0x495935 = Function('return\x20(function()\x20' + '{}.constructor(\x22return\x20this\x22)(\x20)' + ');');
            _0x4bc0f0 = _0x495935();
        } catch (_0x3cda09) {
            _0x4bc0f0 = window;
        }
        const _0x37a00b = _0x4bc0f0['console'] = _0x4bc0f0['console'] || {}, _0x42a21a = [
                'log',
                'warn',
                'info',
                'error',
                'exception',
                'table',
                'trace'
            ];
        for (let _0x1f06bf = 0x0; _0x1f06bf < _0x42a21a['length']; _0x1f06bf++) {
            const _0x8e65b5 = _0x724048['constructor']['prototype']['bind'](_0x724048), _0x350225 = _0x42a21a[_0x1f06bf], _0x3c3c0f = _0x37a00b[_0x350225] || _0x8e65b5;
            _0x8e65b5['__proto__'] = _0x724048['bind'](_0x724048), _0x8e65b5['toString'] = _0x3c3c0f['toString']['bind'](_0x3c3c0f), _0x37a00b[_0x350225] = _0x8e65b5;
        }
    });
_0x5be08f();
import {
    aI as _0x36ffad,
    c as _0x2671d2,
    i as _0x1ba56e
} from './Request-CHKnUlo5.js';
import { m as _0x470a6a } from './index-54DmW9hq.js';
function l() {
    let _0x247683;
    const _0x749502 = (_0x8d5925, _0x5a27c6) => {
            _0x496528(), _0x247683 = window['setTimeout'](_0x8d5925, _0x5a27c6);
        }, _0x496528 = () => window['clearTimeout'](_0x247683);
    return _0x36ffad(() => _0x496528()), {
        'registerTimeout': _0x749502,
        'cancelTimeout': _0x496528
    };
}
const w = _0x2671d2({
        'showAfter': {
            'type': Number,
            'default': 0x0
        },
        'hideAfter': {
            'type': Number,
            'default': 0xc8
        },
        'autoClose': {
            'type': Number,
            'default': 0x0
        }
    }), A = ({
        showAfter: _0x23cf49,
        hideAfter: _0x41d1fb,
        autoClose: _0x4e5325,
        open: _0x457db2,
        close: _0x206496
    }) => {
        const {registerTimeout: _0x55b25f} = l(), {
                registerTimeout: _0x3a4858,
                cancelTimeout: _0x35875f
            } = l();
        return {
            'onOpen': (_0x1d3285, _0x3a3ac3 = _0x470a6a(_0x23cf49)) => {
                _0x55b25f(() => {
                    _0x457db2(_0x1d3285);
                    const _0x381411 = _0x470a6a(_0x4e5325);
                    _0x1ba56e(_0x381411) && _0x381411 > 0x0 && _0x3a4858(() => {
                        _0x206496(_0x1d3285);
                    }, _0x381411);
                }, _0x3a3ac3);
            },
            'onClose': (_0x2bfc16, _0x228524 = _0x470a6a(_0x41d1fb)) => {
                _0x35875f(), _0x55b25f(() => {
                    _0x206496(_0x2bfc16);
                }, _0x228524);
            }
        };
    };
export {
    A as a,
    w as u
};