<template>
  <router-view class="album-router-view"></router-view>
</template>

<script setup></script>

<style lang="scss" scoped>
.album-router-view {
  padding-top: 48px;
  min-height: 100vh;
  overflow-y: auto;
  background-color: var(--el-bg-color-page);
}
</style>
