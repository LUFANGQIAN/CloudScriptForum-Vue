// 封装axios，做请求处理
// 导入axios
import axios from "axios";
// 引入router
import router from "@/router/index.js";
// 获取token
import { GetJwt, RemoveJwt } from "@/utils/Auth.js";
// 引入ElMessage
import { ElMessage } from "element-plus";
// 引入userStore
import { useUserStore } from "@/stores/userStore.js";
const userStore = useUserStore();

// 创建axios
const request = axios.create({
  // 后端地址
  baseURL: import.meta.env.VITE_BACKEND_SERVER + 'api',
  withCredentials: false, // 用于配置请求接口跨域时是否需要凭证
  timeout: 30000, // 增加超时时间到30秒
  headers: {
    // 配置请求头的参数类型，和编码格式
    "Content-Type": "application/json;charset=UTF-8",
  },
});

// 配置请求的拦截器
request.interceptors.request.use(
  (config) => {
    // 在请求头添加token, 判断是否需要发送token
    if (GetJwt()) {
      config.headers["Authorization"] = GetJwt();
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);



// 配置响应拦截器
request.interceptors.response.use(
  (response) => {
    console.log(response)
    let { code, msg } = response.data;
    if (code == 200) {
      if (msg) {
        ElMessage.success(msg);
      }
      return response;
    } else {
      // 响应失败的处理 401 400
      ElMessage.error(msg)
    }
    return Promise.reject(response.data);
  },
  (error) => {
    if (error.response) {
      let { status, data } = error.response;
      if (status === 401) {
        // 401 代表token过期或被禁用或被删除，需要重新登录
        ElMessage.error(data.msg);
        // 清除userStore数据
        userStore.clearUser();
        // 需要重新登陆，跳转到登录页面
        router.push("/login");
      }
    }
    return Promise.reject(error);
  }
);

// 导出
export default request;
