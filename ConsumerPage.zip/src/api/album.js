import request from '@/utils/Request'

// 查看相册详情
export function getAlbum(albumId) {
  return request({
    url: `/album/get/${albumId}`,
    method: 'get'
  })
}

// 新建相册
export function createAlbum(data) {
  return request({
    url: '/album/create',
    method: 'post',
    data
  })
}

// 更新相册
export function updateAlbum(data) {
  return request({
    url: '/album/update',
    method: 'put',
    data
  })
}

// 删除相册
export function deleteAlbum(albumId) {
  return request({
    url: `/album/delete/${albumId}`,
    method: 'delete'
  })
}

// 查看用户所有的相册
export function listAlbum() {
  return request({
    url: '/album/list',
    method: 'get'
  })
}

// 查看所有用户的相册
export function listAllAlbum() {
  return request({
    url: '/album/listAll',
    method: 'get'
  })
}

// 修改相册展示状态
export function changeShowStatus(data) {
  return request({
    url: '/album/changeShowStatus',
    method: 'put',
    data
  })
}

// 相册更换封面
export function changeCover(data) {
  return request({
    url: '/album/changeCover',
    method: 'put',
    data
  })
}