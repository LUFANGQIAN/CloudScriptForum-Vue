<template>
  <!-- <router-view v-slot="{ Component }">
    <transition name="scale" mode="out-in">
      <component :is="Component" />
    </transition>
  </router-view> -->


  <router-view>


  </router-view>
</template>

<script setup>

</script>

<style lang="scss">
body {
  background-color: #f9fafb !important;
}
</style>
